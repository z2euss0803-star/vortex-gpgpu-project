#ifndef VX_TCU_S8_PAIR_H
#define VX_TCU_S8_PAIR_H
#include <stdint.h>

static inline int s8x2_valid_shape(unsigned m,unsigned n,unsigned k) {
    return m>=1 && m<=16 && n>=1 && n<=8 && k>=1 && k<=4096;
}
static inline uint32_t s8x2_pack16(int16_t lo,int16_t hi) {
    return (uint32_t)(uint16_t)lo | ((uint32_t)(uint16_t)hi<<16);
}
// Each bank contains 64 little-endian signed48 values, not 64 low32 values.
static inline void s8x2_unpack48(const uint32_t bank_words[2][96],int64_t out[128]) {
    for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<64;++i) {
        unsigned bit=48*i,word=bit/32,shift=bit%32;
        uint64_t pair=(uint64_t)bank_words[bank][word] | ((uint64_t)bank_words[bank][word+1]<<32);
        uint64_t raw=(pair>>shift)&UINT64_C(0xffffffffffff);
        out[bank*64+i]=(raw&(UINT64_C(1)<<47))?(int64_t)raw-(INT64_C(1)<<48):(int64_t)raw;
    }
}
#if defined(__riscv) && (__riscv_xlen == 32)
// All four lanes call in identical order; only lane0 supplies nonzero control.
// x3 is the format tag in the custom word. Actual uops return f10, never gp.
static inline uint32_t s8x2_begin(uint32_t control_lane_word) {
    uint32_t result;
    __asm__ volatile("fmv.w.x f10, %1\n\t.insn r 0x0b, 0, 2, x3, x13, x0\n\tfmv.x.w %0, f10"
        : "=r"(result) : "r"(control_lane_word) : "f0","f28","f10","memory");
    return result;
}
static inline void s8x2_step(uint32_t a0_pair,uint32_t b_pair,uint32_t a1_pair) {
    __asm__ volatile("fmv.w.x f0, %0\n\tfmv.w.x f28, %1\n\tfmv.w.x f10, %2\n\t.insn r 0x0b, 0, 2, x3, x14, x0"
        : : "r"(a0_pair),"r"(b_pair),"r"(a1_pair) : "f0","f28","f10","memory");
}
static inline uint32_t s8x2_read(uint32_t control_lane_word) {
    uint32_t result;
    __asm__ volatile("fmv.w.x f10, %1\n\t.insn r 0x0b, 0, 2, x3, x15, x0\n\tfmv.x.w %0, f10"
        : "=r"(result) : "r"(control_lane_word) : "f0","f28","f10","memory");
    return result;
}
#endif
#endif
