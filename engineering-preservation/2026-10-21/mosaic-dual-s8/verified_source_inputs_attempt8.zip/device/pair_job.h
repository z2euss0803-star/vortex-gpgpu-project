#ifndef PAIR_JOB_H
#define PAIR_JOB_H
#include <stdint.h>
// Private simulation ABI. GPU32 addresses, never Linux/CPU pointers.
struct PairJob {
    uint32_t magic,version,k,m,n,pair_mode,repeats,reserved;
    uint32_t a0,a1,b,outputs,statuses,identities,timings,reserved2;
};
static_assert(sizeof(PairJob)==64,"private job must be64bytes");
static const uint32_t kPairJobMagic=0x53385832;
#endif
