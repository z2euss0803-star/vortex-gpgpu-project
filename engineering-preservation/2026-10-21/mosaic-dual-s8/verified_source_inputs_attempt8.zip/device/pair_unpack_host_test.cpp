#include "vx_tcu_s8_pair.h"
#include <stdio.h>
int main() {
    uint32_t words[2][96]={};int64_t expected[128],actual[128];
    const int64_t edge[]={-(INT64_C(1)<<47),(INT64_C(1)<<47)-1,-1,0,1,4398046511104LL,-4398046511104LL};
    for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<64;++i) {
        unsigned j=bank*64+i;expected[j]=i<7?edge[i]:(int64_t)(j*199-20000);
        uint64_t raw=(uint64_t)expected[j]&UINT64_C(0xffffffffffff);
        for(unsigned bit=0;bit<48;++bit)words[bank][(i*48+bit)/32]|=(uint32_t)((raw>>bit)&1)<<((i*48+bit)%32);
    }
    s8x2_unpack48(words,actual);
    for(unsigned i=0;i<128;++i)if(expected[i]!=actual[i])return 1;
    for(unsigned m=1;m<=16;++m)for(unsigned n=1;n<=8;++n)if(!s8x2_valid_shape(m,n,4096))return 2;
    if(s8x2_valid_shape(0,8,1)||s8x2_valid_shape(17,8,1)||s8x2_valid_shape(16,9,1)||s8x2_valid_shape(16,8,4097))return 3;
    if(s8x2_pack16(-32768,32767)!=UINT32_C(0x7fff8000))return 4;
    puts("PAIR_HEADER_HOST_PASS signed48=128 shapes=128");return 0;
}
