// Private actual-GPU contention workload. Public job ABI and product RTL intact.
extern "C" void bp_owner_commit_burst();
#define PAIR_PAGE_OBSERVER bp_owner_commit_burst
#define main original_pair_validation_main
#include "pair_validation.cpp"
#undef main
#undef PAIR_PAGE_OBSERVER

static __thread uint32_t bp_alu_sums[8],bp_alu_count;
extern "C" __attribute__((noinline)) void bp_owner_commit_burst() {
    uint32_t a=bp_alu_sums[0],b=bp_alu_sums[1],c=bp_alu_sums[2],d=bp_alu_sums[3];
    uint32_t e=bp_alu_sums[4],f=bp_alu_sums[5],g=bp_alu_sums[6],h=bp_alu_sums[7];
    __asm__ volatile(
        ".globl bp_alu_burst_begin\n bp_alu_burst_begin:\n .rept 32\n"
        "addi %0,%0,1\n addi %1,%1,1\n addi %2,%2,1\n addi %3,%3,1\n"
        "addi %4,%4,1\n addi %5,%5,1\n addi %6,%6,1\n addi %7,%7,1\n"
        ".endr\n .globl bp_alu_burst_end\n bp_alu_burst_end:\n"
        :"+r"(a),"+r"(b),"+r"(c),"+r"(d),"+r"(e),"+r"(f),"+r"(g),"+r"(h)::"memory");
    bp_alu_sums[0]=a;bp_alu_sums[1]=b;bp_alu_sums[2]=c;bp_alu_sums[3]=d;
    bp_alu_sums[4]=e;bp_alu_sums[5]=f;bp_alu_sums[6]=g;bp_alu_sums[7]=h;bp_alu_count+=256;
}

// Keep A/B/C in FPRs across sixteen complete WMMA instructions. Polling DDR
// after each individual instruction left too many gaps in the result stream.
template<unsigned FMT,unsigned DST,unsigned ONES,unsigned BATCH>
static inline void legacy_batch(const uint32_t c[8],uint32_t d[8]) {
    __asm__ volatile(
        "fmv.w.x f0,%[ones]\n fmv.w.x f1,%[ones]\n fmv.w.x f2,%[ones]\n fmv.w.x f3,%[ones]\n"
        "fmv.w.x f4,%[ones]\n fmv.w.x f5,%[ones]\n fmv.w.x f6,%[ones]\n fmv.w.x f7,%[ones]\n"
        "fmv.w.x f28,%[ones]\n fmv.w.x f29,%[ones]\n fmv.w.x f30,%[ones]\n fmv.w.x f31,%[ones]\n"
        "fmv.w.x f10,%[c0]\n fmv.w.x f11,%[c1]\n fmv.w.x f12,%[c2]\n fmv.w.x f13,%[c3]\n"
        "fmv.w.x f14,%[c4]\n fmv.w.x f15,%[c5]\n fmv.w.x f16,%[c6]\n fmv.w.x f17,%[c7]\n"
        ".rept %[batch]\n .word %[word]\n .endr\n"
        "fmv.x.w %[d0],f10\n fmv.x.w %[d1],f11\n fmv.x.w %[d2],f12\n fmv.x.w %[d3],f13\n"
        "fmv.x.w %[d4],f14\n fmv.x.w %[d5],f15\n fmv.x.w %[d6],f16\n fmv.x.w %[d7],f17\n"
        :[d0]"=r"(d[0]),[d1]"=r"(d[1]),[d2]"=r"(d[2]),[d3]"=r"(d[3]),
         [d4]"=r"(d[4]),[d5]"=r"(d[5]),[d6]"=r"(d[6]),[d7]"=r"(d[7])
        :[ones]"r"(ONES),[batch]"i"(BATCH),[word]"i"(0x0400000b|(FMT<<15)|(DST<<7)),
         [c0]"r"(c[0]),[c1]"r"(c[1]),[c2]"r"(c[2]),[c3]"r"(c[3]),
         [c4]"r"(c[4]),[c5]"r"(c[5]),[c6]"r"(c[6]),[c7]"r"(c[7])
        :"f0","f1","f2","f3","f4","f5","f6","f7","f10","f11","f12","f13","f14","f15","f16","f17","f28","f29","f30","f31","memory");
}

static inline void query_batch(unsigned lane,uint32_t& query_count,uint32_t& last_query,uint32_t& error) {
    for(unsigned q=0;q<64;++q) {
        last_query=s8x2_read(lane?0:31);++query_count;
        if(last_query)error=0xe102;
    }
}

static void backpressure_kernel(PairJob* __UNIFORM__ job) {
    unsigned core=vx_core_id(),warp=vx_warp_id(),lane=vx_thread_id(),hart=vx_hart_id();
    volatile uint32_t probe[4];probe[0]=0xa1000000|hart;tls_identity=0xb2000000|hart;
    uint32_t sp,tp;__asm__ volatile("mv %0,sp":"=r"(sp));__asm__ volatile("mv %0,tp":"=r"(tp));
    volatile uint32_t* id=(volatile uint32_t*)job->identities+hart*16;
    id[0]=core;id[1]=warp;id[2]=lane;id[3]=hart;id[4]=sp;id[5]=tp;
    id[6]=(uint32_t)&probe[0];id[7]=(uint32_t)&tls_identity;id[8]=probe[0];id[9]=tls_identity;
    volatile uint32_t* flag=(volatile uint32_t*)0x2a000000+core*16;
    if(warp==0 && lane==0){*flag=0;vx_fence();}
    __syncthreads();
    uint32_t error=0,count=0,c[8]={0},d[8],fp_count=0,fc[8]={0},fd[8],query_count=0,last_query=0;
    if(warp==0) {
        volatile uint32_t* out=(volatile uint32_t*)job->outputs+core*1024;
        uint64_t start=cycles();error=execute(job,out);vx_fence();uint64_t end=cycles();
        if(lane==0){((volatile uint64_t*)job->timings)[core*32]=end-start;*flag=1;vx_fence();}
        vx_barrier(1,1);
        if(lane==0 && !error) {
            uint32_t local[2][96];int64_t results[128];
            for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<96;++i)local[bank][i]=out[bank*96+i];
            s8x2_unpack48(local,results);
            for(unsigned i=0;i<128;++i)((volatile int64_t*)(out+256))[i]=results[i];
        }
    } else {
        while(*flag==0 && count<4096) {
            // Rotate all three phases, avoiding the measured common query-only
            // window: warp1 FP/query/I8, warp2 I8/FP/query, warp3 query/I8/FP.
            // Each complete loop still has I8=16, FP=64 and query=64.
            if(warp==3)query_batch(lane,query_count,last_query,error);
            if(warp==1) {
                legacy_batch<1,0,0x3c003c00,64>(fc,fd);
                for(unsigned i=0;i<8;++i)fc[i]=fd[i];fp_count+=64;
                query_batch(lane,query_count,last_query,error);
            }
            legacy_batch<9,8,0x01010101,16>(c,d);for(unsigned i=0;i<8;++i)c[i]=d[i];count+=16;
            // A second actual PE contends at the unchanged outer result arbiter.
            // Preserve all three I8 streams; FP16 has separate exact evidence.
            if(warp!=1) {
                legacy_batch<1,0,0x3c003c00,64>(fc,fd);
                for(unsigned i=0;i<8;++i)fc[i]=fd[i];fp_count+=64;
            }
            if(warp==2)query_batch(lane,query_count,last_query,error);
        }
        if(*flag!=1 || count==0 || count==4096)error=0xe101;
    }
    volatile uint32_t* loop_out=(volatile uint32_t*)0x2b000000+hart*16;
    loop_out[0]=count;for(unsigned i=0;i<8;++i)loop_out[1+i]=c[i];
    volatile uint32_t* fp_out=(volatile uint32_t*)0x2c000000+hart*16;
    fp_out[0]=fp_count;for(unsigned i=0;i<8;++i)fp_out[1+i]=fc[i];
    volatile uint32_t* query_out=(volatile uint32_t*)0x2d000000+hart*16;
    query_out[0]=query_count;query_out[1]=last_query;
    volatile uint32_t* alu_out=(volatile uint32_t*)0x2e000000+hart*16;
    alu_out[0]=bp_alu_count;for(unsigned i=0;i<8;++i)alu_out[1+i]=bp_alu_sums[i];
    ((volatile uint32_t*)job->statuses)[hart]=error;vx_fence();__syncthreads();
}

int main() {
    PairJob* __UNIFORM__ job=(PairJob*)csr_read(VX_CSR_MSCRATCH);
    if(job->magic!=kPairJobMagic || job->version!=1 || job->reserved || job->reserved2 ||
       !s8x2_valid_shape(job->m,job->n,job->k) || job->k>64 || job->pair_mode!=1 || job->repeats!=1) {
        ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=0xbadab103;vx_fence();return 1;
    }
    uint32_t grid=4,block=16;int rc=vx_spawn_threads(1,&grid,&block,(vx_kernel_func_cb)backpressure_kernel,job);
    ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=rc;vx_fence();return rc;
}
