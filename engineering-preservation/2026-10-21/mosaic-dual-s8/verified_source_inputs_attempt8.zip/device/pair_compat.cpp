// Actual four-core validation ELF. No production runtime or ABI modification.
#define main original_pair_validation_main
#include "pair_validation.cpp"
#undef main

template<unsigned FMT,unsigned DST>
static inline void legacy_tile(uint32_t a,uint32_t b,const uint32_t c[8],uint32_t d[8]) {
    __asm__ volatile(
        "fmv.w.x f0,%[a]\n fmv.w.x f1,%[a]\n fmv.w.x f2,%[a]\n fmv.w.x f3,%[a]\n"
        "fmv.w.x f4,%[a]\n fmv.w.x f5,%[a]\n fmv.w.x f6,%[a]\n fmv.w.x f7,%[a]\n"
        "fmv.w.x f28,%[b]\n fmv.w.x f29,%[b]\n fmv.w.x f30,%[b]\n fmv.w.x f31,%[b]\n"
        "fmv.w.x f10,%[c0]\n fmv.w.x f11,%[c1]\n fmv.w.x f12,%[c2]\n fmv.w.x f13,%[c3]\n"
        "fmv.w.x f14,%[c4]\n fmv.w.x f15,%[c5]\n fmv.w.x f16,%[c6]\n fmv.w.x f17,%[c7]\n"
        ".word %[word]\n"
        "fmv.x.w %[d0],f10\n fmv.x.w %[d1],f11\n fmv.x.w %[d2],f12\n fmv.x.w %[d3],f13\n"
        "fmv.x.w %[d4],f14\n fmv.x.w %[d5],f15\n fmv.x.w %[d6],f16\n fmv.x.w %[d7],f17\n"
        :[d0]"=r"(d[0]),[d1]"=r"(d[1]),[d2]"=r"(d[2]),[d3]"=r"(d[3]),
         [d4]"=r"(d[4]),[d5]"=r"(d[5]),[d6]"=r"(d[6]),[d7]"=r"(d[7])
        :[a]"r"(a),[b]"r"(b),[c0]"r"(c[0]),[c1]"r"(c[1]),[c2]"r"(c[2]),[c3]"r"(c[3]),
         [c4]"r"(c[4]),[c5]"r"(c[5]),[c6]"r"(c[6]),[c7]"r"(c[7]),[word]"i"(0x0400000b|(FMT<<15)|(DST<<7))
        :"f0","f1","f2","f3","f4","f5","f6","f7","f10","f11","f12","f13","f14","f15","f16","f17","f28","f29","f30","f31","memory");
}
static inline void fpu_values(unsigned hart,uint32_t out[8]) {
    __asm__ volatile(
        "fcvt.s.w f0,%[n]\n fmv.w.x f1,%[two]\n fmv.w.x f2,%[one]\n fmv.w.x f3,%[sixteen]\n"
        "fadd.s f4,f0,f1\n fmv.x.w %[a],f4\n"
        "fmul.s f4,f0,f1\n fmv.x.w %[b],f4\n"
        "fsub.s f4,f0,f1\n fmv.x.w %[c],f4\n"
        "fdiv.s f4,f0,f1\n fmv.x.w %[d],f4\n"
        "fsqrt.s f4,f3\n fmv.x.w %[e],f4\n"
        "fmadd.s f4,f0,f1,f2\n fmv.x.w %[f],f4\n"
        "fcvt.w.s %[g],f0\n flt.s %[h],f0,f1\n"
        :[a]"=r"(out[0]),[b]"=r"(out[1]),[c]"=r"(out[2]),[d]"=r"(out[3]),
         [e]"=r"(out[4]),[f]"=r"(out[5]),[g]"=r"(out[6]),[h]"=r"(out[7])
        :[n]"r"(hart+1),[two]"r"(0x40000000),[one]"r"(0x3f800000),[sixteen]"r"(0x41800000)
        :"f0","f1","f2","f3","f4","memory");
}
static inline uint32_t tex(int u,int v) {
    uint32_t p;__asm__ volatile(".insn r 0x2b,0,0,%0,%1,%2":"=r"(p):"r"(u),"r"(v):"memory");return p;
}
static void compatibility(unsigned hart) {
    volatile uint32_t* out=(volatile uint32_t*)0x28000000+hart*64;
    uint32_t c[8],d[8];for(unsigned i=0;i<8;++i)c[i]=(hart+1)*16+i;
    legacy_tile<9,8>(0x80808080,0x02020202,c,d);for(unsigned i=0;i<8;++i)out[i]=d[i];
    legacy_tile<10,8>(0xffffffff,0xffffffff,c,d);for(unsigned i=0;i<8;++i)out[8+i]=d[i];
    legacy_tile<11,8>(0x88888888,0x77777777,c,d);for(unsigned i=0;i<8;++i)out[16+i]=d[i];
    legacy_tile<12,8>(0xffffffff,0xffffffff,c,d);for(unsigned i=0;i<8;++i)out[24+i]=d[i];
    for(unsigned i=0;i<8;++i)c[i]=0;
    legacy_tile<1,0>(0x3c003c00,0x3c003c00,c,d);for(unsigned i=0;i<8;++i)out[32+i]=d[i];
    legacy_tile<2,0>(0x3f803f80,0x3f803f80,c,d);for(unsigned i=0;i<8;++i)out[40+i]=d[i];
    fpu_values(hart,d);for(unsigned i=0;i<8;++i)out[48+i]=d[i];
    int core=hart/16,warp=(hart/4)%4,lane=hart%4;
    out[56]=tex((lane-1)*65536,(core+warp-1)*65536);
    out[57]=tex(lane*65536+32768,32768);
    out[58]=tex(-32769,4*65536);
    out[59]=tex(2*65536+16384,65536+16384);
    vx_fence();
}
static void compat_kernel(PairJob* __UNIFORM__ job) {
    unsigned core=vx_core_id(),warp=vx_warp_id(),lane=vx_thread_id(),hart=vx_hart_id();
    volatile uint32_t probe[4];probe[0]=0xa1000000|hart;tls_identity=0xb2000000|hart;
    uint32_t sp,tp;__asm__ volatile("mv %0,sp":"=r"(sp));__asm__ volatile("mv %0,tp":"=r"(tp));
    volatile uint32_t* id=(volatile uint32_t*)job->identities+hart*16;
    id[0]=core;id[1]=warp;id[2]=lane;id[3]=hart;id[4]=sp;id[5]=tp;id[6]=(uint32_t)&probe[0];id[7]=(uint32_t)&tls_identity;id[8]=probe[0];id[9]=tls_identity;
    __syncthreads();uint32_t error=0;
    if(warp==0) {
        volatile uint32_t* out=(volatile uint32_t*)job->outputs+core*1024;
        uint64_t start=cycles();error=execute(job,out);vx_fence();uint64_t end=cycles();
        if(lane==0)((volatile uint64_t*)job->timings)[core*32]=end-start;
        vx_barrier(1,1);
        if(lane==0 && !error) {
            uint32_t local[2][96];int64_t results[128];
            for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<96;++i)local[bank][i]=out[bank*96+i];
            s8x2_unpack48(local,results);
            for(unsigned i=0;i<128;++i)((volatile int64_t*)(out+256))[i]=results[i];
        }
    }
    // Warp1..3 start the compatibility stream while warp0 executes native S8.
    // Actual overlap, completion and metadata are checked from the RTL trace.
    compatibility(hart);
    ((volatile uint32_t*)job->statuses)[hart]=error;vx_fence();__syncthreads();
}
int main() {
    PairJob* __UNIFORM__ job=(PairJob*)csr_read(VX_CSR_MSCRATCH);
    if(job->magic!=kPairJobMagic || job->version!=1 || job->reserved || job->reserved2 ||
       !s8x2_valid_shape(job->m,job->n,job->k) || job->k>64 || job->pair_mode>1 || job->repeats!=1) {
        ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=0xbadab102;vx_fence();return 1;
    }
    uint32_t grid=4,block=16;int rc=vx_spawn_threads(1,&grid,&block,(vx_kernel_func_cb)compat_kernel,job);
    ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=rc;vx_fence();return rc;
}
