#include "vx_tcu_s8_pair.h"
#include "vx_tcu_s8.h"
extern "C" __attribute__((noinline,used)) uint32_t pair_probe(uint32_t k,uint32_t a,uint32_t b,uint32_t a1,uint32_t page) {
    uint32_t status=s8x2_begin(k);s8x2_step(a,b,a1);return s8x2_read(page)^status;
}
extern "C" __attribute__((noinline,used)) uint32_t single_probe(uint32_t k,uint32_t a,uint32_t b,uint32_t page) {
    uint32_t status=s8_begin(k);s8_step(a,b);return s8_read(page)^status;
}
