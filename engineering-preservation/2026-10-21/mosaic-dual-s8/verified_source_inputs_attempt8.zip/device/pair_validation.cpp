#include <vx_spawn.h>
#include <vx_intrinsics.h>
#include "pair_job.h"
#include "vx_tcu_s8_pair.h"
#include "vx_tcu_s8.h"

static __thread volatile uint32_t tls_identity;
static inline uint32_t broadcast(uint32_t value,int lane) {return vx_shfl_idx(value,lane,3,0);}
static inline uint64_t cycles() {
    uint32_t hi,lo,again;do {hi=csr_read(VX_CSR_MCYCLE_H);lo=csr_read(VX_CSR_MCYCLE);again=csr_read(VX_CSR_MCYCLE_H);}while(hi!=again);
    return ((uint64_t)hi<<32)|lo;
}
static uint32_t execute(PairJob* __UNIFORM__ job,volatile uint32_t* words) {
    const unsigned lane=vx_thread_id(),core=vx_core_id(),k=job->k,m=job->m,n=job->n;
    const int16_t* a0=(const int16_t*)job->a0;const int16_t* a1=(const int16_t*)job->a1;const int16_t* b=(const int16_t*)job->b;
    const bool paired=job->pair_mode!=0;
    for(unsigned pass=0;pass<(paired?1u:2u);++pass) {
        uint32_t s=paired?s8x2_begin(lane?0:k):s8_begin(lane?0:k);
        if(broadcast(s,0))return 0xe001;
        for(unsigned t=0;t<k;++t) {
            unsigned row=lane*2,col=lane*2;
            const int16_t* ax=pass?a1:a0;
            int16_t x0=row+(pass?8:0)<m?ax[(core*8+row)*k+t]:0;
            int16_t x1=row+1+(pass?8:0)<m?ax[(core*8+row+1)*k+t]:0;
            int16_t y0=col<n?b[(core*k+t)*8+col]:0,y1=col+1<n?b[(core*k+t)*8+col+1]:0;
            uint32_t x=s8x2_pack16(x0,x1),y=s8x2_pack16(y0,y1);
            if(paired) {
                int16_t z0=row+8<m?a1[(core*8+row)*k+t]:0,z1=row+9<m?a1[(core*8+row+1)*k+t]:0;
                s8x2_step(x,y,s8x2_pack16(z0,z1));
            } else s8_step(x,y);
        }
        unsigned tries=0;
        do {
            s=paired?s8x2_read(lane?0:31):s8_read(lane?0:31);
            if(broadcast(s,0))return 0xe002;
            if(++tries>1024)return 0xe003;
        }while(!(broadcast(s,3)&2));
        for(unsigned bank=0;bank<(paired?2u:1u);++bank)for(unsigned page=0;page<24;++page) {
            #ifdef PAIR_PAGE_OBSERVER
            PAIR_PAGE_OBSERVER();
            #endif
            uint32_t control=(bank<<5)|page;
            uint32_t value=paired?s8x2_read(lane?0:control):s8_read(lane?0:page);
            words[(paired?bank:pass)*96+page*4+lane]=value;
        }
        s=paired?s8x2_read(lane?0:31):s8_read(lane?0:31);
        if(broadcast(s,0)||broadcast(s,1)!=k||broadcast(s,2)!=k||broadcast(s,3)!=(paired?63u:7u))return 0xe004;
        s=paired?s8x2_read(lane?0:0x11f):s8_read(lane?0:0x11f);
        if(broadcast(s,0))return 0xe005;
    }
    return 0;
}
static void validate(PairJob* __UNIFORM__ job) {
    unsigned core=vx_core_id(),warp=vx_warp_id(),lane=vx_thread_id(),hart=vx_hart_id();
    volatile uint32_t probe[4];probe[0]=0xa1000000|hart;tls_identity=0xb2000000|hart;
    uint32_t sp,tp;__asm__ volatile("mv %0, sp":"=r"(sp));__asm__ volatile("mv %0, tp":"=r"(tp));
    volatile uint32_t* id=(volatile uint32_t*)job->identities+hart*16;
    id[0]=core;id[1]=warp;id[2]=lane;id[3]=hart;id[4]=sp;id[5]=tp;id[6]=(uint32_t)&probe[0];id[7]=(uint32_t)&tls_identity;id[8]=probe[0];id[9]=tls_identity;
    __syncthreads();
    if(warp==0) {
        volatile uint32_t* output=(volatile uint32_t*)job->outputs+core*1024;
        volatile uint64_t* timing=(volatile uint64_t*)job->timings+core*32;
        uint32_t error=0;
        for(unsigned repeat=0;repeat<job->repeats;++repeat) {
            uint64_t start=cycles();error=execute(job,output);vx_fence();uint64_t end=cycles();
            if(lane==0)timing[repeat]=end-start;
            if(error)break;
        }
        vx_fence();
        // Per-lane stores are complete before lane0 reconstructs the two banks.
        vx_barrier(1,1);
        if(lane==0 && !error) {
            uint32_t local[2][96];int64_t results[128];
            for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<96;++i)local[bank][i]=output[bank*96+i];
            s8x2_unpack48(local,results);
            volatile int64_t* unpacked=(volatile int64_t*)(output+256);
            for(unsigned i=0;i<128;++i)unpacked[i]=results[i];
        }
        ((volatile uint32_t*)job->statuses)[hart]=error;
    } else ((volatile uint32_t*)job->statuses)[hart]=0;
    __syncthreads();vx_fence();
}
int main() {
    PairJob* __UNIFORM__ job=(PairJob*)csr_read(VX_CSR_MSCRATCH);
    if(job->magic!=kPairJobMagic || job->version!=1 || job->reserved || job->reserved2 || !s8x2_valid_shape(job->m,job->n,job->k) || job->pair_mode>1 || !job->repeats || job->repeats>5) {
        ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=0xbadab100;vx_fence();return 1;
    }
    uint32_t grid=4,block=16;
    int rc=vx_spawn_threads(1,&grid,&block,(vx_kernel_func_cb)validate,job);
    ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=rc;vx_fence();return rc;
}
