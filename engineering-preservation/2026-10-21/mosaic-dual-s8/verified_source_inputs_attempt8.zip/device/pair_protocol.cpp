// Private simulation kernel: unchanged production driver/ABI and native words.
// Retain the original validated helpers without changing the old program.
#define main original_pair_validation_main
#include "pair_validation.cpp"
#undef main

static void protocol(PairJob* __UNIFORM__ job) {
    const unsigned core=vx_core_id(),warp=vx_warp_id(),lane=vx_thread_id(),hart=vx_hart_id();
    volatile uint32_t probe[4];probe[0]=0xa1000000|hart;tls_identity=0xb2000000|hart;
    uint32_t sp,tp;__asm__ volatile("mv %0, sp":"=r"(sp));__asm__ volatile("mv %0, tp":"=r"(tp));
    volatile uint32_t* id=(volatile uint32_t*)job->identities+hart*16;
    id[0]=core;id[1]=warp;id[2]=lane;id[3]=hart;id[4]=sp;id[5]=tp;id[6]=(uint32_t)&probe[0];id[7]=(uint32_t)&tls_identity;id[8]=probe[0];id[9]=tls_identity;
    volatile uint32_t* trace=(volatile uint32_t*)0x28000000+core*256;
    uint32_t error=0;
    __syncthreads();
    for(unsigned phase=0;phase<4;++phase) {
        const bool paired=phase&1;
        volatile uint32_t* out=(volatile uint32_t*)job->outputs+core*4096+phase*1024;
        uint64_t start=0;
        if(warp==0)start=cycles();
        for(unsigned pass=0;pass<(paired?1u:2u);++pass) {
            uint32_t s=0;
            if(warp==0) {
                s=paired?s8x2_begin(lane?0:job->k):s8_begin(lane?0:job->k);
                if(lane==0)trace[32+phase*4+pass]=s;
                if(broadcast(s,0))error=0xe101;
            }
            // All four warps reach both barriers. Warp0 holds the context while
            // warp1..3 exercise real decoded requests and returned statuses.
            __syncthreads();
            if(phase==1 && pass==0 && warp!=0) {
                uint32_t q=s8x2_begin(lane?0:job->k);
                if(lane==0)trace[warp*8]=q;
                if(broadcast(q,0)!=1)error=0xe111;
                q=s8x2_read(lane?0:31);
                if(lane==0)trace[warp*8+1]=q;
                if(broadcast(q,0)!=1 || broadcast(q,1)||broadcast(q,2)||broadcast(q,3))error=0xe112;
                s8x2_step(0x80007fff,0x7fff8000,0xffff0001);
                q=s8x2_read(lane?0:31);
                if(lane==0)trace[warp*8+2]=q;
                if(broadcast(q,0)!=3 || broadcast(q,1)||broadcast(q,2)||broadcast(q,3))error=0xe113;
                q=s8x2_read(0);
                if(lane==0)trace[warp*8+3]=q;
                if(q!=0)error=0xe114;
                q=s8x2_read(lane?0:31);
                if(lane==0)trace[warp*8+4]=q;
                if(broadcast(q,0)!=3 || broadcast(q,1)||broadcast(q,2)||broadcast(q,3))error=0xe115;
                q=s8x2_read(lane?0:0x11f);
                if(lane==0)trace[warp*8+5]=q;
                if(broadcast(q,0)!=3 || broadcast(q,1)||broadcast(q,2)||broadcast(q,3))error=0xe116;
            }
            __syncthreads();
            if(warp==0) {
                const int16_t* a0=(const int16_t*)job->a0;
                const int16_t* a1=(const int16_t*)job->a1;
                const int16_t* b=(const int16_t*)job->b;
                // Bounded per-core skew exercises independent core progress.
                for(unsigned delay=0;delay<core*7;++delay)__asm__ volatile("nop");
                for(unsigned t=0;t<job->k;++t) {
                    unsigned row=lane*2,col=lane*2;
                    const int16_t* ax=pass?a1:a0;
                    int16_t x0=row+(pass?8:0)<job->m?ax[(core*8+row)*job->k+t]:0;
                    int16_t x1=row+1+(pass?8:0)<job->m?ax[(core*8+row+1)*job->k+t]:0;
                    int16_t y0=col<job->n?b[(core*job->k+t)*8+col]:0;
                    int16_t y1=col+1<job->n?b[(core*job->k+t)*8+col+1]:0;
                    if(paired) {
                        int16_t z0=row+8<job->m?a1[(core*8+row)*job->k+t]:0;
                        int16_t z1=row+9<job->m?a1[(core*8+row+1)*job->k+t]:0;
                        s8x2_step(s8x2_pack16(x0,x1),s8x2_pack16(y0,y1),s8x2_pack16(z0,z1));
                    } else s8_step(s8x2_pack16(x0,x1),s8x2_pack16(y0,y1));
                }
                unsigned tries=0;
                do {
                    s=paired?s8x2_read(lane?0:31):s8_read(lane?0:31);
                    if(broadcast(s,0)!=0 && broadcast(s,0)!=4){error=0xe121;break;}
                    if(++tries>1024){error=0xe122;break;}
                }while(!(broadcast(s,3)&2));
                for(unsigned bank=0;bank<(paired?2u:1u);++bank)for(unsigned page=0;page<24;++page) {
                    uint32_t value=paired?s8x2_read(lane?0:(bank<<5)|page):s8_read(lane?0:page);
                    out[(paired?bank:pass)*96+page*4+lane]=value;
                }
                s=paired?s8x2_read(lane?0:31):s8_read(lane?0:31);
                if(broadcast(s,0)||broadcast(s,1)!=job->k||broadcast(s,2)!=job->k||broadcast(s,3)!=(paired?63u:7u))error=0xe123;
                s=paired?s8x2_read(lane?0:0x11f):s8_read(lane?0:0x11f);
                if(lane==0)trace[32+phase*4+2+pass]=s;
                if(broadcast(s,0))error=0xe124;
            }
            __syncthreads();
        }
        if(warp==0) {
            vx_fence();uint64_t end=cycles();
            if(lane==0)((volatile uint64_t*)job->timings)[core*32+phase]=end-start;
            vx_barrier(1,1);
            if(lane==0) {
                uint32_t local[2][96];int64_t results[128];
                for(unsigned bank=0;bank<2;++bank)for(unsigned i=0;i<96;++i)local[bank][i]=out[bank*96+i];
                s8x2_unpack48(local,results);
                for(unsigned i=0;i<128;++i)((volatile int64_t*)(out+256))[i]=results[i];
            }
        }
        __syncthreads();
    }
    ((volatile uint32_t*)job->statuses)[hart]=error;
    vx_fence();__syncthreads();
}

int main() {
    PairJob* __UNIFORM__ job=(PairJob*)csr_read(VX_CSR_MSCRATCH);
    if(job->magic!=kPairJobMagic || job->version!=1 || job->reserved || job->reserved2 ||
       !s8x2_valid_shape(job->m,job->n,job->k) || job->k>64 || job->pair_mode!=1 || job->repeats!=1) {
        ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=0xbadab101;vx_fence();return 1;
    }
    uint32_t grid=4,block=16;
    int rc=vx_spawn_threads(1,&grid,&block,(vx_kernel_func_cb)protocol,job);
    ((volatile uint32_t*)job->statuses)[64+vx_core_id()]=rc;vx_fence();return rc;
}
