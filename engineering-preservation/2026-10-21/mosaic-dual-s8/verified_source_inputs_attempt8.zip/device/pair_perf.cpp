// Same arithmetic/load/page-read path, job.repeats supplies up to5 raw samples.
// These are full device intervals. Register-resident microtiming is separate.
#define PAIR_PERFORMANCE 1
#include "pair_validation.cpp"
