#ifndef VX_TCU_S8_H
#define VX_TCU_S8_H
#include <stdint.h>
// Pure representation conversion. Every value occupies 48 little-endian bits.
static inline void s8_unpack48(const uint32_t words[96], int64_t out[64]) {
    for (unsigned i=0;i<64;++i) {
        unsigned bit=48*i,word=bit/32,shift=bit%32;
        uint64_t pair=uint64_t(words[word])|(uint64_t(words[word+1])<<32);
        uint64_t raw=(pair>>shift)&UINT64_C(0xffffffffffff);
        out[i]=(raw&(UINT64_C(1)<<47))?int64_t(raw)-(INT64_C(1)<<48):int64_t(raw);
    }
}
#if defined(__riscv) && (__riscv_xlen == 32)
// Fixed floating registers match the frozen TCU uops. All participants in the
// full four-lane warp must call these functions in the same order.
static inline uint32_t s8_begin(uint32_t control_lane_word) {
    uint32_t result;
    __asm__ volatile("fmv.w.x f10, %1\n\t.insn r 0x0b, 0, 2, x8, x13, x0\n\tfmv.x.w %0, f10"
        : "=r"(result) : "r"(control_lane_word) : "f10","memory");
    return result;
}
static inline void s8_step(uint32_t a_pair,uint32_t b_pair) {
    __asm__ volatile("fmv.w.x f0, %0\n\tfmv.w.x f28, %1\n\t.insn r 0x0b, 0, 2, x8, x14, x0"
        : : "r"(a_pair),"r"(b_pair) : "f0","f28","memory");
}
static inline uint32_t s8_read(uint32_t control_lane_word) {
    uint32_t result;
    __asm__ volatile("fmv.w.x f10, %1\n\t.insn r 0x0b, 0, 2, x8, x15, x0\n\tfmv.x.w %0, f10"
        : "=r"(result) : "r"(control_lane_word) : "f10","memory");
    return result;
}
#endif
#endif
