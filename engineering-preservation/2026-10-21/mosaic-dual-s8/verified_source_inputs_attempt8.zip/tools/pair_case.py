"""Private GPU32 validation job, exact four-core inputs/outputs and guards."""
import argparse,random,struct
from pathlib import Path
from tools.evidence import save,sha,utc
from tools.pair_layout import valid_shape,padded_operands,pack48
from tools.pair_oracle import pair_reference
from tools.gpu_runtime_budget import runtime_budget

GPU=dict(job=0x20000000,a0=0x21000000,a1=0x22000000,b=0x23000000,outputs=0x24000000,statuses=0x25000000,identities=0x26000000,timings=0x27000000)
def make_case(output,k,m=16,n=8,seed=20261018,paired=True,repeats=1):
    if not valid_shape(m,n,k) or repeats not in range(1,6):raise ValueError('shape/K/repeats outside frozen private job contract')
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    rng=random.Random(seed);a0_bytes=bytearray();a1_bytes=bytearray();b_bytes=bytearray();cores=[]
    for core in range(4):
        a=[[rng.choice([-32768,-32767,-1,0,1,32766,32767]) for _ in range(k)] for _ in range(m)]
        b=[[rng.choice([-32768,-3,-1,0,1,11,32767]) for _ in range(n)] for _ in range(k)]
        a,b=padded_operands(a,b,m,n,k)
        expected=pair_reference(a[:8],a[8:],b)
        for target,matrix in [(a0_bytes,a[:8]),(a1_bytes,a[8:]),(b_bytes,b)]:
            for row in matrix:
                for value in row:target.extend(struct.pack('<h',value))
        cores.append(dict(core=core,owner_warp=0,expected128=expected,expected_bank_words=pack48(expected),expected_accepted_steps=(k if paired else 2*k)*repeats,expected_begin=(1 if paired else 2)*repeats,expected_data_reads=48*repeats,expected_release=(1 if paired else 2)*repeats,raw_offset=4096*core,unpacked_offset=4096*core+1024))
    blobs=dict(a0=a0_bytes,a1=a1_bytes,b=b_bytes)
    blobs['job']=struct.pack('<16I',0x53385832,1,k,m,n,int(paired),repeats,0,*[GPU[key] for key in ['a0','a1','b','outputs','statuses','identities','timings']],0)
    inputs=[]
    for name,data in blobs.items():
        path=output/(name+'.bin');path.write_bytes(data);inputs.append(dict(name=name,gpu_base=GPU[name],path=path.name,bytes=len(data),sha256=sha(path),permissions='r'))
    regions=[dict(name='outputs',gpu_base=GPU['outputs'],bytes=4*4096,fill_byte=0xa5),dict(name='statuses',gpu_base=GPU['statuses'],bytes=68*4,fill_byte=0xa5),dict(name='identities',gpu_base=GPU['identities'],bytes=64*64,fill_byte=0xa5),dict(name='timings',gpu_base=GPU['timings'],bytes=4*32*8,fill_byte=0xa5)]
    case=dict(schema_version=1,utc=utc(),case_id=f"{'pair' if paired else 'two_single'}_m{m}_n{n}_k{k}_seed{seed}",K=k,M=m,N=n,seed=seed,paired=paired,repeats=repeats,cores=cores,inputs=inputs,regions=regions,guards=dict(fill_byte=0xa5,output_intervals_written_per_core=[[0,768],[1024,2048]],identity_words_written_per_hart=list(range(10)),timing_slots_written_per_core=list(range(repeats))),expected_harts=64,source='independent integer oracle; expected data only, not GPU execution evidence')
    case['runtime_budget']=runtime_budget(k,repeats,paired)
    save(output/'case.json',case);return case

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--k',type=int,required=True);ap.add_argument('--m',type=int,default=16);ap.add_argument('--n',type=int,default=8);a=ap.parse_args();print(make_case(a.output,a.k,a.m,a.n)['case_id'])
