"""A-only fresh RV32 CRT and pair ELF build; no device or driver execution."""
import argparse,datetime,getpass,json,os,platform,shutil,subprocess,sys,time,math
from pathlib import Path
if __package__ in (None,''):sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tools.evidence import ROOT,load,save,sha,utc,input_identity,archive_inputs

TOOLS=Path('/home/z2euss/vortex-tools')
def fresh_gate_round_trip(decision,elapsed):
    return decision.get('launch_permitted') is True and isinstance(elapsed,(int,float)) and math.isfinite(elapsed) and 0<=elapsed<60
def wsl_path(p):
    p=Path(p).resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]

def worker(run):
    from tools.device_recipe import build_recipe,runtime_recipe,linux_command
    if os.name=='nt' or platform.node().lower()!='ry' or os.getuid()!=1000:raise ValueError('requires A/RY WSL uid1000')
    run=Path(run).resolve()
    if run.parent!=ROOT/'runs':raise ValueError('build outside candidate runs')
    request=load(run/'build_request.json');sdk=run/'sdk';shutil.copytree(ROOT/'inputs/sdk',sdk)
    rows=load(ROOT/'evidence/pair_sdk_subset_manifest.json')['files']
    for row in rows:
        if sha(sdk/row['path'])!=row['sha256']:raise ValueError('SDK copy drift')
    def command(args,name):return linux_command(args,run,run,name)
    def gate(name):
        # Query Windows memory AND the now-active A WSL. Own compiler has exited
        # before each next gate. This never queries B or controls other jobs.
        code="import os,sys;os.chdir(sys.argv[1]);from tools.resource_gate import resource_gate,launch_decision;from tools.evidence import save,load;g=resource_gate(sys.argv[3]);a=load(sys.argv[4]) if sys.argv[4] else None;g['launch_decision']=launch_decision(g,'device_build',a);save(sys.argv[2],g);print(g['launch_decision']['admission']);sys.exit(0 if g['launch_decision']['launch_permitted'] else 2)"
        if (run/(name+'.json')).exists():raise ValueError('fresh gate path already exists')
        started=time.monotonic()
        command([request['linux_windows_python'],'-c',code,request['windows_root'],request['windows_run']+'/'+name+'.json',name,request.get('memory_override_relative','')],name)
        elapsed=time.monotonic()-started
        current=load(run/(name+'.json'))
        current['worker_freshness']=dict(monotonic_round_trip_seconds=elapsed,cross_os_utc_delta_seconds=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(current['utc'])).total_seconds(),proof='new exclusive run path and this actual command, not cross-OS UTC equality')
        save(run/(name+'.json'),current)
        if not fresh_gate_round_trip(current['launch_decision'],elapsed):raise ValueError('fresh gate refused/unknown')
    for name in ['VX_config','VX_types']:
        command([sys.executable,sdk/'hw/scripts/gen_config.py','-i',ROOT/'candidate/build/compat_rtl'/(name+'.vh'),'-o',sdk/'hw'/(name+'.h')],'generate_'+name)
    bins=TOOLS/'llvm-vortex/bin';gcc=TOOLS/'riscv32-gnu-toolchain/bin'
    toolpaths=[bins/'clang',bins/'clang++',bins/'llvm-objdump',gcc/'riscv32-unknown-elf-gcc',gcc/'riscv32-unknown-elf-gcc-ar',gcc/'riscv32-unknown-elf-ld',Path('/usr/bin/g++')]
    libs=[TOOLS/'libc32/lib/libm.a',TOOLS/'libc32/lib/libc.a',TOOLS/'libcrt32/lib/baremetal/libclang_rt.builtins-riscv32.a']
    tool_identity={str(p):sha(p) for p in toolpaths+libs}
    if sha(bins/'clang')!='a4bc2f4bd028059d875dd8238befd075251d8727b240ff59c6655ddb383330c5':raise ValueError('frozen Vortex Clang18.1.7 differs')
    save(run/'linux_tool_inputs.json',tool_identity)
    command([bins/'clang++','--version'],'clang_version');command([gcc/'riscv32-unknown-elf-gcc','--version'],'gcc_version')
    gate('post_wsl_host_test_gate')
    command(['/usr/bin/g++','-std=c++17','-O2','-fsanitize=undefined,bounds','-I'+str(ROOT/'device'),ROOT/'device/pair_unpack_host_test.cpp','-o',run/'pair_unpack_host_test'],'host_header_compile')
    command([run/'pair_unpack_host_test'],'host_header_run')
    runtime=runtime_recipe(sdk,TOOLS);objects=[]
    for i,name in enumerate(runtime['kernel_sources']):
        gate('runtime_gate_'+str(i));obj=run/(name+'.o');objects.append(obj)
        command([runtime['compiler'],*runtime['flags'],'-c',sdk/'kernel/src'/name,'-o',obj],'runtime_'+str(i))
    archive=run/'libvortex.a';command([runtime['archiver'],'rcs',archive,*objects],'archive_runtime')
    recipe=build_recipe(sdk,TOOLS,0x80000000)
    flags=recipe['flags']+['-fno-rtti','-std=c++17','-I'+str(ROOT/'device'),'-I'+str(ROOT/'reference/device')]
    outputs=[]
    for program in ['pair_encoding_probe','pair_validation','pair_perf','pair_protocol','pair_compat','pair_backpressure']:
        gate(program+'_compile_gate');obj=run/(program+'.o')
        command([bins/'clang++',*flags,'-c',ROOT/'device'/(program+'.cpp'),'-o',obj],program+'_compile')
        command([bins/'llvm-objdump','-d',obj],program+'_object_disassembly')
        if program=='pair_encoding_probe':continue
        gate(program+'_link_gate');elf=run/(program+'.elf')
        command([gcc/'riscv32-unknown-elf-ld','-Bstatic','--gc-sections','-T',sdk/'kernel/scripts/link32.ld','--defsym=STARTUP_ADDR=0x80000000','-Map',run/(program+'.map'),'-o',elf,obj,archive,'--start-group',*libs,'--end-group'],program+'_link')
        command([bins/'llvm-objdump','-d',elf],program+'_disassembly')
        outputs.append(dict(program=program,elf=elf.name,sha256=sha(elf)))
    after_tools={str(p):sha(p) for p in toolpaths+libs};save(run/'linux_tool_inputs_after.json',after_tools)
    if after_tools!=tool_identity:raise ValueError('Linux tool/library drift')
    save(run/'worker_manifest.json',dict(utc=utc(),status='TOOL_COMPLETE',host=platform.node(),uid=os.getuid(),outputs=outputs,tool_inputs=tool_identity,scope='actual host header execution and RV32 build, no GPU execution'))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--worker',action='store_true');ap.add_argument('--run',type=Path);ap.add_argument('--memory-override',type=Path);args=ap.parse_args()
    if args.worker:worker(args.run);return 0
    from tools.resource_gate import resource_gate,launch_decision
    from tools.process_runner import run_preserving
    if os.name!='nt' or platform.node().lower()!='ry' or getpass.getuser()!='13151':raise ValueError('requires A Windows launcher')
    state=load(ROOT/'evidence/system_state.json')
    if state.get('active_run') or state['mode']=='awaiting_independent_acceptance':raise ValueError('active/unaccepted run exists')
    run=ROOT/'runs'/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'_device_pair');run.mkdir()
    auth_path=args.memory_override.resolve() if args.memory_override else None
    if auth_path and not auth_path.is_relative_to(ROOT/'evidence'):raise ValueError('exception receipt outside own evidence')
    auth=load(auth_path) if auth_path else None
    if auth_path:save(run/'memory_override.json',auth)
    g=resource_gate('pair_device_build');g['launch_decision']=launch_decision(g,'device_build',auth);save(run/'preflight.json',g)
    if not g['launch_decision']['launch_permitted']:
        state.update(utc=utc(),mode='resource_refused',monitor='PAUSED',active_run=None,resource=g,blocked_run=str(run));save(ROOT/'evidence/system_state.json',state);print(json.dumps(g));return 2
    before=input_identity();save(run/'inputs_before.json',before);archive_inputs(ROOT,before,run/'verified_source_inputs.zip')
    save(run/'build_request.json',dict(windows_root=ROOT.as_posix(),windows_run=run.as_posix(),linux_windows_python=wsl_path(sys.executable),memory_override_relative=(run/'memory_override.json').relative_to(ROOT).as_posix() if auth_path else '',memory_override_sha256=sha(run/'memory_override.json') if auth_path else None))
    cmd=['wsl.exe','-d','Ubuntu-24.04','--exec','python3',wsl_path(Path(__file__)),'--worker','--run',wsl_path(run)]
    state.update(utc=utc(),mode='active',active_run=str(run),stage='device_build',monitor='PAUSED',command=cmd,cwd=str(ROOT));save(ROOT/'evidence/system_state.json',state)
    exit=run_preserving(cmd,cwd=ROOT,log_path=run/'wsl.log',events_path=run/'wsl.events.jsonl',poll_seconds=.1);save(run/'wsl_exit.json',exit)
    after=input_identity();save(run/'inputs_after.json',after)
    complete=exit['exit_code']==0 and before==after and (run/'worker_manifest.json').is_file()
    gate_files=[p for p in run.glob('*gate*.json') if not p.name.endswith(('.exit.json','.started.json'))]
    refused=[load(p) for p in gate_files if load(p).get('status') in ['REFUSED','UNKNOWN'] and not load(p).get('launch_decision',{}).get('launch_permitted')]
    save(run/'product_manifest.json',{p.relative_to(run).as_posix():sha(p) for p in run.rglob('*') if p.is_file()})
    state.update(utc=utc(),mode='awaiting_device_admission' if complete else 'resource_refused' if refused else 'device_failed',active_run=None,monitor='PAUSED',last_run=str(run))
    if refused:state.update(resource=refused[-1],blocked_run=str(run))
    save(ROOT/'evidence/system_state.json',state)
    print(json.dumps(dict(run=str(run),status=state['mode'])));return 0 if complete else 1

if __name__=='__main__':raise SystemExit(main())
