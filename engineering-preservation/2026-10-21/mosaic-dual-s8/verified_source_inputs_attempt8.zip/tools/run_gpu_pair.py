"""One explicit independent actual-GPU ELF/case invocation."""
import argparse,datetime,subprocess,sys
from tools.evidence import ROOT,load,save
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--variant',choices=['baseline','candidate'],required=True);ap.add_argument('--suite',choices=['legacy','pair','protocol','compat','mixed','reopen','backpressure'],required=True);ap.add_argument('--k',type=int,default=1);ap.add_argument('--m',type=int,default=16);ap.add_argument('--n',type=int,default=8);ap.add_argument('--seed',type=int,default=20261019);ap.add_argument('--repeats',type=int,default=1);ap.add_argument('--memory-override');a=ap.parse_args()
    state=load(ROOT/'evidence/system_state.json')
    if a.variant=='baseline' and a.suite not in ['legacy','compat']:raise ValueError('baseline cannot execute pair mode')
    if a.suite in ['protocol','compat','mixed','reopen','backpressure'] and (not 1<=a.k<=64 or a.repeats!=1):raise ValueError('directed protocol/compatibility bounded K1..64/repeats1')
    paired=a.suite in ['pair','protocol','mixed','reopen','backpressure']
    request=dict(variant=a.variant,paired=paired,k=a.k,m=a.m,n=a.n,seed=a.seed,repeats=a.repeats,device_receipt=state['accepted_device_receipt'],scope='one real four-core CRT/two-single or paired native case; actual compatibility only when explicit profile is bound')
    if a.suite=='protocol':request['profile']='owner_modes_v1'
    if a.suite in ['compat','mixed']:request['profile']='legacy_fpu_tex_v1'
    if a.suite=='reopen':request['profile']='reset_reopen_v1'
    if a.suite=='backpressure':request['profile']='dualbank_backpressure_v1'
    path=ROOT/'evidence'/('gpu_request_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json');save(path,request)
    command=[sys.executable,'-m','tools.run_stage','--stage','gpu_'+('pair' if paired else 'legacy'),'--variant',a.variant,'--case-request',str(path)]
    if a.memory_override:command+=['--memory-override',a.memory_override]
    return subprocess.run(command,cwd=ROOT).returncode
if __name__=='__main__':raise SystemExit(main())
