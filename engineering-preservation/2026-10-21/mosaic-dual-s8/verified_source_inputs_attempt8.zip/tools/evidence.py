"""Small path/hash primitives. No tool launch on import."""
import datetime
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def save(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def archive_inputs(root,identity,archive):
    # Pre-read/verify every source before opening an exclusive immutable archive.
    rows=[]
    for rel,expected in identity['files'].items():
        p=bound(root,rel);data=p.read_bytes()
        if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('source changed before archive: '+rel)
        rows.append((rel,data))
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for rel,data in rows:z.writestr(rel,data)
    return sha(archive)

def bound(root, relative):
    result=(Path(root)/relative).resolve()
    if not result.is_relative_to(Path(root).resolve()):raise ValueError('path escaped root')
    return result

def input_identity(root=ROOT):
    root=Path(root)
    files={}
    for folder in ['candidate','tools','tb','device','flow','config','inputs','reference']:
        if not (root/folder).exists():continue
        for p in (root/folder).rglob('*'):
            rel=p.relative_to(root).as_posix()
            if not p.is_file() or '__pycache__' in p.parts:continue
            if rel.startswith(('candidate/build/vivado/','candidate/build/artifacts/')):continue
            files[rel]=sha(p)
    files['docs/planning_contract.json']=sha(root/'docs/planning_contract.json')
    files['reference/device/vx_tcu_s8.h']=sha(root/'reference/device/vx_tcu_s8.h')
    digest=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'files':files,'sha256':digest}
