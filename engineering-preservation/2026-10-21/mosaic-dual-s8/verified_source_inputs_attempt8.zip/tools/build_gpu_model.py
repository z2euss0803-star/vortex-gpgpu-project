"""Freshly compile/elaborate actual W4 GPU with source-bound physical IP HDL."""
import hashlib,zipfile
from pathlib import Path
from tools.evidence import load,save,sha
from tools.elf_image import elf_image,read_elf
from tools.memory_layout import gpu_to_hp
from tools.pair_case import make_case
from tools.vivado_runtime import runtime_env

def admit_device_inputs(root,receipt,program='pair_validation'):
    receipt=Path(receipt).resolve()
    if not receipt.is_relative_to(root/'evidence'):raise ValueError('device admission outside own root')
    accepted=load(receipt);run=Path(accepted['run'])
    if accepted['status']!='PASS':raise ValueError('device not independently accepted')
    for rel,h in load(run/'product_manifest.json').items():
        if sha(run/rel)!=h:raise ValueError('device product drift '+rel)
    original=load(run/'inputs_before.json')['files']
    with zipfile.ZipFile(run/'verified_source_inputs.zip') as z:
        for rel,h in original.items():
            if hashlib.sha256(z.read(rel)).hexdigest()!=h:raise ValueError('original compiled input archive drift')
            if rel.startswith(('device/','inputs/sdk/')) or rel in ['reference/device/vx_tcu_s8.h','candidate/build/compat_rtl/VX_config.vh','candidate/build/compat_rtl/VX_types.vh','tools/device_recipe.py']:
                if sha(root/rel)!=h:raise ValueError('compiled device source/config drift '+rel)
    if program not in ['pair_validation','pair_protocol','pair_compat','pair_backpressure']:raise ValueError('unsupported actual GPU program')
    row=next(x for x in accepted['outputs'] if x['program']==program);elf=run/row['elf']
    if sha(elf)!=row['sha256']:raise ValueError('accepted ELF drift')
    return elf,accepted

def prepare_gpu(root,run,variant,stage):
    request=load(run/'gpu_request.json')
    protocol=request.get('profile')=='owner_modes_v1'
    compat=request.get('profile')=='legacy_fpu_tex_v1'
    reopen=request.get('profile')=='reset_reopen_v1'
    bp=request.get('profile')=='dualbank_backpressure_v1'
    if request.get('profile') not in [None,'owner_modes_v1','legacy_fpu_tex_v1','reset_reopen_v1','dualbank_backpressure_v1']:raise ValueError('unknown GPU profile')
    if protocol and (variant!='candidate' or not request['paired']):raise ValueError('protocol requires paired candidate')
    if reopen and (variant!='candidate' or not request['paired'] or request['repeats']!=1 or not 1<=request['k']<=64):raise ValueError('reset reopen requires bounded paired candidate')
    if bp and (variant!='candidate' or not request['paired'] or request['repeats']!=1):raise ValueError('backpressure requires paired candidate')
    elf,device=admit_device_inputs(root,request['device_receipt'],'pair_protocol' if protocol else 'pair_compat' if compat else 'pair_backpressure' if bp else 'pair_validation')
    request.update(elf=str(elf),device_receipt_sha256=sha(request['device_receipt']));save(run/'gpu_request.json',request)
    if variant=='baseline' and request['paired']:raise ValueError('baseline cannot execute new mode')
    for key in ['accepted_ddr_run','accepted_reset_run']:
        accepted=Path(load(root/'evidence/system_state.json')[key]);a=load(accepted/'independent_admission.json')
        if a['status']!='PASS':raise ValueError('external model/checker admission missing')
        for rel in (['tb/axi_ddr_model.sv','tb/tb_axi_ddr_model.sv'] if key=='accepted_ddr_run' else ['tb/verification_overlay/VX_pending_size.sv','tb/tb_reset_guard.sv']):
            if sha(root/rel)!=load(accepted/'inputs_before.json')['files'][rel]:raise ValueError('admitted model input changed '+rel)
        save(run/(key+'.json'),dict(receipt=str(accepted/'independent_admission.json'),sha256=sha(accepted/'independent_admission.json')))
    case=make_case(run/'case',request['k'],request['m'],request['n'],request['seed'],request['paired'],request['repeats'])
    if protocol:
        from tools.gpu_protocol import extend_case
        case=extend_case(case,run/'case')
    if compat:
        from tools.gpu_compat import extend_case
        case=extend_case(case,run/'case')
    if bp:
        from tools.gpu_backpressure import extend_case,alu_burst_range
        case=extend_case(case,run/'case')
        start,end=alu_burst_range(elf)
        case['alu_burst_pc_begin']=start;case['alu_burst_pc_end']=end
        (run/'gpu_bp_alu_pc.txt').write_text(f'{start:x} {end:x}\n')
        save(run/'case/case.json',case)
    if reopen:
        from tools.gpu_reopen import PROFILE,epoch_budget
        save(run/'case/epoch_0/case.json',case)
        second=make_case(run/'case/epoch_1',request['k'],request['m'],request['n'],request['seed']+1,True,1)
        case.update(profile=PROFILE,reopen_epochs=2,
                    epoch_case_sha256=[sha(run/f'case/epoch_{e}/case.json') for e in range(2)],
                    runtime_budget=epoch_budget(request['k']),case_id='reset_reopen_'+case['case_id'])
        save(run/'case/case.json',case)
    budget=case['runtime_budget']
    (run/'gpu_runtime_budget.txt').write_text(f"{budget['watchdog_cycles']} {budget['host_limit_cycles']} {budget['global_timeout_ns']}\n")
    regions=[dict(name=x['name'],kind='args',gpu_base=x['gpu_base'],byte_count=x['bytes'],permissions=x['permissions'],fill_byte=0) for x in case['inputs']]
    regions += [dict(name=x['name'],kind='output',gpu_base=x['gpu_base'],byte_count=x['bytes'],permissions='rw',fill_byte=x['fill_byte']) for x in case['regions']]
    regions += [dict(name='crt_io',kind='io',gpu_base=0x40,byte_count=0x440,permissions='rw',fill_byte=0),dict(name='flush',kind='flush',gpu_base=0x10030000,byte_count=64,permissions='rw',fill_byte=0)]
    # AXI fetches full64byte lines. Explicit read-only padding is separate from
    # live input/output extents and cannot turn an out-of-bounds write legal.
    for region in regions[:]:
        end=region['gpu_base']+region['byte_count'];pad=(-end)%64
        if pad:regions.append(dict(name=region['name']+'_padding',kind='prefetch_padding',gpu_base=end,byte_count=pad,permissions='r',fill_byte=0))
    layout=dict(hart_count=64,stack_base=0xffff0000,stack_bytes=8192,cache_line_bytes=64,require_crt_tls=True,regions=regions)
    save(run/'layout.json',layout);memory=load(elf_image(elf,run/'layout.json',run/'image'))
    (run/'gpu_regions.txt').write_text(''.join(f"{r['hp_base']:x} {r['byte_count']} {int(r['permissions']=='rw')} {r['fill_byte']:02x} {r['name']}\n" for r in memory['regions']))
    with (run/'gpu_load_bytes.txt').open('w') as f:
        for segment in memory['segments']:
            for i,value in enumerate(Path(segment['image_path']).read_bytes()):f.write(f"{segment['hp_base']+i:x} {value:02x}\n")
        for row in case['inputs']:
            for i,value in enumerate((run/'case'/row['path']).read_bytes()):f.write(f"{gpu_to_hp(row['gpu_base'])+i:x} {value:02x}\n")
    if reopen:
        # External memory stimulus only, after real DONE/drain and while reset.
        # Restore ELF data and fresh guards, then install different epoch inputs.
        with (run/'gpu_load_bytes_epoch_1.txt').open('w') as f:
            for segment in memory['segments']:
                for i,value in enumerate(Path(segment['image_path']).read_bytes()):f.write(f"{segment['hp_base']+i:x} {value:02x}\n")
            for row in second['regions']:
                for i in range(row['bytes']):f.write(f"{gpu_to_hp(row['gpu_base'])+i:x} {row['fill_byte']:02x}\n")
            for row in second['inputs']:
                for i,value in enumerate((run/'case/epoch_1'/row['path']).read_bytes()):f.write(f"{gpu_to_hp(row['gpu_base'])+i:x} {value:02x}\n")
    (run/'gpu_launch.txt').write_text('80000000 20000000\n')
    base=root/('candidate' if variant=='candidate' else 'reference/s8_w4');cfg=load(base/'config/build.json')
    sources=[base/p for p in cfg['sources']]
    counter=base/'build/compat_rtl/libs/VX_pending_size.sv';overlay=root/'tb/verification_overlay/VX_pending_size.sv'
    origin=load(root/'evidence/gpu_model_fixture_origins.json')['files'][-1]
    if sha(counter)!=origin['production_sha256'] or sha(overlay)!=origin['sha256']:raise ValueError('counter overlay binding mismatch')
    sources=[overlay if p==counter else p for p in sources]
    sources += [base/'rtl'/name for name in ['VX_tex_unit.sv','gpgpu_tex_sampler.sv','gpgpu_ctrl.sv','gpgpu_subsystem.sv']]
    sources += [root/'tb/axi_ddr_model.sv',root/'tb/tb_gpu_pair_system.sv',root/'tb/ip_full_usage/ctrl_axi_converter.v']
    if any(not p.is_relative_to(root) or not p.is_file() for p in sources):raise ValueError('GPU sources escaped/missing')
    toolroot=Path('G:/xilinx/Vivado/2020.1');b=toolroot/'bin/unwrapped/win64.o'
    sources += [toolroot/'data/verilog/src/glbl.v']
    includes=[root/'tb']+[base/p for p in cfg['includes']]+[base/'build/compat_rtl',base/'build/compat_rtl/interfaces',base/'build/compat_rtl/libs',base/'build/compat_rtl/core',base/'build/compat_rtl/tcu']
    defines=cfg['defines']+['SIMULATION']+(['PAIR_CANDIDATE'] if variant=='candidate' else [])
    if protocol:defines+=['PAIR_PROTOCOL']
    if compat:defines+=['PAIR_COMPAT']
    if reopen:defines+=['PAIR_REOPEN']
    if bp:defines+=['PAIR_BP']
    vlog=[str(b/'xvlog.exe'),'--sv','--relax','--work','xil_defaultlib']+sum((['-i',str(p)] for p in dict.fromkeys(includes)),[])+sum((['-d',p] for p in defines),[])+[str(p) for p in sources]
    fp=[root/'tb/ip_full_usage'/(name+'.vhd') for name in ['xil_fadd','xil_fmul','xil_fma','xil_fdiv','xil_fsqrt']]
    vhdl=[str(b/'xvhdl.exe'),'--relax','--work','xil_defaultlib']+[str(p) for p in fp]
    libs=['xbip_utils_v3_0_10','axi_utils_v2_0_6','xbip_pipe_v3_0_6','xbip_dsp48_wrapper_v3_0_4','xbip_dsp48_addsub_v3_0_6','xbip_dsp48_multadd_v3_0_6','xbip_bram18k_v3_0_6','mult_gen_v12_0_16','floating_point_v7_1_10','axi_infrastructure_v1_1_0','axi_register_slice_v2_1_21','fifo_generator_v13_2_5','axi_data_fifo_v2_1_20','axi_protocol_converter_v2_1_21','generic_baseblocks_v2_1_0','blk_mem_gen_v8_4_4','xil_defaultlib','unisims_ver','unimacro_ver','secureip','xpm']
    elab=[str(b/'xelab.exe'),'--relax','--debug','typical','--mt','4']+sum((['-L',p] for p in libs),[])+['-s','gpu_snapshot','xil_defaultlib.tb_gpu_pair_system','xil_defaultlib.glbl','-timescale','1ns/1ps']
    ini=toolroot/'data/xsim/xsim.ini';(run/'xsim.ini').write_bytes(ini.read_bytes())
    (run/'simulation.tcl').write_text('log_wave /tb_gpu_pair_system/resetn\nlog_wave /tb_gpu_pair_system/dut/gpu_busy\nlog_wave /tb_gpu_pair_system/crt_cycles\nrun all\nquit\n')
    save(run/'gpu_model_inputs.json',dict(variant=variant,source_files={str(p):sha(p) for p in sources+fp},defines=defines,axi_write_window=4,model='fresh native compile/elaboration of full W4 GPU; HPM/DDR external model'))
    files=[b/(n+'.exe') for n in ['xvlog','xvhdl','xelab','xsim']]+[ini,elf]
    mappings=dict(line.split('=',1) for line in ini.read_text().splitlines() if '=' in line and not line.startswith('#'))
    for lib in libs+['std','ieee','ieee_proposed','unisim']:
        if lib=='xil_defaultlib':continue
        if lib not in mappings:raise ValueError('vendor compiled library mapping missing '+lib)
        folder=Path(mappings[lib].replace('$RDI_DATADIR',(toolroot/'data').as_posix()))
        if not folder.is_dir():raise ValueError('vendor compiled library absent '+lib)
        files.extend(p for p in folder.rglob('*') if p.is_file())
    return [vlog,vhdl,elab,[str(b/'xsim.exe'),'gpu_snapshot','-tclbatch','simulation.tcl','-log','simulate.log']],runtime_env(toolroot,run),{str(p):sha(p) for p in files}
