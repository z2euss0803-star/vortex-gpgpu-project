"""Exact contention sums, real bank stalls and TCU metadata conservation."""
from collections import Counter,defaultdict,deque
import re
import struct
from tools.evidence import save

PROFILE='dualbank_backpressure_v1'
MAX_ITERATIONS=4096

def bp_budget(k):
    if type(k) is not int or not 1<=k<=64:raise ValueError('backpressure requires K1..64')
    # BEGIN + up to 1025 status polls (last may return an error) + 48 pages
    # + final status + RELEASE. Include the bounded failure path as well.
    requests=15*MAX_ITERATIONS*16+12*MAX_ITERATIONS+k+1076
    alu_requests=48*256
    watchdog=1000000+256*(requests+alu_requests);host=watchdog+200000
    return dict(watchdog_cycles=watchdog,host_limit_cycles=host,
                global_timeout_ns=(host+10000)*10,
                max_tcu_requests_per_core=requests,
                max_alu_requests_per_core=alu_requests,
                policy='finite_1m_base_plus_256_per_bounded_native_and_legacy_request')

def extend_case(case,output):
    if case['paired'] is not True or case['repeats']!=1:raise ValueError('backpressure needs one paired job')
    case['regions'] += [dict(name='contention_flags',gpu_base=0x2a000000,bytes=256,fill_byte=0xa5),
                        dict(name='contention_sums',gpu_base=0x2b000000,bytes=4096,fill_byte=0xa5),
                        dict(name='fp_contention_sums',gpu_base=0x2c000000,bytes=4096,fill_byte=0xa5),
                        dict(name='query_contention',gpu_base=0x2d000000,bytes=4096,fill_byte=0xa5),
                        dict(name='owner_alu_bursts',gpu_base=0x2e000000,bytes=4096,fill_byte=0xa5)]
    case.update(profile=PROFILE,contention_max_iterations=MAX_ITERATIONS,contention_batch_size=16,
                fp_contention_warps=[1,2,3],fp_contention_ratio=4,fp_first_warp=1,
                native_query_warps=[1,2,3],native_query_ratio=4,
                native_query_phases=['between_fp_i8','after_fp','before_i8'],
                owner_alu_instructions_per_page=256,
                runtime_budget=bp_budget(case['K']),readback_words=9604)
    case['case_id']='dualbank_backpressure_'+case['case_id'];save(output/'case.json',case);return case

def check_contenders(frames,flags,batch_size=1):
    if type(batch_size) is not int or batch_size not in [1,16]:return ['invalid contention batch size']
    if len(frames)!=64 or len(flags)!=4:return ['missing full contention memory readback']
    issues=[]
    for h,f in enumerate(frames):
        if len(f)!=16 or any(type(x) is not int for x in f):issues.append('unknown contender frame');continue
        n=f[0];owner=h%16<4
        if (n!=0 if owner else not 1<=n<MAX_ITERATIONS) or n%batch_size or f[1:9]!=[16*n]*8 or f[9:]!=[0xa5a5a5a5]*7:
            issues.append(f'hart{h} exact contention sum/count/guard')
    for c in range(4):
        if flags[c]!=[1]+[0xa5a5a5a5]*15:issues.append(f'core{c} owner stop flag/guard')
        for w in range(4):
            if len({f[0] for f in frames[c*16+w*4:c*16+w*4+4]})!=1:
                issues.append(f'core{c} warp{w} divergent iteration count')
    return issues

def check_fp_contenders(frames,iterations):
    if len(frames)!=64:return ['missing full FP16 contention readback']
    issues=[]
    for h,f in enumerate(frames):
        c,w=h//16,(h//4)%4
        expected=4*iterations[c][w] if w!=0 else 0
        if len(f)!=16 or any(type(x) is not int for x in f):issues.append('unknown FP16 contender frame');continue
        bits=struct.unpack('<I',struct.pack('<f',8*expected))[0]
        if f!=[expected]+[bits]*8+[0xa5a5a5a5]*7:issues.append(f'hart{h} exact FP16 sum/count/guard')
    return issues

def check_arbitration(banks,rows):
    issues=[];observed={}
    for r in rows:
        key=(r['core'],r['cycle'])
        if key in observed:issues.append('duplicate arbitration sample')
        observed[key]=r
        if r['core'] not in range(4) or any(type(r[k]) is not int or r[k] not in [0,1] for k in ['native_ready','choose_native','legacy_valid','int_ready','fp_valid','fp_ready']):
            issues.append('unknown arbitration control');continue
        if r['native_ready']!=(r['choose_native'] & r['int_ready']):issues.append('native handshake arbitration mismatch')
        if not r['choose_native'] and not r['legacy_valid']:issues.append('native denied without a valid legacy result')
    if set(observed)!={(b['core'],b['cycle']) for b in banks}:issues.append('arbitration trace missing/extra bank cycle')
    for b in banks:
        r=observed.get((b['core'],b['cycle']))
        if r and r['native_ready']!=b['capture']:issues.append('bank capture differs from arbitration ready')
    return issues

def check_query_frames(frames,iterations):
    if len(frames)!=64:return ['missing full native query readback']
    issues=[]
    for h,f in enumerate(frames):
        c,w=h//16,(h//4)%4
        n=4*iterations[c][w] if w!=0 else 0
        if f!=[n,0]+[0xa5a5a5a5]*14:issues.append(f'hart{h} native query count/result/guard')
    return issues

def check_query_packets(rows,requests):
    fields=['core','uuid','pc','warp','rd','mask','wb','sop','eop']
    expected=Counter(tuple(r[k] for k in fields) for r in requests if r['event']==0 and r['warp']!=0 and r['fmt']==15)
    actual=Counter(tuple(r[k] for k in fields) for r in rows)
    issues=[]
    if actual!=expected:issues.append('native query packet/request metadata conservation')
    for r in rows:
        if r['warp'] not in [1,2,3] or r['data']!=0 or r['mask']!=15 or r['wb']!=1 or r['sop']!=1 or r['eop']!=1:
            issues.append('nonowner native query exact zero status/metadata')
    return issues

def check_bank_events(case,rows):
    issues=[];held={};captures=Counter();stalls=Counter();previous=-1
    for r in rows:
        c,b,p=r['core'],r['bank'],r['page']
        if c not in range(4) or b not in range(2) or p not in range(24) or r['capture'] not in [0,1]:
            issues.append('bank response identity invalid');continue
        if r['cycle']<previous:issues.append('bank response chronology reversed')
        previous=r['cycle'];key=(c,b,p)
        expected=sum(case['cores'][c]['expected_bank_words'][b][p*4+i]<<(32*i) for i in range(4))
        if r['data']!=expected:issues.append('bank response exact signed48 page mismatch')
        if c in held:
            first=held[c]
            if any(r[k]!=first[k] for k in ['bank','page','packet','data']):issues.append('stalled full response changed')
            if not 0<=r['cycle']-first['cycle']<=20000:issues.append('stalled bank response exceeded finite bound')
        if r['capture']:
            captures[key]+=1;held.pop(c,None)
        else:
            stalls[c,b]+=1
            held.setdefault(c,r)
    if held:issues.append('bank response stall never drained')
    for c in range(4):
        for b in range(2):
            if not stalls[c,b]:issues.append(f'core{c} bank{b} no actual response backpressure')
            if any(captures[c,b,p]!=1 for p in range(24)):issues.append('bank page capture missing/duplicate')
    return issues

def check_tcu_events(rows,iterations,fp_iterations=None,query_iterations=None):
    issues=[];pending=defaultdict(deque);legacy=Counter();fp=Counter();query=Counter();previous=-1
    if fp_iterations is None:fp_iterations=[[0]*4 for _ in range(4)]
    if query_iterations is None:query_iterations=[[0]*4 for _ in range(4)]
    for r in rows:
        if r['core'] not in range(4) or r['warp'] not in range(4) or r['event'] not in [0,1]:
            issues.append('TCU contention event identity');continue
        if r['cycle']<previous:issues.append('TCU contention chronology')
        previous=r['cycle']
        key=tuple(r[k] for k in ['core','uuid','pc','warp','rd','mask','wb','sop','eop'])
        if r['event']==0:
            pending[key].append(r['cycle'])
            if r['fmt']==15 and r['warp']!=0:query[r['core'],r['warp']]+=1
            if r['fmt']==9:
                legacy[r['core'],r['warp']]+=1
                if r['mask']!=15 or r['wb']!=1:issues.append('legacy contender mask/writeback invalid')
            elif r['fmt']==1:
                fp[r['core'],r['warp']]+=1
                if r['mask']!=15 or r['wb']!=1:issues.append('FP16 contender mask/writeback invalid')
            elif r['fmt'] not in [13,14,15]:issues.append('unexpected actual TCU format')
        elif not pending[key]:issues.append('TCU result missing exact request metadata')
        elif not 0<=r['cycle']-pending[key].popleft()<=200000:issues.append('TCU result exceeded finite bound')
    if any(pending.values()):issues.append('TCU contention requests not drained')
    for c in range(4):
        for w in range(4):
            if legacy[c,w]!=16*iterations[c][w]:issues.append('actual legacy uops differ from all-lane iteration count')
            if fp[c,w]!=16*fp_iterations[c][w]:issues.append('actual FP16 uops differ from all-lane iteration count')
            if query[c,w]!=query_iterations[c][w]:issues.append('actual native query count differs from all-lane readback')
    return issues

def check_alu_frames(frames):
    if len(frames)!=64:return ['missing full ALU readback']
    return [f'hart{h} exact owner ALU count/value/guard' for h,f in enumerate(frames)
            if f!=([12288]+[1536]*8+[0xa5a5a5a5]*7 if h%16<4 else [0]*9+[0xa5a5a5a5]*7)]

def check_alu_words(words):
    if len(words)!=256:return ['ALU executable instruction count']
    regs=[(w>>7)&31 for w in words[:8]]
    if len(set(regs))!=8 or 0 in regs:return ['ALU independent register pattern']
    if any((w&0xfff0707f)!=0x00100013 or ((w>>15)&31)!=((w>>7)&31)
           or ((w>>7)&31)!=regs[i%8] for i,w in enumerate(words)):return ['ALU executable ADDI/self/one pattern']
    return []

def alu_burst_range(elf):
    from tools.elf_image import read_elf
    from pathlib import Path
    parsed=read_elf(elf);symbols=parsed['symbols'];start=symbols['bp_alu_burst_begin'];end=symbols['bp_alu_burst_end']
    if start%4 or end-start!=1024:raise ValueError('ALU burst executable extent')
    raw=Path(elf).read_bytes();segment=next(x for x in parsed['segments'] if x['gpu_base']<=start and end<=x['gpu_base']+x['file_bytes'] and x['flags']&1)
    offset=segment['file_offset']+start-segment['gpu_base']
    words=list(struct.unpack('<256I',raw[offset:offset+1024]))
    if check_alu_words(words):raise ValueError('ALU burst executable pattern')
    return start//4,end//4

def check_alu_events(rows,start,end):
    if type(start) is not int or type(end) is not int or end-start!=256:return ['ALU executable range']
    pending=defaultdict(deque);counts=Counter();issues=[];previous=-1
    for r in rows:
        if r['cycle']<previous:issues.append('ALU event order')
        previous=r['cycle']
        if not(0<=r['core']<4 and r['warp']==0 and start<=r['pc']<end and r['mask']==15 and r['wb']==1 and r['sop']==1 and r['eop']==1 and 1<=r['rd']<=31):
            issues.append('ALU burst metadata');continue
        key=tuple(r[k] for k in ['core','uuid','pc','warp','rd','mask','wb','sop','eop'])
        if r['event']==0:
            n=counts[r['core'],r['pc']];counts[r['core'],r['pc']]+=1
            value=n*32+(r['pc']-start)//8+1
            pending[key].append((r['cycle'],sum(value<<(32*i) for i in range(4))))
        elif r['event']==1 and pending[key]:
            cycle,value=pending[key].popleft()
            if not 0<=r['cycle']-cycle<=200000 or r['data']!=value:issues.append('ALU exact result or response bound')
        else:issues.append('orphan/invalid ALU retirement')
    if any(pending.values()):issues.append('unretired ALU burst')
    if any(counts[c,p]!=48 for c in range(4) for p in range(start,end)):issues.append('ALU actual PC execution count')
    return issues

def check_commit_events(banks,rows):
    if len(rows)!=len(banks) or {(r['core'],r['cycle']) for r in rows}!={(r['core'],r['cycle']) for r in banks}:return ['commit trace/page mismatch']
    if len({(r['core'],r['cycle']) for r in rows})!=len(rows):return ['duplicate commit trace']
    issues=[]
    for r in rows:
        if any(r[k] not in [0,1] for k in ['tcu_valid','tcu_ready','alu_valid','lsu_valid','sfu_valid','fpu_valid','tex_valid']):issues.append('unknown commit control')
        if r['tcu_valid'] and not r['tcu_ready'] and not any(r[k] for k in ['alu_valid','lsu_valid','sfu_valid','fpu_valid']):issues.append('TCU commit stall without higher-priority valid')
    return issues

def check_contention_contract(case):
    if (case.get('contention_max_iterations')!=MAX_ITERATIONS or case.get('readback_words')!=9604
        or case.get('contention_batch_size')!=16 or case.get('fp_contention_warps')!=[1,2,3]
        or case.get('fp_contention_ratio')!=4 or case.get('fp_first_warp')!=1
        or case.get('native_query_warps')!=[1,2,3] or case.get('native_query_ratio')!=4
        or case.get('native_query_phases')!=['between_fp_i8','after_fp','before_i8']
        or case.get('owner_alu_instructions_per_page')!=256):return ['contention contract drift']
    return []

def check_query_phase_order(events,iterations):
    issues=[]
    phases={1:[(1,1024),(15,64),(9,256)],2:[(9,256),(1,1024),(15,64)],3:[(15,64),(9,256),(1,1024)]}
    for c in range(4):
        for w in range(1,4):
            actual=[r['fmt'] for r in events if r['event']==0 and r['core']==c and r['warp']==w]
            expected=[fmt for fmt,n in phases[w] for _ in range(n)]*(iterations[c][w]//16)
            if actual!=expected:issues.append(f'core{c} warp{w} actual query/FP/I8 phase order')
    return issues

def verify_artifacts(run,case):
    issues=check_contention_contract(case);memory={}
    from tools.evidence import load
    start,end=alu_burst_range(load(run/'gpu_request.json')['elf'])
    if (start,end)!=(case.get('alu_burst_pc_begin'),case.get('alu_burst_pc_end')):issues.append('ALU bound executable PC drift')
    for line in (run/'gpu_bp_readback.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=2 or any(re.fullmatch('[0-9a-fA-F]{8}',s) is None for s in f):
            issues.append('unknown contention output');continue
        a,v=map(lambda s:int(s,16),f)
        if a in memory:issues.append('duplicate contention output')
        memory[a]=v
    if len(memory)!=4160:issues.append('incomplete contention memory readback')
    issues+=check_alu_frames([[memory.get(0x2e000000+h*64+i*4) for i in range(16)] for h in range(64)])
    frames=[[memory.get(0x2b000000+h*64+i*4) for i in range(16)] for h in range(64)]
    flags=[[memory.get(0x2a000000+c*64+i*4) for i in range(16)] for c in range(4)]
    fp_frames=[[memory.get(0x2c000000+h*64+i*4) for i in range(16)] for h in range(64)]
    query_frames=[[memory.get(0x2d000000+h*64+i*4) for i in range(16)] for h in range(64)]
    # Historical single-instruction attempts retain their original contract.
    issues+=check_contenders(frames,flags,batch_size=case.get('contention_batch_size',1))
    rows=[]
    for line in (run/'gpu_bp_bank_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=7 or any(re.fullmatch('[0-9a-fA-F]+',s) is None for s in f[5:]):
            issues.append('unknown bank response record');continue
        try:r=dict(zip(['core','cycle','capture','bank','page'],map(int,f[:5])))
        except ValueError:issues.append('malformed bank event');continue
        r.update(packet=f[5],data=int(f[6],16));rows.append(r)
    issues+=check_bank_events(case,rows)
    arbs=[]
    for line in (run/'gpu_bp_arb_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=8:issues.append('malformed arbitration trace');continue
        try:arbs.append(dict(zip(['core','cycle','native_ready','choose_native','legacy_valid','int_ready','fp_valid','fp_ready'],map(int,f))))
        except ValueError:issues.append('unknown arbitration trace')
    issues+=check_arbitration(rows,arbs)
    events=[]
    for line in (run/'gpu_bp_tcu_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=12:issues.append('TCU contention event shape');continue
        try:v=[int(s,16 if i in [3,4,7] else 10) for i,s in enumerate(f)]
        except ValueError:issues.append('unknown TCU contention event');continue
        events.append(dict(zip(['event','core','cycle','uuid','pc','warp','rd','mask','wb','sop','eop','fmt'],v)))
    iters=[[frames[c*16+w*4][0] for w in range(4)] for c in range(4)]
    fp_iters=[[fp_frames[c*16+w*4][0] for w in range(4)] for c in range(4)]
    query_iters=[[query_frames[c*16+w*4][0] for w in range(4)] for c in range(4)]
    if all(type(n) is int for ns in iters+fp_iters+query_iters for n in ns):
        issues+=check_fp_contenders(fp_frames,iters)
        issues+=check_query_frames(query_frames,iters)
        issues+=check_tcu_events(events,iters,fp_iters,query_iters)
        issues+=check_query_phase_order(events,iters)
    else:issues.append('unknown contention iteration count')
    queries=[]
    for line in (run/'gpu_bp_query_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=11:issues.append('native query packet shape');continue
        try:v=[int(s,16 if i in [3,4,6,10] else 10) for i,s in enumerate(f)]
        except ValueError:issues.append('unknown native query packet');continue
        queries.append(dict(zip(['core','cycle','warp','uuid','pc','rd','mask','wb','sop','eop','data'],v)))
    issues+=check_query_packets(queries,events)
    alu=[]
    for line in (run/'gpu_bp_alu_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=12:issues.append('ALU event shape');continue
        try:v=[int(s,16 if i in [3,4,7,11] else 10) for i,s in enumerate(f)]
        except ValueError:issues.append('unknown ALU event');continue
        alu.append(dict(zip(['event','core','cycle','uuid','pc','warp','rd','mask','wb','sop','eop','data'],v)))
    issues+=check_alu_events(alu,case.get('alu_burst_pc_begin'),case.get('alu_burst_pc_end'))
    commits=[]
    for line in (run/'gpu_bp_commit_events.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=9:issues.append('commit event shape');continue
        try:v=list(map(int,f))
        except ValueError:issues.append('unknown commit event');continue
        commits.append(dict(zip(['core','cycle','tcu_valid','tcu_ready','alu_valid','lsu_valid','sfu_valid','fpu_valid','tex_valid'],v)))
    issues+=check_commit_events(rows,commits)
    return issues,dict(owner_alu_events=len(alu),owner_alu_instructions_per_core=12288,commit_events=len(commits),tcu_commit_stalls_with_alu_valid=sum(r["tcu_valid"] and not r["tcu_ready"] and r["alu_valid"] for r in commits),iterations_per_core_warp=iters,fp16_iterations_per_core_warp=fp_iters,native_query_count_per_core_warp=query_iters,native_query_packets=len(queries),bank_stall_cycles=[[sum(r['capture']==0 and r['core']==c and r['bank']==b for r in rows) for b in range(2)] for c in range(4)],outer_fp_captures_during_native_stall=sum(r['native_ready']==0 and r['choose_native']==1 and r['fp_valid']==1 and r['fp_ready']==1 for r in arbs),bank_events=len(rows),arbitration_events=len(arbs),tcu_events=len(events),scope='actual dualbank stalls, stable full response, exact I8/FP16/query counts/packets/pages and real retirement; not performance')
