"""Exact integer oracle, deliberately independent of DSP pipeline implementation."""
def pair_reference(a0:list[list[int]],a1:list[list[int]],b:list[list[int]])->list[int]:
    k=len(b)
    if not 1<=k<=4096 or len(a0)!=8 or len(a1)!=8:raise ValueError('shape/K')
    if any(len(row)!=k for row in a0+a1) or any(len(row)!=8 for row in b):raise ValueError('shape')
    if any(isinstance(x,bool) or not isinstance(x,int) or not -32768<=x<=32767 for row in a0+a1+b for x in row):raise ValueError('signed16')
    return [sum(a[i][n]*b[n][j] for n in range(k)) for a in [a0,a1] for i in range(8) for j in range(8)]

def pack16(values):return sum((v&65535)<<(16*i) for i,v in enumerate(values))
