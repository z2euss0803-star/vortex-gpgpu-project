import argparse
from tools.baseline_identity import check_identity
from tools.evidence import ROOT, save, utc, sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['baseline','candidate'],required=True);a=ap.parse_args()
    r=check_identity(ROOT)
    if a.phase=='baseline' and r['modified']:r.update(status='REFUSED',issues=r['issues']+['baseline already changed'])
    r.update(utc=utc(),phase=a.phase,contract_sha256=sha(ROOT/'docs/planning_contract.json'),old_valid_formats='TCU_DSP FP16/BF16 input to FP32 output; I8/U8/I4/U4; S8 fmt13..15 dest8',format_clarification='TCU sourcefmt0 FP32 enum selects X in frozen VX_tcu_fedp_dsp; preserve unsupported behavior. General FP32 is GPU FPU and needs G3 verification.',new_reserved_allocation='S8 fmt13..15 dest3; previously BAD_CONTROL',functional='NOT_RUN')
    save(ROOT/'evidence'/('compatibility_'+a.phase+'.json'),r)
    print(r);return 0 if r['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
