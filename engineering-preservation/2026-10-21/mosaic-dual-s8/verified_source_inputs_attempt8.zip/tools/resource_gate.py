"""Fresh A Windows and running-WSL queries; never turn UNKNOWN into idle."""
import datetime
import getpass
import json
import math
import platform
import re
import shutil
import subprocess
from pathlib import Path
import psutil
from tools.evidence import ROOT, load, utc

def assess_resources(snapshot,policy=None):
    row=dict(snapshot)
    p=policy or dict(physical_min_gib=4,commit_min_gib=8,host='RY',account='13151')
    known=row.get('query_known') is True
    for key in ['physical_available_gib','commit_headroom_gib','other_heavy']:
        v=row.get(key)
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:known=False
    if not known:status='UNKNOWN'
    elif str(row.get('host','')).upper()!=p['host'] or row.get('account')!=p['account']:status='REFUSED'
    elif row['physical_available_gib']<p['physical_min_gib'] or row['commit_headroom_gib']<p['commit_min_gib'] or row['other_heavy']!=0:status='REFUSED'
    else:status='READY'
    return dict(row,status=status)

def _run(args):return subprocess.run(args,capture_output=True,timeout=25)

def launch_decision(snapshot,stage,authorization=None):
    raw=assess_resources(snapshot)
    permitted=raw['status']=='READY';admission=raw['status']
    # Latest direct user instruction waives only this execution chain's memory
    # thresholds. Keep the actual gate REFUSED; never call that sample READY.
    auth=authorization or {}
    valid=(auth.get('authorized_by')=='direct_user_message' and auth.get('quote')=='你直接启动就行了' and auth.get('exception')=='memory_threshold_only' and bool(auth.get('authorization_id')) and stage in auth.get('scope',[]) and stage in ['device_build','gpu_model','gpu_simulation'])
    if raw['status']=='REFUSED' and valid and raw.get('query_known') is True and str(raw.get('host')).lower()=='ry' and raw.get('account')=='13151' and raw.get('other_heavy')==0:
        permitted=True;admission='USER_AUTHORIZED_MEMORY_EXCEPTION'
    return dict(resource_status=raw['status'],launch_permitted=permitted,admission=admission,authorization_id=auth.get('authorization_id') if admission=='USER_AUTHORIZED_MEMORY_EXCEPTION' else None)

def is_linux_heavy_line(line):
    # ps -eo pid,lstart,pcpu,rss,args has8 fixed fields before the command.
    # Inspect the executable, not tool names appearing in another program's args.
    fields=line.split(maxsplit=8)
    if len(fields)!=9 or not fields[0].isdigit():return False
    exe=fields[8].split(maxsplit=1)[0].rsplit('/',1)[-1].lower()
    return bool(re.fullmatch(r'(?:vivado|xelab|xsimk?|xvlog|xvhdl|verilator(?:_bin)?|yosys|nextpnr(?:-[a-z0-9]+)?|vvp|cc1(?:plus)?|clang(?:\+\+)?(?:-\d+)?|(?:[a-z0-9_]+-)*g(?:cc|\+\+)|(?:[a-z0-9_]+-)*ld)',exe))

def resource_gate(stage:str,root:Path=ROOT)->dict:
    policy=load(Path(root)/'config/resource_policy.json')
    row=dict(utc=utc(),stage=stage,host=platform.node(),account=getpass.getuser(),physical_available_gib=None,commit_headroom_gib=None,other_heavy=0,unknown=[],heavy=[],wsl=[],query_known=False)
    try:
        q=_run(['powershell.exe','-NoProfile','-Command',"$ErrorActionPreference='Stop'; $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory; [pscustomobject]@{physical=$m.AvailableBytes;commit=($m.CommitLimit-$m.CommittedBytes)} | ConvertTo-Json -Compress"])
        if q.returncode:raise ValueError(q.stderr.decode(errors='replace'))
        m=json.loads(q.stdout);row['physical_available_gib']=m['physical']/2**30;row['commit_headroom_gib']=m['commit']/2**30
    except (OSError,ValueError,KeyError,TypeError,subprocess.TimeoutExpired) as e:row['unknown'].append('memory query: '+str(e))
    names={'vivado.exe','xsim.exe','xsimk.exe','xelab.exe','xvlog.exe','xvhdl.exe','vvp.exe','verilator.exe','yosys.exe','nextpnr.exe','cc1plus.exe','cc1.exe','clang.exe','clang++.exe','gcc.exe','g++.exe','ld.exe'}
    try:
        for p in psutil.process_iter(['pid','name']):
            if (p.info['name'] or '').lower() not in names:continue
            try:
                row['heavy'].append(dict(pid=p.pid,name=p.name(),created_at_utc=datetime.datetime.fromtimestamp(p.create_time(),datetime.timezone.utc).isoformat(),command=p.cmdline(),cwd=p.cwd(),cpu_seconds=sum(p.cpu_times()[:2]),rss=p.memory_info().rss))
            except psutil.NoSuchProcess:continue
            except psutil.Error as e:row['unknown'].append('heavy identity: '+str(e))
    except psutil.Error as e:row['unknown'].append('process query: '+str(e))
    try:
        q=_run(['wsl.exe','--list','--running','--quiet']);row['wsl_list_exit']=q.returncode
        if q.returncode:
            absent=_run(['powershell.exe','-NoProfile','-Command',"$ErrorActionPreference='Stop'; Get-CimInstance Win32_OptionalFeature -Filter \"Name='Microsoft-Windows-Subsystem-Linux'\" | Select-Object Name,InstallState | ConvertTo-Json -Compress"])
            feature=json.loads(absent.stdout);row['wsl_feature']=feature
            if absent.returncode or feature.get('InstallState')!=2:raise ValueError('running WSL query failed, absence not proven')
        else:
            text=q.stdout.decode('utf-16-le').replace('\x00','').strip().lstrip('\ufeff')
            for distro in text.splitlines():
                distro=distro.strip()
                if not distro:continue
                q=_run(['wsl.exe','-d',distro,'--exec','ps','-eo','pid,lstart,pcpu,rss,args'])
                output=q.stdout.decode('utf-8',errors='replace');row['wsl'].append(dict(distro=distro,exit_code=q.returncode,output=output))
                if q.returncode:raise ValueError('WSL process query failed: '+distro)
                for line in output.splitlines()[1:]:
                    if is_linux_heavy_line(line):row['heavy'].append(dict(distro=distro,process=line))
    except (OSError,ValueError,TypeError,subprocess.TimeoutExpired) as e:row['unknown'].append('WSL: '+str(e))
    disk=shutil.disk_usage(Path(root).anchor);row['disk_free_bytes']=disk.free
    row['query_known']=not row['unknown'];row['other_heavy']=len(row['heavy'])
    return assess_resources(row,policy)
