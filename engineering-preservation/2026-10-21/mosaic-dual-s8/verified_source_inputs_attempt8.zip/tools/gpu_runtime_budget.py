"""Finite test budgets for approved K/repetition work, never numerical waivers.

The fixed one-million-cycle base covered the separately accepted K1/K64 CRT
runs. Add 8192 cycles per submitted STEP for load/pack/software/AXI headroom;
this is a conservative test bound, not measured GPU latency or throughput.
Keep the hardware watchdog, host wait and global TB limit independently armed.
"""


def runtime_budget(k, repeats, paired):
    if (type(k) is not int or not 1 <= k <= 4096 or
            type(repeats) is not int or not 1 <= repeats <= 5 or
            type(paired) is not bool):
        raise ValueError('unsupported K/repeats/mode for bounded GPU case')
    steps = k * repeats * (1 if paired else 2)
    watchdog = 1000000 + steps * 8192
    host = watchdog + 200000
    return dict(watchdog_cycles=watchdog, host_limit_cycles=host,
                global_timeout_ns=(host + 10000) * 10,
                submitted_steps_per_core=steps,
                policy='finite_1m_base_plus_8192_per_STEP_not_performance_estimate')
