"""Local native XSim backend. Stage preparation is not simulation acceptance."""
from pathlib import Path
import random
from tools.evidence import sha, save
from tools.pair_oracle import pair_reference,pack16
from tools.vivado_runtime import runtime_env
from tools.evidence import load

def compute_vectors(run):
    rng=random.Random(20261018);cases=[]
    # Interleave both modes so a second single bank cannot accidentally remain active.
    for k in [1,2,3,8,64,2592,4096]:
        for kind in [0,1,2]:
            def value():return -32768 if kind==0 else rng.choice([-32768,-32767,-1,0,1,32766,32767]) if kind==1 else rng.randint(-32768,32767)
            a0=[[value() for _ in range(k)] for _ in range(8)]
            a1=[[value() for _ in range(k)] for _ in range(8)]
            b=[[value() for _ in range(8)] for _ in range(k)]
            index=len(cases);v=f'case_{index:02d}_steps.mem';g=f'case_{index:02d}_gold.mem'
            (run/v).write_text(''.join(f'{(pack16([a1[i][t] for i in range(8)])<<256)|(pack16(b[t])<<128)|pack16([a0[i][t] for i in range(8)]):096x}\n' for t in range(k)))
            (run/g).write_text(''.join(f'{x&((1<<48)-1):012x}\n' for x in pair_reference(a0,a1,b)))
            mode=0 if kind==1 else 1;cases.append((mode,k,v,g))
    (run/'cases.txt').write_text(str(len(cases))+'\n'+''.join(f'{m} {k} {v} {g}\n' for m,k,v,g in cases))
    save(run/'case_manifest.json',dict(seed=20261018,cases=cases,input_files={p.name:sha(p) for p in run.glob('case*') if p.is_file()}))

def prepare(root,run,variant,stage):
    if stage in ['gpu_legacy','gpu_pair']:
        from tools.build_gpu_model import prepare_gpu
        return prepare_gpu(root,run,variant,stage)
    if stage in ['aux_ddr','aux_reset']:
        toolroot=Path('G:/xilinx/Vivado/2020.1');b=toolroot/'bin/unwrapped/win64.o';base=root/'candidate/build/compat_rtl'
        top='tb_axi_ddr_model' if stage=='aux_ddr' else 'tb_reset_guard'
        sources=[root/'tb/axi_ddr_model.sv',root/'tb/tb_axi_ddr_model.sv'] if stage=='aux_ddr' else [root/'tb/verification_overlay/VX_pending_size.sv',base/'libs/VX_reset_relay.sv',root/'tb/tb_reset_guard.sv']
        (run/'xsim.ini').write_bytes((toolroot/'data/xsim/xsim.ini').read_bytes())
        commands=[[str(b/'xvlog.exe'),'--sv','--work','xil_defaultlib','-d','SIMULATION','-d','VIVADO','-i',str(base)]+[str(p) for p in sources],[str(b/'xelab.exe'),'--mt','4','--timescale','1ns/1ps','xil_defaultlib.'+top,'-s','model_snapshot']]
        for case in range(10 if stage=='aux_ddr' else 4):commands.append([str(b/'xsim.exe'),'model_snapshot','-runall','-testplusarg',('NEGATIVE=' if stage=='aux_ddr' else 'CASE=')+str(case),'-log',f'case_{case}.log'])
        return commands,runtime_env(toolroot,run),{str(b/(n+'.exe')):sha(b/(n+'.exe')) for n in ['xvlog','xelab','xsim']}
    if stage not in ['pair_compute','pair_atomic','frontend','native_protocol','tcu_compat','tcu_compat_negative'] or variant!='candidate':raise ValueError('backend not implemented for this stage; no fallback')
    if stage in ['pair_compute','native_protocol']:compute_vectors(run)
    toolroot=Path('G:/xilinx/Vivado/2020.1');b=toolroot/'bin/unwrapped/win64.o'
    rtl=root/'candidate/build/compat_rtl/tcu'
    top='tb_s8_'+stage
    sources=([rtl/'s8_compute.sv'] if stage=='pair_compute' else [])+[rtl/'VX_tcu_s8_pair.sv',root/'tb'/(top+'.sv'),toolroot/'data/verilog/src/glbl.v']
    ini=toolroot/'data/xsim/xsim.ini';(run/'xsim.ini').write_bytes(ini.read_bytes())
    wave=['clk','reset','pair_mode','cmd_valid','step_valid','result_ready','cmd_ready','step_ready','result_valid','cmd_error','a0_flat','a1_flat','b_flat','dut/cmd_fire','dut/step_fire']
    if stage=='pair_compute':wave+=['ref_cmd_ready','ref_step_ready','ref_result_valid','ref_error','dut/compute0/accepted','dut/compute1/accepted','dut/compute0/v1','dut/compute0/v2']
    (run/'simulation.tcl').write_text('open_vcd '+stage+'.vcd\nlog_vcd '+' '.join('/'+top+'/'+s for s in wave)+'\nrun all\nclose_vcd\nquit\n')
    commands=[[str(b/'xvlog.exe'),'--sv','--relax','--work','xil_defaultlib']+[str(p) for p in sources],
              [str(b/'xelab.exe'),'--relax','--debug','typical','--mt','4','-L','unisims_ver','-L','secureip','-s','pair_snapshot','xil_defaultlib.'+top,'xil_defaultlib.glbl'],
              [str(b/'xsim.exe'),'pair_snapshot','-tclbatch','simulation.tcl','-log','simulate.log']]
    if stage=='frontend':
        base=root/'candidate/build/compat_rtl';cfg=load(root/'candidate/config/build.json')
        common=[root/'candidate'/s for s in cfg['sources'] if '/interfaces/' in s or '/libs/' in s]
        packages=[base/n for n in ['VX_gpu_pkg.sv','fpu/VX_fpu_pkg.sv','tcu/VX_tcu_pkg.sv','VX_trace_pkg.sv']]
        source=packages+common+[base/'interfaces/VX_fetch_if.sv']+[base/n for n in ['tcu/VX_tcu_uops.sv','core/VX_decode.sv','core/VX_uop_sequencer.sv','core/VX_scoreboard.sv','core/VX_commit.sv']]
        source += [root/'tb/ref/VX_tcu_uops_ref.sv',root/'tb/ref/VX_uop_sequencer_ref.sv',root/'tb/tcu_pair_dependency_tb.sv',root/'tb/tb_pair_frontend.sv']
        include=[base,base/'interfaces',base/'libs',base/'core',base/'fpu',base/'tcu']
        commands[0]=[str(b/'xvlog.exe'),'--sv','--relax','--work','xil_defaultlib']+sum((['-i',str(p)] for p in include),[])+sum((['-d',d] for d in cfg['defines']),[])+[str(p) for p in dict.fromkeys(source)]
        commands[1]=[str(b/'xelab.exe'),'--relax','--debug','typical','--mt','4','-s','pair_snapshot','xil_defaultlib.tb_pair_frontend']
        (run/'simulation.tcl').write_text('open_vcd frontend.vcd\nlog_vcd /tb_pair_frontend/clk /tb_pair_frontend/reset /tb_pair_frontend/count /tb_pair_frontend/dependency/sb_count /tb_pair_frontend/dependency/retired /tb_pair_frontend/dependency/writebacks\nrun all\nclose_vcd\nquit\n')
    if stage=='native_protocol':
        base=root/'candidate/build/compat_rtl';cfg=load(root/'candidate/config/build.json')
        common=[root/'candidate'/s for s in cfg['sources'] if '/interfaces/' in s or '/libs/' in s]
        source=[base/n for n in ['VX_gpu_pkg.sv','fpu/VX_fpu_pkg.sv','tcu/VX_tcu_pkg.sv','VX_trace_pkg.sv']]+common
        source += [base/'tcu'/n for n in ['s8_compute.sv','VX_tcu_s8_pair.sv','VX_tcu_native_s8.sv']]
        source += [root/'tb/ref/VX_tcu_native_s8_ref.sv',root/'tb/tb_tcu_pair_protocol.sv',toolroot/'data/verilog/src/glbl.v']
        include=[base,base/'interfaces',base/'libs',base/'core',base/'fpu',base/'tcu']
        commands[0]=[str(b/'xvlog.exe'),'--sv','--relax','--work','xil_defaultlib']+sum((['-i',str(p)] for p in include),[])+sum((['-d',d] for d in cfg['defines']),[])+[str(p) for p in dict.fromkeys(source)]
        commands[1]=[str(b/'xelab.exe'),'--relax','--debug','typical','--mt','4','-L','unisims_ver','-L','secureip','-s','pair_snapshot','xil_defaultlib.tb_tcu_pair_protocol','xil_defaultlib.glbl']
        wave=['clk','reset','seq','sent','received','legacy_compare','packet','dut/active','dut/accepted','dut/target','dut/captured_pages']
        (run/'simulation.tcl').write_text('open_vcd native_protocol.vcd\nlog_vcd '+' '.join('/tb_tcu_pair_protocol/'+s for s in wave)+'\nrun all\nclose_vcd\nquit\n')
    if stage in ['tcu_compat','tcu_compat_negative']:
        base=root/'candidate/build/compat_rtl';cfg=load(root/'candidate/config/build.json')
        source=[base/n for n in ['VX_gpu_pkg.sv','fpu/VX_fpu_pkg.sv','tcu/VX_tcu_pkg.sv','VX_trace_pkg.sv']]
        source += [root/'candidate'/s for s in cfg['sources'] if '/interfaces/' in s or '/libs/' in s or ('/tcu/' in s and not s.endswith('/VX_tcu_pkg.sv'))]
        source += [base/'core'/n for n in ['VX_dispatch_unit.sv','VX_gather_unit.sv','VX_pe_switch.sv','VX_commit.sv']]
        source += [root/'tb'/n for n in ['tcu_sim.sv','tcu_legacy_tb.sv','tb_tcu_legacy_diff.sv']]
        source += [root/'tb/ref'/n for n in ['VX_tcu_int_ref.sv','VX_tcu_unit_ref.sv','VX_tcu_native_s8_ref.sv','tcu_sim_ref.sv']]
        source += [toolroot/'data/verilog/src/glbl.v']
        include=[base,base/'interfaces',base/'libs',base/'core',base/'fpu',base/'tcu']
        defines=cfg['defines']+['S8_TEST_ROOT="'+root.as_posix()+'"']
        if stage=='tcu_compat_negative':defines+=['PAIR_NEGATIVE_GOLD']
        vlog=[str(b/'xvlog.exe'),'--sv','--relax','--work','xil_defaultlib']+sum((['-i',str(p)] for p in include),[])+sum((['-d',d] for d in defines),[])+[str(p) for p in dict.fromkeys(source)]
        vhdl=[root/'tb/ip_full_usage'/(n+'.vhd') for n in ['xil_fadd','xil_fmul']]
        vhd=[str(b/'xvhdl.exe'),'--relax','--work','xil_defaultlib']+[str(p) for p in vhdl]
        libs=['xbip_utils_v3_0_10','axi_utils_v2_0_6','xbip_pipe_v3_0_6','xbip_dsp48_wrapper_v3_0_4','xbip_dsp48_addsub_v3_0_6','xbip_dsp48_multadd_v3_0_6','xbip_bram18k_v3_0_6','mult_gen_v12_0_16','floating_point_v7_1_10','xil_defaultlib','unisims_ver','unimacro_ver','secureip','xpm']
        elab=[str(b/'xelab.exe'),'--relax','--debug','typical','--mt','4']+sum((['-L',name]for name in libs),[])+['-s','pair_snapshot','xil_defaultlib.tb_tcu_legacy_diff','xil_defaultlib.glbl','-timescale','1ns/1ps']
        commands=[vlog,vhd,elab,commands[2]]
        (run/'simulation.tcl').write_text('open_vcd tcu_compat.vcd\nlog_vcd /tb_tcu_legacy_diff/clk /tb_tcu_legacy_diff/reset /tb_tcu_legacy_diff/accepted /tb_tcu_legacy_diff/retired /tb_tcu_legacy_diff/step_retired /tb_tcu_legacy_diff/step_writeback /tb_tcu_legacy_diff/captured /tb_tcu_legacy_diff/pair_cases\nrun all\nclose_vcd\nquit\n')
    files=[b/(n+'.exe') for n in ['xvlog','xelab','xsim']]+[ini,toolroot/'data/verilog/src/unisims/DSP48E2.v',toolroot/'bin/setupEnv.bat']
    if stage in ['tcu_compat','tcu_compat_negative']:
        files += [b/'xvhdl.exe']+list((root/'tb/ip_full_usage').glob('*'))
        files += [p for p in (toolroot/'data/xsim/ip/floating_point_v7_1_10').rglob('*') if p.is_file()]
    return commands,runtime_env(toolroot,run),{str(p):sha(p) for p in files}
