"""Independent exact compatibility vectors for real GPU integer/FP/TEX execution."""
import struct
from collections import Counter,defaultdict,deque
from tools.evidence import save,sha
from tools.gpu_runtime_budget import runtime_budget

PROFILE='legacy_fpu_tex_v1'
FORMATS=[9,10,11,12,1,2]

def fp(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def pixel(x,y):return 0xa0000000|((y*41+3)<<16)|((x*53+7)<<8)|(x+4*y+1)
def sample(u,v):
    x=max(0,min(3,(u+32768)//65536));y=max(0,min(3,(v+32768)//65536))
    return pixel(x,y)
def hart_expected(hart):
    if type(hart) is not int or hart not in range(64):raise ValueError('requires actual hart0..63')
    base=(hart+1)*16;v=[]
    for total in [-4096,1040400,-1792,7200]:v += [(base+i+total)&0xffffffff for i in range(8)]
    v += [fp(8)]*16
    n=hart+1;v += [fp(n+2),fp(n*2),fp(n-2),fp(n/2),fp(4),fp(n*2+1),n,int(n<2)]
    core=hart//16;warp=(hart//4)%4;lane=hart%4
    v += [sample((lane-1)*65536,(core+warp-1)*65536),sample(lane*65536+32768,32768),sample(-32769,4*65536),sample(2*65536+16384,65536+16384)]
    return v+[0xa5a5a5a5]*4
def check_frames(frames):
    if len(frames)!=64:return ['64 compatibility hart records missing']
    return [f'hart{h} compatibility numeric/guard mismatch' for h in range(64) if frames[h]!=hart_expected(h)]
def check_events(rows,require_overlap=False):
    issues=[];pending=defaultdict(deque);formats=Counter();fpu=defaultdict(set);tex=Counter();overlap=Counter();last=-1
    for r in rows:
        if r['core'] not in range(4) or r['src'] not in range(3) or r['warp'] not in range(4) or r['event'] not in [0,1]:
            issues.append('unknown compatibility event identity');continue
        if r['cycle']<last:issues.append('compatibility chronology reversed')
        last=r['cycle']
        key=tuple(r[k] for k in ['src','core','uuid','pc','warp','rd','mask','wb','sop','eop'])
        if r['event']==0:
            pending[key].append(r['cycle'])
            if r['src']==0:
                if r['fmt']<13:
                    if r['fmt'] not in FORMATS or r['mask']!=15 or r['wb']!=1:issues.append('unsupported legacy format/mask/writeback')
                    formats[r['core'],r['warp'],r['fmt']]+=1
                    overlap[r['core']]+=r['overlap']
            elif r['src']==1:fpu[r['core'],r['warp']].add(r['fmt'])
            elif r['src']==2:tex[r['core'],r['warp']]+=1
        else:
            if not pending[key]:issues.append('compatibility result without matching exact request metadata')
            elif not 0<=r['cycle']-pending[key].popleft()<=200000:issues.append('compatibility result exceeded finite fairness bound')
    if any(pending.values()):issues.append('compatibility accepted requests not drained')
    for c in range(4):
        if require_overlap and not overlap[c]:issues.append(f'core{c} no actual legacy/native context overlap')
        for w in range(4):
            if any(formats[c,w,f]!=16 for f in FORMATS):issues.append(f'core{c} warp{w} missing exact legacy uops')
            if not {0,1,2,4,5,8,10,12}.issubset(fpu[c,w]):issues.append(f'core{c} warp{w} missing actual FPU categories')
            if tex[c,w]!=4:issues.append(f'core{c} warp{w} TEX request count')
    return issues
def extend_case(case,output):
    if case['repeats']!=1 or not 1<=case['K']<=64:raise ValueError('compatibility directed case requires K1..64/repeats1')
    tex=output/'texture.bin';tex.write_bytes(struct.pack('<16I',*[pixel(x,y) for y in range(4) for x in range(4)]))
    case['inputs'].append(dict(name='texture',gpu_base=0x29000000,path=tex.name,bytes=64,sha256=sha(tex),permissions='r'))
    case['regions'].append(dict(name='compat_results',gpu_base=0x28000000,bytes=16384,fill_byte=0xa5))
    case.update(profile=PROFILE,readback_words=9540,compat_formats=FORMATS[:],texture=dict(base=0x29000000,width=4,height=4,pitch=16,mode=8,bytes=64))
    case['runtime_budget']=runtime_budget(case['K']*(1 if case['paired'] else 2)+1024,1,True)
    case['case_id']='legacy_fpu_tex_'+case['case_id'];save(output/'case.json',case);return case
