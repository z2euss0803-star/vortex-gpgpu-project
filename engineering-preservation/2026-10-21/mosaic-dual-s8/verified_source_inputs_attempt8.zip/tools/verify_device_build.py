"""Independent byte/ELF/command readback, not GPU execution acceptance."""
import argparse,hashlib,struct,zipfile
from pathlib import Path
from tools.evidence import ROOT,load,save,sha,utc,input_identity
from tools.elf_image import read_elf

def check_device_command(receipt):
    if receipt.get('exit_code') is not None and receipt['exit_code']!=0:return dict(status='FAIL',reason='nonzero natural tool exit')
    if receipt.get('exit_code') is None or not all(receipt.get(k) for k in ['pid','created_at_utc','command','cwd','host']) or 'uid' not in receipt:return dict(status='UNKNOWN',reason='missing tool identity/exit')
    if receipt['host'].lower()!='ry' or receipt['uid']!=1000:return dict(status='FAIL',reason='wrong A WSL execution identity')
    return dict(status='PASS',reason='exact compiler-driver natural exit, not inferred descendants')

def check_probe_words(words):
    expected={'pair_begin':0x0406818b,'pair_step':0x0407018b,'pair_read':0x0407818b,'single_begin':0x0406840b,'single_step':0x0407040b,'single_read':0x0407840b}
    counts={k:words.count(v) for k,v in expected.items()}
    return dict(status='PASS' if all(v==1 for v in counts.values()) else 'FAIL',counts=counts)

def executable_words(path):
    data=Path(path).read_bytes()
    if data[:7]!=b'\x7fELF\x01\x01\x01':raise ValueError('requires ELF32 LE')
    h=struct.unpack_from('<HHIIIIIHHHHHH',data,16)
    if h[1]!=243 or h[0] not in (1,2) or h[10]!=40:raise ValueError('requires RV32 object/executable sections')
    words=[]
    for i in range(h[11]):
        s=struct.unpack_from('<IIIIIIIIII',data,h[5]+40*i)
        if s[1]!=1 or not s[2]&4:continue
        if s[4]+s[5]>len(data) or s[5]%4:raise ValueError('instruction section extent/alignment')
        words.extend(struct.unpack('<'+'I'*(s[5]//4),data[s[4]:s[4]+s[5]]))
    return words

def verify_device_build(run):
    run=Path(run).resolve();issues=[]
    if not run.is_relative_to(ROOT/'runs'):raise ValueError('outside current build root')
    gates=[p for p in run.glob('*gate*.json') if not p.name.endswith(('.exit.json','.started.json'))]
    from tools.resource_gate import launch_decision
    exception=load(run/'memory_override.json') if (run/'memory_override.json').is_file() else None
    if exception:
        request=load(run/'build_request.json')
        if request.get('memory_override_sha256')!=sha(run/'memory_override.json'):return dict(status='REFUSED',issues=['memory exception receipt changed'])
    refused=[p for p in gates if not launch_decision(load(p),'device_build',exception)['launch_permitted']]
    if refused:return dict(schema_version=1,utc=utc(),stage='device_build',run=str(run),status='REFUSED',issues=['resource gate '+str(p) for p in refused],boundaries='incomplete build; no device/RTL PASS')
    mandatory=['inputs_before.json','inputs_after.json','product_manifest.json','wsl_exit.json','worker_manifest.json','linux_tool_inputs.json','linux_tool_inputs_after.json']
    missing=[p for p in mandatory if not (run/p).is_file()]
    if missing:return dict(schema_version=1,utc=utc(),stage='device_build',run=str(run),status='UNKNOWN',issues=['missing build evidence '+p for p in missing],boundaries='missing evidence never PASS')
    before=load(run/'inputs_before.json')
    if before!=load(run/'inputs_after.json') or before!=input_identity():issues.append('source input drift')
    with zipfile.ZipFile(run/'verified_source_inputs.zip') as z:
        for rel,h in before['files'].items():
            if hashlib.sha256(z.read(rel)).hexdigest()!=h:issues.append('source archive drift '+rel)
    for rel,h in load(run/'product_manifest.json').items():
        if sha(run/rel)!=h:issues.append('product drift '+rel)
    wsl=load(run/'wsl_exit.json')
    if wsl['exit_code']!=0 or not all(wsl.get(k) for k in ['pid','created_at_utc','command','cwd']):issues.append('WSL driver natural exit/identity')
    required=['clang_version','gcc_version','host_header_compile','host_header_run','archive_runtime']+['runtime_'+str(i) for i in range(8)]
    required += [p+s for p in ['pair_encoding_probe','pair_validation','pair_perf'] for s in ['_compile','_object_disassembly']]
    required += [p+s for p in ['pair_validation','pair_perf'] for s in ['_link','_disassembly']]
    worker=load(run/'worker_manifest.json')
    if any(row['program']=='pair_protocol' for row in worker['outputs']):
        required += ['pair_protocol'+s for s in ['_compile','_object_disassembly','_link','_disassembly']]
    if any(row['program']=='pair_compat' for row in worker['outputs']):
        required += ['pair_compat'+s for s in ['_compile','_object_disassembly','_link','_disassembly']]
    if any(row['program']=='pair_backpressure' for row in worker['outputs']):
        required += ['pair_backpressure'+s for s in ['_compile','_object_disassembly','_link','_disassembly']]
    for name in required:
        if not (run/(name+'.exit.json')).is_file():issues.append('missing Linux compiler command receipt '+name);continue
        receipt=load(run/(name+'.exit.json'))
        if check_device_command(receipt)['status']!='PASS':issues.append('Linux compiler command exit/identity '+name)
        for stream in ['stdout','stderr']:
            if sha(run/(name+'.'+stream+'.bin'))!=receipt[stream+'_sha256']:issues.append('command log drift '+name)
    if 'PAIR_HEADER_HOST_PASS signed48=128 shapes=128' not in (run/'host_header_run.stdout.bin').read_text():issues.append('actual header test missing')
    probe=check_probe_words(executable_words(run/'pair_encoding_probe.o'))
    if probe['status']!='PASS':issues.append('actual raw probe encoding mismatch')
    disasm=(run/'pair_encoding_probe_object_disassembly.stdout.bin').read_text()
    for reg in ['ft0','ft8','fa0']:
        if reg not in disasm:issues.append('missing floating register operand '+reg)
    worker=load(run/'worker_manifest.json')
    if worker['status']!='TOOL_COMPLETE' or worker['host'].lower()!='ry' or worker['uid']!=1000:issues.append('worker status/identity')
    if load(run/'linux_tool_inputs.json')!=load(run/'linux_tool_inputs_after.json'):issues.append('Linux tool/library drift')
    outputs=[]
    for row in worker['outputs']:
        elf=run/row['elf'];info=read_elf(elf)
        if sha(elf)!=row['sha256'] or info['entry']!=0x80000000:issues.append('ELF entry/hash '+row['program'])
        required_symbols=['_start','main','_Exit','vx_spawn_threads','__init_tls','_end','__tbss_size','__tdata_size','__tbss_offset']
        if any(k not in info['symbols'] for k in required_symbols):issues.append('missing CRT/TLS symbols '+row['program'])
        outputs.append(dict(row,entry=info['entry'],symbols={k:info['symbols'].get(k) for k in required_symbols},segments=[{k:v for k,v in s.items() if k!='payload'} for s in info['segments']]))
    return dict(schema_version=1,utc=utc(),stage='device_build',run=str(run),status='FAIL' if issues else 'PASS',issues=issues,probe=probe,outputs=outputs,input_manifest_sha256=sha(run/'inputs_before.json'),natural_exit_sha256=sha(run/'wsl_exit.json'),product_manifest_sha256=sha(run/'product_manifest.json'),contract_sha256=sha(ROOT/'docs/planning_contract.json'),boundaries=['actual host C++ header execution + real RV32 CRT/ELF build','no actual GPU execution or STEP retirement claim','compiler-driver exits recorded; internal GCC assembler exits not individually traced'])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--build',type=Path,required=True);a=ap.parse_args();r=verify_device_build(a.build)
    save(ROOT/'evidence'/('device_build_admission_'+a.build.name+'.json'),r);print(r['status'],r['issues']);raise SystemExit(r['status']!='PASS')
