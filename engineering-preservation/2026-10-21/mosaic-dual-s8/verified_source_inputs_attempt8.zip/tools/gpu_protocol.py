"""Four actual-GPU modes and exact contender controls; no acceptance by error suppression."""
from tools.evidence import save
from tools.gpu_runtime_budget import runtime_budget
from tools.pair_layout import unpack48

MODES=[False,True,False,True]
PROFILE='owner_modes_v1'


def extend_case(case,output):
    if case['paired'] is not True or case['repeats']!=1 or not 1<=case['K']<=64:
        raise ValueError('directed protocol supports candidate paired K1..64/repeats1 only')
    case.update(profile=PROFILE,phase_modes=MODES[:],readback_words=18756,timing_count=4)
    for row in case['cores']:
        row['expected128']=row['expected128']*4
        row.update(expected_accepted_steps=6*case['K']+3,expected_begin=9,
                   expected_release=9,expected_data_reads=192,raw_offset=16384*row['core'])
    case['regions'][0]['bytes']=65536
    case['regions'].append(dict(name='protocol_trace',gpu_base=0x28000000,bytes=4096,fill_byte=0xa5))
    case['runtime_budget']=runtime_budget(6*case['K']+3,1,True)
    case['case_id']='owner_modes_'+case['case_id']
    save(output/'case.json',case)
    return case


def decode_frame(frame):
    if len(frame)!=1024 or any(type(v) is not int for v in frame):return [],False
    raw=unpack48([frame[:96],frame[96:192]])
    wide=[]
    for i in range(128):
        v=frame[256+2*i]+(frame[257+2*i]<<32)
        wide.append(v-(1<<64) if v>>63 else v)
    return raw,raw==wide and all(frame[i]==0xa5a5a5a5 for i in range(1024) if not (i<192 or 256<=i<512))


def check_trace(trace):
    expected=[0xa5a5a5a5]*256
    for w in [1,2,3]:expected[w*8:w*8+6]=[1,1,3,0,3,3]
    for phase,paired in enumerate(MODES):
        for p in range(1 if paired else 2):
            expected[32+phase*4+p]=0;expected[32+phase*4+2+p]=0
    return trace==expected


def check_requests(k,records):
    issues=[]
    if not records or any(r['core'] not in range(4) or r['warp'] not in range(4) for r in records):return ['protocol request identity missing/outside four cores/warps']
    for core in range(4):
        owner=[r for r in records if r['core']==core and r['warp']==0]
        if any(r['error']!=0 for r in owner):issues.append(f'core{core} unexpected owner error')
        for key,expected in [('cmd',6),('step',6*k),('release',6)]:
            if sum(r[key] for r in owner)!=expected:issues.append(f'core{core} successful {key} count')
        # Independent command order confirms actual mode changes, rather than
        # declaring a mixed software loop sufficient evidence.
        tags=[r['tag'] for r in owner if r['cmd']]
        if tags!=[8,8,3,8,8,3]:issues.append(f'core{core} command mode sequence')
        for warp in [1,2,3]:
            rows=[r for r in records if r['core']==core and r['warp']==warp]
            if [(r['fmt'],r['error']) for r in rows]!=[(13,1),(15,0),(14,3),(15,0),(15,3),(15,0),(15,3)]:issues.append(f'core{core} warp{warp} exact contention sequence')
            if any(r['tag']!=3 or r['cmd'] or r['step'] or r['release'] for r in rows):issues.append(f'core{core} warp{warp} rejected operation changed context')
    return issues
