"""Read back complete TCU semantic counts; retain original source-bound admission."""
import argparse
import hashlib
import re
import zipfile
from pathlib import Path
from tools.evidence import ROOT,load,save,sha,utc
from tools.admit_stage import semantic_errors

def check_tcu_semantics(text):
    issues=semantic_errors(text)
    patterns={
        'legacy':r'LEGACY_CYCLE_EQ_PASS sent=(\d+) returned=(\d+) reset_discarded=(\d+) stalls=(\d+) resets=(\d+)',
        'pair':r'PAIR_TCU_COMPAT_PASS pair_cases=(\d+) snapshot_bank1=PASS',
        'oracle':r'NATIVE_INTEGER_ORACLE_PASS cases=(\d+) values=(\d+) captured_pages=(\d+) snapshot_before_retirement=(\d+)',
        'commit':r'INTEGRATED_COMMIT_PASS accepted=(\d+) retired=(\d+) step_retired=(\d+) step_writeback=(\d+) reset_discarded=(\d+) output_stalls=(\d+)'}
    counts={}
    for key,pattern in patterns.items():
        hits=re.findall(pattern,text)
        if len(hits)!=1:issues.append('missing/duplicate semantic result '+key);continue
        counts[key]=tuple(map(int,hits[0])) if isinstance(hits[0],tuple) else (int(hits[0]),)
    if 'legacy' in counts:
        sent,returned,discard,stalls,resets=counts['legacy']
        if sent!=5999 or sent!=returned+discard or discard!=44 or stalls<=0 or resets!=2:issues.append('legacy loss/reset/backpressure contract')
    if counts.get('pair')!=(1,):issues.append('pair bank1 snapshot missing')
    if counts.get('oracle')!=(5,320,240,1):issues.append('old single oracle coverage')
    if 'commit' in counts:
        accepted,retired,steps,wb,discard,stalls=counts['commit']
        if accepted!=7391 or retired!=7390 or accepted!=retired+discard or steps!=6700 or wb!=0 or discard!=1 or stalls<=0:issues.append('actual commit contract')
    return dict(status='FAIL' if issues else 'PASS',counts=counts,issues=issues)

def verify_tcu_run(run):
    run=Path(run).resolve()
    if not run.is_relative_to(ROOT/'runs'):raise ValueError('outside candidate runs')
    admission=load(run/'independent_admission.json')
    issues=[]
    if admission['status']!='PASS' or admission['run']!=str(run) or admission['stage']!='tcu_compat':issues.append('not accepted complete TCU run')
    for file,field in [('inputs_before.json','input_manifest_sha256'),('natural_exit.json','natural_exit_sha256'),('product_manifest.json','product_manifest_sha256')]:
        if sha(run/file)!=admission[field]:issues.append('admitted receipt binding drift '+file)
    for rel,digest in load(run/'product_manifest.json').items():
        if sha(run/rel)!=digest:issues.append('admitted product drift '+rel)
    with zipfile.ZipFile(run/'verified_source_inputs.zip') as archive:
        for rel,digest in load(run/'inputs_before.json')['files'].items():
            if hashlib.sha256(archive.read(rel)).hexdigest()!=digest:issues.append('original source archive drift '+rel)
    semantics=check_tcu_semantics((run/'console.log').read_text(encoding='utf-8',errors='replace'))
    issues+=semantics['issues']
    return dict(schema_version=1,utc=utc(),run=str(run),status='FAIL' if issues else 'PASS',admission_sha256=sha(run/'independent_admission.json'),contract_sha256=admission['contract_sha256'],semantics=semantics,issues=issues,boundaries='complete TCU only; source archive bound; not GPU or physical PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);a=ap.parse_args()
    result=verify_tcu_run(a.run);save(ROOT/'evidence'/('tcu_semantic_readback_'+a.run.name+'.json'),result)
    print(result['status']);raise SystemExit(result['status']!='PASS')
