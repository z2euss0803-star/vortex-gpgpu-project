"""Registered test memory; GPU addresses remain distinct from HP addresses."""
FLUSH=0x10030000


def gpu_to_hp(address):
    if not isinstance(address,int) or not 0<=address<=0xffffffff:
        raise ValueError('GPU address outside32 bits')
    return 0x500000000+(address&0x7fffffff) if address&0x80000000 else address


def validate_regions(regions):
    result=[]
    for region in regions:
        r=dict(region);base=r['gpu_base'];size=r['byte_count'];kind=r.get('kind','ddr')
        if not isinstance(size,int) or size<=0 or base+size>1<<32:raise ValueError('invalid region size')
        if kind=='io':legal=0<=base and base+size<=0x10000000
        else:legal=(0x10000000<=base and base+size<=0x30000000) or (0x80000000<=base and base+size<=1<<32)
        if not legal:raise ValueError('unregistered GPU domain')
        if base<FLUSH+64 and base+size>FLUSH and kind!='flush':raise ValueError('reserved flush line collision')
        if r['permissions'] not in ['r','rw'] or not 0<=r.get('fill_byte',0)<=255:raise ValueError('invalid region attributes')
        r['hp_base']=gpu_to_hp(base);r['hp_end']=r['hp_base']+size
        if any(r['hp_base']<other['hp_end'] and r['hp_end']>other['hp_base'] for other in result):
            raise ValueError('overlapping physical regions')
        result.append(r)
    return result


class RegisteredMemory:
    def __init__(self,regions):
        self.regions=validate_regions(regions);self.data={};self.job_active=False

    def region(self,address):
        for r in self.regions:
            if r['hp_base']<=address<r['hp_end']:return r
        raise ValueError('unallocated physical byte')

    def peek_byte(self,address):
        r=self.region(address)
        return self.data.get(address,r.get('fill_byte',0))

    def load_byte(self,address,value):
        self.region(address)
        if self.job_active:raise ValueError('host load during job')
        if not 0<=value<=255:raise ValueError('invalid byte')
        self.data[address]=value

    def store_byte(self,address,value):
        if self.region(address)['permissions']!='rw':raise ValueError('write to readonly region')
        if not 0<=value<=255:raise ValueError('invalid byte')
        self.data[address]=value
