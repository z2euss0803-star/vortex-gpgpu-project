"""Compare candidate with immutable reference and a narrow product allowlist."""
from pathlib import Path
from tools.evidence import load, sha, bound

def check_identity(root:Path)->dict:
    root=Path(root).resolve();issues=[];modified=[];expected={}
    try:
        manifest=load(root/'evidence/baseline_snapshot_manifest.json')
        contract=load(root/'docs/planning_contract.json')
        for row in manifest['files']:
            p=bound(root,row['snapshot'])
            if not p.is_file() or sha(p)!=row['sha256']:issues.append('reference drift: '+row['snapshot'])
            if row['snapshot'].startswith('reference/s8_w4/'):
                expected['candidate/'+row['snapshot'][len('reference/s8_w4/'):]]=row['sha256']
        if len(expected)!=manifest['source_files']:issues.append('reference source count mismatch')
        allow=set(contract['product_modify_allowlist']); additions=set(contract['product_additions'])
        for rel,digest in expected.items():
            p=bound(root,rel)
            if not p.is_file():issues.append('missing candidate: '+rel);continue
            if sha(p)==digest:continue
            modified.append(rel)
            if rel in allow:continue
            if rel=='candidate/config/build.json':
                old=load(root/'reference/s8_w4/config/build.json'); new=load(p)
                source='build/compat_rtl/tcu/VX_tcu_s8_pair.sv'
                valid=new.get('sources',[]).count(source)==1
                reduced=dict(new,sources=[x for x in new.get('sources',[]) if x!=source])
                if valid and reduced==old:continue
            issues.append('forbidden candidate change: '+rel)
        for p in (root/'candidate').rglob('*'):
            if not p.is_file() or '__pycache__' in p.parts:continue
            rel=p.relative_to(root).as_posix()
            if rel.startswith(('candidate/build/vivado/','candidate/build/artifacts/')):continue
            if rel not in expected and rel not in additions:issues.append('unapproved candidate addition: '+rel)
    except (OSError,ValueError,KeyError,TypeError) as exc:issues.append(str(exc))
    return {'status':'REFUSED' if issues else 'PASS','issues':issues,'modified':modified,'source_count':len(expected),'scope':'static identity and allowlist only'}
