"""Two externally reset real GPU epochs; neither epoch inherits acceptance."""
from tools.evidence import load, save, sha, utc
from tools.gpu_runtime_budget import runtime_budget

PROFILE = 'reset_reopen_v1'


def epoch_budget(k):
    if type(k) is not int or not 1 <= k <= 64:
        raise ValueError('reset reopen requires bounded K1..64')
    b = runtime_budget(k, 1, True)
    return dict(b, global_timeout_ns=b['global_timeout_ns'] * 2)


def check_epochs(rows):
    issues=[]
    if [(r.get('epoch'),r.get('event')) for r in rows] != [
            (e,event) for e in range(2) for event in ['reset','start','done']]:
        issues.append('two actual reset/start/done sequences required')
    previous=-1
    for r in rows:
        if type(r.get('cycle')) is not int or r['cycle'] <= previous:
            issues.append('reset epoch chronology invalid')
        previous=r.get('cycle',-1)
        bits=['resetn','gpu_reset','active','busy','aw','w','r','bvalid','rvalid']
        if any(type(r.get(k)) is not int or r[k] not in [0,1] for k in bits):
            issues.append('unknown reset epoch signal');continue
        if any(r[k] for k in bits[2:]):
            issues.append('reset/job boundary before complete GPU and AXI drain')
        if r.get('event')=='reset':
            if r['resetn']!=0 or r['gpu_reset']!=1:
                issues.append('normal external reset did not converge')
        elif r['resetn']!=1:
            issues.append('job boundary without released external reset')
    return issues


def check_case_pair(master,cases):
    if len(cases)!=2:return ['two distinct epoch cases missing']
    issues=[]
    for e,c in enumerate(cases):
        if (c.get('K')!=master['K'] or c.get('M')!=master['M'] or
            c.get('N')!=master['N'] or c.get('seed')!=master['seed']+e or
            c.get('paired') is not True or c.get('repeats')!=1 or
            c.get('profile') is not None):
            issues.append('reset epoch case binding invalid')
    for core in range(4):
        if cases[0]['cores'][core]['expected128']==cases[1]['cores'][core]['expected128']:
            issues.append('epoch inputs cannot detect stale numeric output')
    return issues


def verify_reopen(run):
    from tools.verify_gpu_pair import verify_gpu_pair
    master=load(run/'case/case.json');issues=[]
    if (master.get('profile')!=PROFILE or master.get('reopen_epochs')!=2 or
        master.get('paired') is not True or master.get('repeats')!=1 or
        not 1<=master['K']<=64):
        issues.append('reset reopen profile drift')
    budget=epoch_budget(master['K'])
    if master['runtime_budget']!=budget:issues.append('reset reopen bounded budget drift')
    rows=[]
    for line in (run/'gpu_reset_epochs.txt').read_text().splitlines():
        f=line.split()
        if len(f)!=12:issues.append('reset epoch record shape');continue
        try:
            row=dict(epoch=int(f[0]),event=f[1],cycle=int(f[2]))
            row.update(zip(['resetn','gpu_reset','active','busy','aw','w','r','bvalid','rvalid'],map(int,f[3:])))
        except ValueError:issues.append('unknown reset epoch record');continue
        rows.append(row)
    issues+=check_epochs(rows)
    cases=[];epochs=[]
    for e in range(2):
        case_path=run/'case'/f'epoch_{e}'/'case.json'
        if sha(case_path)!=master['epoch_case_sha256'][e]:issues.append('epoch case hash drift')
        cases.append(load(case_path))
        result=verify_gpu_pair(run,_epoch=e)
        epochs.append(result)
        issues += [f'epoch{e}: '+s for s in result['issues']]
        if result['status']!='PASS':issues.append(f'epoch{e} independent GPU not PASS')
    issues+=check_case_pair(master,cases)
    if (run/'console.log').read_text().count('PAIR_GPU_RESET_REOPEN_DRAIN_PASS epochs=2')!=1:
        issues.append('two-epoch final completion missing')
    return dict(schema_version=1,utc=utc(),run=str(run),status='FAIL' if issues else 'PASS',
                issues=issues,epochs=epochs,reset_epochs=rows,
                case_sha256=sha(run/'case/case.json'),
                independent_admission_sha256=sha(run/'independent_admission.json'),
                boundaries='two distinct real GPU jobs with normal external reset and complete readbacks; not whole G3, backpressure or performance PASS')
