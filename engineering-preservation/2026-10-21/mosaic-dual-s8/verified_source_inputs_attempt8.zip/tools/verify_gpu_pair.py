"""Exact four-core readback, identities, guards and observed native retirement."""
import argparse,hashlib,re,struct,zipfile
from pathlib import Path
from tools.evidence import ROOT,load,save,sha,utc
from tools.pair_layout import unpack48
from tools.elf_image import read_elf

def check_gpu_observations(case,observed):
    if observed.get('native_status')!='PASS':return dict(status='UNKNOWN' if observed.get('native_status')=='UNKNOWN' else 'FAIL',issues=['actual native tool/worker exit not accepted'])
    issues=[]
    if not observed.get('normal_reset'):issues.append('normal external reset not verified')
    if not observed.get('real_done') or observed.get('axi_pending_reads')!=0 or observed.get('axi_pending_writes')!=0:issues.append('real DONE/AXI drain not verified')
    if not observed.get('all_harts_valid'):issues.append('64hart identity/stack/TLS/status failure')
    rows=observed.get('cores',[])
    if len(rows)!=4 or {r['core'] for r in rows}!=set(range(4)):issues.append('four core observations missing/duplicate')
    for expected in case['cores']:
        found=[r for r in rows if r['core']==expected['core']]
        if len(found)!=1:continue
        r=found[0];core=r['core']
        if r['values']!=expected['expected128']:issues.append(f'core{core} exact two-bank numeric mismatch')
        if not r['guards_ok']:issues.append(f'core{core} guard corruption')
        protocol=case.get('profile')=='owner_modes_v1'
        expected_counts=dict(accepted_steps=expected['expected_accepted_steps'],retired_steps=expected['expected_accepted_steps'],step_writeback=0,begins=expected['expected_begin'],releases=expected['expected_release'],data_captures=expected['expected_data_reads'],bank0_captures=144 if protocol else (24 if case['paired'] else 48)*case['repeats'],bank1_captures=48 if protocol else (24 if case['paired'] else 0)*case['repeats'])
        for key,value in expected_counts.items():
            if r.get(key)!=value:issues.append(f'core{core} {key} expected{value} observed{r.get(key)}')
    return dict(status='FAIL' if issues else 'PASS',issues=issues)

def verify_gpu_pair(run,_epoch=None):
    run=Path(run).resolve()
    if not run.is_relative_to(ROOT/'runs'):raise ValueError('run outside candidate root')
    admission=load(run/'independent_admission.json');case_path=run/'case/case.json' if _epoch is None else run/'case'/f'epoch_{_epoch}'/'case.json'
    case=load(case_path);text=(run/'console.log').read_text(encoding='utf8',errors='replace')
    if _epoch is None and case.get('profile')=='reset_reopen_v1':
        from tools.gpu_reopen import verify_reopen
        return verify_reopen(run)
    prefix='' if _epoch is None else f'epoch_{_epoch}_'
    protocol=case.get('profile')=='owner_modes_v1'
    compat=case.get('profile')=='legacy_fpu_tex_v1'
    bp=case.get('profile')=='dualbank_backpressure_v1'
    observations=dict(native_status=admission['checks']['native']['status'],normal_reset='INITIAL_RESET_CONVERGENCE_PASS' in text and 'INITIAL_RESET_COMPLETE:' in text,real_done='PAIR_GPU_REAL_DONE_DRAIN_PASS cores=4 jobs=1 pending_reads=0 pending_writes=0' in text,axi_pending_reads=0 if 'pending_reads=0' in text else None,axi_pending_writes=0 if 'pending_writes=0' in text else None,all_harts_valid=True,cores=[])
    if admission['status']!='PASS':observations['native_status']=admission['status']
    issues=[]
    if bp:
        from tools.gpu_backpressure import verify_artifacts
        if case['paired'] is not True or case['repeats']!=1 or not 1<=case['K']<=64:issues.append('backpressure case contract drift')
        bp_issues,bp_observed=verify_artifacts(run,case)
        issues+=bp_issues;observations['backpressure']=bp_observed
    if compat:
        from tools.gpu_compat import FORMATS,check_frames,check_events
        if not (case['compat_formats']==FORMATS and case['repeats']==1 and 1<=case['K']<=64 and case['readback_words']==9540 and case['texture']==dict(base=0x29000000,width=4,height=4,pitch=16,mode=8,bytes=64)):issues.append('compatibility case contract drift')
        extra={}
        for line in (run/'gpu_compat_readback.txt').read_text().splitlines():
            address,value=line.split()
            if re.fullmatch('[0-9a-fA-F]{8}',value) is None:issues.append('unknown compatibility output');continue
            address=int(address,16)
            if address in extra:issues.append('duplicate compatibility output')
            extra[address]=int(value,16)
        if len(extra)!=4096:issues.append('incomplete actual compatibility memory readback')
        frames=[[extra.get(0x28000000+h*256+i*4) for i in range(64)] for h in range(64)]
        issues+=check_frames(frames)
        rows=[]
        for line in (run/'gpu_compat_events.txt').read_text().splitlines():
            f=line.split()
            if len(f)!=14:issues.append('compatibility event record shape');continue
            try:
                v=[int(s,16 if i in [4,5,8] else 10) for i,s in enumerate(f)]
            except ValueError:issues.append('unknown/malformed actual compatibility event');continue
            rows.append(dict(zip(['event','src','core','cycle','uuid','pc','warp','rd','mask','wb','sop','eop','fmt','overlap'],v)))
        issues+=check_events(rows,require_overlap=case['paired'])
        observations['compatibility']=dict(harts=64,exact_values=3840,guard_words=256,events=len(rows),paired_context_overlap_required=case['paired'])
    if protocol:
        from tools.gpu_protocol import MODES,check_requests,check_trace,decode_frame
        if not (case['phase_modes']==MODES and case['paired'] is True and case['repeats']==1 and 1<=case['K']<=64 and case['readback_words']==18756 and case['timing_count']==4):issues.append('protocol case contract drift')
        for row in case['cores']:
            if not (len(row['expected128'])==512 and row['expected128']==row['expected128'][:128]*4 and row['expected_accepted_steps']==6*case['K']+3 and row['expected_begin']==9 and row['expected_release']==9 and row['expected_data_reads']==192):issues.append('protocol count/numeric contract drift')
        records=[]
        for line in (run/'gpu_protocol_requests.txt').read_text().splitlines():
            fields=list(map(int,line.split()))
            if len(fields)!=9:issues.append('protocol request record shape');continue
            records.append(dict(zip(['cycle','core','warp','fmt','tag','error','cmd','step','release'],fields)))
        issues+=check_requests(case['K'],records)
        if any(records[i]['cycle']>records[i+1]['cycle'] for i in range(len(records)-1)):issues.append('nonmonotonic protocol request chronology')
    if 'runtime_budget' in case:
        from tools.gpu_runtime_budget import runtime_budget
        budget=runtime_budget(6*case['K']+3,1,True) if protocol else runtime_budget(case['K']*(1 if case['paired'] else 2)+1024,1,True) if compat else runtime_budget(case['K'],case['repeats'],case['paired'])
        if bp:
            from tools.gpu_backpressure import bp_budget
            budget=bp_budget(case['K'])
        if budget!=case['runtime_budget']:issues.append('case-derived runtime budget drift')
        expected=[budget[k] for k in ['watchdog_cycles','host_limit_cycles','global_timeout_ns']]
        if _epoch is not None:expected[2]*=2
        try:
            if [int(x) for x in (run/'gpu_runtime_budget.txt').read_text().split()]!=expected:issues.append('runtime budget input drift')
        except (OSError,ValueError):issues.append('runtime budget input missing/malformed')
    for file,key in [('inputs_before.json','input_manifest_sha256'),('natural_exit.json','natural_exit_sha256'),('product_manifest.json','product_manifest_sha256')]:
        if sha(run/file)!=admission[key]:issues.append('admission binding drift '+file)
    for rel,h in load(run/'product_manifest.json').items():
        if sha(run/rel)!=h:issues.append('product drift '+rel)
    memory={}
    for line in (run/(prefix+'gpu_readback.txt')).read_text().splitlines():
        address,value=line.split()
        if re.fullmatch('[0-9a-fA-F]{8}',value) is None:issues.append('unknown output at'+address);continue
        address=int(address,16)
        if address in memory:issues.append('duplicate readback address')
        memory[address]=int(value,16)
    def word(address):return memory.get(address)
    if len(memory)!=(18756 if protocol else 5444):issues.append('incomplete/unknown actual memory readback')
    elf=read_elf(Path(load(run/'gpu_request.json')['elf']));tls_base=elf['symbols']['_end'];tls_size=elf['symbols']['__tbss_size'];stack_probes=set();tls_probes=set()
    for hart in range(64):
        r=[word(0x26000000+hart*64+i*4) for i in range(16)];top=0xffff0000-hart*8192
        expected=[hart//16,(hart//4)%4,hart%4,hart]
        valid=r[:4]==expected and all(v is not None for v in r) and word(0x25000000+hart*4)==0
        if valid:valid=top-8192<=r[4]<top and r[5]==tls_base+hart*tls_size and top-8192<=r[6]<top and r[5]<=r[7]<r[5]+tls_size and r[8]==(0xa1000000|hart) and r[9]==(0xb2000000|hart) and r[10:]==[0xa5a5a5a5]*6
        observations['all_harts_valid'] &= valid
        if valid:stack_probes.add(r[6]);tls_probes.add(r[7])
    observations['all_harts_valid'] &= len(stack_probes)==64 and len(tls_probes)==64 and all(word(0x25000000+(64+c)*4)==0 for c in range(4))
    counters={}
    for line in (run/(prefix+'gpu_monitor.txt')).read_text().splitlines():
        values=list(map(int,line.split()))
        if len(values)!=9 or values[0] in counters:issues.append('counter readback shape/duplicate');continue
        counters[values[0]]=dict(zip(['core','accepted_steps','retired_steps','step_writeback','begins','releases','data_captures','bank0_captures','bank1_captures'],values))
    for c in range(4):
        output=[word(0x24000000+c*(16384 if protocol else 4096)+i*4) for i in range(4096 if protocol else 1024)];r=counters.get(c,{'core':c})
        if any(v is None for v in output):r.update(values=[],guards_ok=False)
        elif protocol:
            values=[];guards=True
            for phase in range(4):
                frame,ok=decode_frame(output[phase*1024:(phase+1)*1024]);values+=frame;guards &= ok
            trace=[word(0x28000000+c*1024+i*4) for i in range(256)]
            r.update(values=values,guards_ok=guards and check_trace(trace))
        else:
            raw=unpack48([output[:96],output[96:192]])
            signed64=[int.from_bytes(struct.pack('<II',output[256+2*i],output[257+2*i]),'little',signed=True) for i in range(128)]
            r.update(values=raw,guards_ok=raw==signed64 and all(output[i]==0xa5a5a5a5 for i in range(1024) if not (i<192 or 256<=i<512)))
        timing=[word(0x27000000+c*256+i*4) for i in range(64)];samples=[]
        timing_count=4 if protocol else case['repeats']
        for i in range(timing_count):
            if timing[2*i] is None or timing[2*i+1] is None:issues.append('unknown timing');continue
            samples.append(timing[2*i]+(timing[2*i+1]<<32))
        if any(v is None or v!=0xa5a5a5a5 for v in timing[timing_count*2:]) or any(v<=0 for v in samples):issues.append('timing guard/interval')
        r['protocol_intervals_including_barriers_cycles' if protocol else 'device_load_through_page_cycles']=samples;observations['cores'].append(r)
    result=check_gpu_observations(case,observations);result['issues']+=issues
    if result['issues']:result['status']='FAIL'
    return dict(schema_version=1,utc=utc(),run=str(run),status=result['status'],issues=result['issues'],observations=observations,case_id=case['case_id'],case_sha256=sha(case_path),contract_sha256=admission['contract_sha256'],independent_admission_sha256=sha(run/'independent_admission.json'),boundaries='one real four-core GPU case only; not whole G3, performance conclusion, physical or board PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--case',type=Path);a=ap.parse_args();r=verify_gpu_pair(a.run);save(a.run/'gpu_function_admission.json',r);print(r['status'],r['issues']);raise SystemExit(r['status']!='PASS')
