"""Independent file readback: every required native executable must exit naturally."""
import argparse
import re
from pathlib import Path, PureWindowsPath
from tools.evidence import ROOT, load, save, sha, utc, input_identity, bound

def semantic_errors(text):
    return re.findall(r'(?im)^\s*(?:fatal(?:_error)?|error)\s*[:\[][^\r\n]*',text)

def check_natural_exit(receipt,required_names):
    rows=[receipt]+receipt.get('children',[]);unknown=[];failed=[]
    if receipt.get('descendant_identity_unknown'):unknown.append('descendant identity unknown')
    if receipt.get('exit_code') is None:unknown.append('root exit missing')
    elif receipt['exit_code']!=0:failed.append('nonzero root exit')
    for name in required_names:
        hits=[r for r in rows if r.get('command') and PureWindowsPath(str(r['command'][0])).name.lower()==name.lower()]
        if not hits:unknown.append('missing native tool: '+name)
        for r in hits:
            if not all(r.get(k) for k in ['pid','created_at_utc','command','cwd']) or r.get('exit_code') is None:unknown.append('missing native identity/exit: '+name)
            elif r['exit_code']!=0:failed.append('nonzero native exit: '+name)
    return {'status':'FAIL' if failed else 'UNKNOWN' if unknown else 'PASS','reasons':failed+unknown}

def admit_stage(run:Path,contract:Path)->dict:
    run=Path(run).resolve();root=ROOT;issues=[];unknown=[]
    if not run.is_relative_to(root/'runs'):raise ValueError('run outside this project')
    launch=load(run/'launch.json');config=load(root/'config/stages.json')[launch['stage']]
    natural=load(run/'natural_exit.json')
    native=check_natural_exit(natural,config['required_native'])
    if native['status']=='FAIL':issues+=native['reasons']
    elif native['status']!='PASS':unknown+=native['reasons']
    for rel,expected in load(run/'inputs_before.json')['files'].items():
        p=bound(root,rel)
        if not p.is_file() or sha(p)!=expected:issues.append('input/source drift: '+rel)
    text=(run/'console.log').read_text(encoding='utf-8',errors='replace')
    if launch['stage'] in ['aux_ddr','aux_reset']:
        from tools.model_checks import phase_model_check
        expected=12 if launch['stage']=='aux_ddr' else 6
        if natural['phases']!=expected:issues.append('incomplete model controls')
        for i in range(natural['phases']):
            result=phase_model_check(run,launch['stage'],i,(run/f'phase_{i}.log').read_text(encoding='utf8',errors='replace'),load(run/f'phase_{i}_exit.json'))
            if result['status']!='PASS':issues.append('model case failed/unknown '+str(i))
    else:issues+=semantic_errors(text)
    for rel,expected in load(run/'run_inputs_before.json').items():
        p=bound(run,rel)
        if not p.is_file() or sha(p)!=expected:issues.append('run input/vector drift: '+rel)
    for name,expected in load(run/'tool_manifest.json').items():
        p=Path(name)
        if not p.is_file() or sha(p)!=expected:issues.append('tool/model drift: '+name)
    if load(run/'inputs_after.json')!=load(run/'inputs_before.json'):issues.append('recorded input drift')
    if config['pass_marker'] not in text:issues.append('missing semantic completion marker')
    for rel,expected in load(run/'product_manifest.json').items():
        p=bound(run,rel)
        if not p.is_file() or sha(p)!=expected:issues.append('product drift: '+rel)
    if launch['contract_sha256']!=sha(contract):issues.append('contract drift')
    result=dict(schema_version=1,stage=launch['stage'],variant=launch['variant'],run=str(run),utc=utc(),status='FAIL' if issues else 'UNKNOWN' if unknown else 'PASS',input_manifest_sha256=sha(run/'inputs_before.json'),contract_sha256=sha(contract),natural_exit_sha256=sha(run/'natural_exit.json'),product_manifest_sha256=sha(run/'product_manifest.json'),checks={'native':native,'issues':issues,'unknown':unknown},boundaries=config['scope'])
    save(run/'independent_admission.json',result);return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--contract',type=Path,default=ROOT/'docs/planning_contract.json');a=ap.parse_args()
    r=admit_stage(a.run,a.contract);print(r['status']);raise SystemExit(0 if r['status']=='PASS' else 1)
