"""Strict RV32 ELF admission and sparse simulation memory images.

Only PT_LOAD file bytes plus exact BSS extents are loaded. Cache prefetch
padding, CRT stacks and externally declared buffers remain separate regions.
No instruction relocation, flat-DDR aliasing, or device execution is implied.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import sys
if __package__ in (None, ''): sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.memory_layout import validate_regions


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_elf(elf_path):
    data = Path(elf_path).read_bytes()
    if len(data) < 52 or data[:7] != b'\x7fELF\x01\x01\x01':
        raise ValueError('requires ELF32 little endian version1')
    h = struct.unpack_from('<HHIIIIIHHHHHH', data, 16)
    typ, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, shnum, shstr = h
    if (typ, machine, version, ehsize, phsize) != (2, 243, 1, 52, 32):
        raise ValueError('requires executable RISC-V ELF32 header')
    if not phnum or phoff < 52 or phoff + phnum * phsize > len(data):
        raise ValueError('invalid program header extent')
    segments = []
    for index in range(phnum):
        ptype, offset, base, physical, filesz, memsz, pf, align = struct.unpack_from(
            '<IIIIIIII', data, phoff + index * phsize)
        if ptype != 1 or memsz == 0:
            continue
        if filesz > memsz or offset + filesz > len(data) or base + memsz > 1 << 32:
            raise ValueError('invalid PT_LOAD extent')
        if physical != base or pf & ~7 or not pf & 4:
            raise ValueError('unsupported PT_LOAD mapping or permissions')
        if align not in (0, 1) and (align & (align - 1) or (base - offset) % align):
            raise ValueError('invalid PT_LOAD alignment')
        if any(base < s['gpu_base'] + s['byte_count'] and base + memsz > s['gpu_base'] for s in segments):
            raise ValueError('overlapping PT_LOAD segments')
        segments.append(dict(index=index, gpu_base=base, byte_count=memsz,
                             file_offset=offset, file_bytes=filesz, bss_bytes=memsz-filesz,
                             flags=pf, permissions='rw' if pf & 2 else 'r',
                             payload=data[offset:offset+filesz]))
    if not any(s['flags'] & 1 and s['gpu_base'] <= entry < s['gpu_base'] + s['file_bytes'] for s in segments):
        raise ValueError('entry is outside file-backed executable PT_LOAD')
    # Symbols are not required for fixture admission; actual CRT builds require
    # their named symbol set in build_device, including _end and TLS sizes.
    symbols = {}
    if shnum:
        if shsize != 40 or shoff + shnum * shsize > len(data):
            raise ValueError('invalid section header extent')
        sections = [struct.unpack_from('<IIIIIIIIII', data, shoff + i*40) for i in range(shnum)]
        for section in sections:
            if section[1] != 2:
                continue
            offset, size, link, entsize = section[4], section[5], section[6], section[9]
            if entsize != 16 or size % 16 or link >= shnum or offset + size > len(data):
                raise ValueError('invalid symbol table')
            strings = sections[link]
            if strings[1] != 3 or strings[4] + strings[5] > len(data):
                raise ValueError('invalid symbol string table')
            table = data[strings[4]:strings[4]+strings[5]]
            for at in range(offset, offset+size, 16):
                name, value, symsize, info, other, ndx = struct.unpack_from('<IIIBBH', data, at)
                if name >= len(table):
                    raise ValueError('invalid symbol name')
                end = table.find(b'\0', name)
                if end < 0:
                    raise ValueError('unterminated symbol name')
                if name and ndx:
                    symbols[table[name:end].decode('utf-8')] = value
    return dict(entry=entry, flags=flags, segments=segments, symbols=symbols)


def crt_tls_regions(symbols):
    required = ['_end', '__tbss_size', '__tdata_size', '__tbss_offset']
    if any(key not in symbols for key in required):
        raise ValueError('missing frozen CRT TLS symbols')
    if symbols['__tdata_size'] != 0 or symbols['__tbss_offset'] != 0 or symbols['__tbss_size'] <= 0:
        raise ValueError('TLS initialization conflicts with frozen CRT tbss-only stride')
    return [dict(name=f'tls_{hart}', kind='tls', hart=hart,
                 gpu_base=symbols['_end'] + hart * symbols['__tbss_size'],
                 byte_count=symbols['__tbss_size'], permissions='rw', fill_byte=0)
            for hart in range(64)]


def elf_image(elf_path, layout_path, out_dir):
    elf_path, layout_path, out_dir = map(lambda p: Path(p).resolve(), (elf_path, layout_path, out_dir))
    elf = read_elf(elf_path)
    layout = json.loads(layout_path.read_text(encoding='utf-8'))
    if (layout['hart_count'], layout['stack_base'], layout['stack_bytes'], layout['cache_line_bytes']) != (64, 0xffff0000, 8192, 64):
        raise ValueError('layout conflicts with frozen HW4 CRT geometry')
    regions = [dict(name=f"elf_{s['index']}", kind='elf', gpu_base=s['gpu_base'],
                    byte_count=s['byte_count'], permissions=s['permissions'], fill_byte=0)
               for s in elf['segments']]
    # Register uncovered portions of ELF and TLS cache lines, never widening
    # valid ELF/BSS ranges or overlapping an adjacent PT_LOAD sharing the line.
    if layout.get('require_crt_tls'):
        regions += crt_tls_regions(elf['symbols'])
        validate_regions(regions)
    padding = []
    for s in regions[:]:
        intervals = [(s['gpu_base']//64*64, (s['gpu_base']+s['byte_count']+63)//64*64)]
        for r in regions:
            remaining = []
            a, b = r['gpu_base'], r['gpu_base']+r['byte_count']
            for left, right in intervals:
                if a >= right or b <= left: remaining.append((left, right))
                else:
                    if left < a: remaining.append((left, a))
                    if b < right: remaining.append((b, right))
            intervals = remaining
        padding.extend(intervals)
    merged = []
    for a, b in sorted(set(padding)):
        if merged and a <= merged[-1][1]: merged[-1] = (merged[-1][0], max(b, merged[-1][1]))
        else: merged.append((a, b))
    regions += [dict(name=f'prefetch_padding_{i}', kind='prefetch_padding', gpu_base=a,
                     byte_count=b-a, permissions='r', fill_byte=0)
                for i, (a, b) in enumerate(merged)]
    for hart in range(64):
        top = layout['stack_base'] - hart * layout['stack_bytes']
        regions.append(dict(name=f'stack_{hart}', kind='stack', hart=hart, top=top,
                            gpu_base=top-layout['stack_bytes'], byte_count=layout['stack_bytes'],
                            permissions='rw', fill_byte=0))
    regions += layout['regions']
    regions = validate_regions(regions)
    # Refusal happens before creating images. Never overwrite a prior attempt.
    out_dir.mkdir(parents=True, exist_ok=False)
    result = dict(schema_version=1, elf_path=str(elf_path), elf_sha256=sha256(elf_path),
                  layout_path=str(layout_path), layout_sha256=sha256(layout_path),
                  entry=elf['entry'], symbols=elf['symbols'], segments=[], regions=regions,
                  scope='simulation load preparation only; no device execution claim')
    for segment in elf['segments']:
        row = {k: v for k, v in segment.items() if k != 'payload'}
        image = out_dir / f"segment_{row['index']}.bin"
        with image.open('xb') as f:
            f.write(segment['payload'])
            remaining = segment['bss_bytes']
            while remaining:
                chunk = min(remaining, 65536); f.write(bytes(chunk)); remaining -= chunk
        row.update(image_path=str(image), image_sha256=sha256(image),
                   hp_base=next(r['hp_base'] for r in regions if r['name']==f"elf_{row['index']}"))
        result['segments'].append(row)
    path = out_dir / 'memory_manifest.json'
    path.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    return path


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--elf', required=True); ap.add_argument('--layout', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    print(elf_image(args.elf, args.layout, args.out))
