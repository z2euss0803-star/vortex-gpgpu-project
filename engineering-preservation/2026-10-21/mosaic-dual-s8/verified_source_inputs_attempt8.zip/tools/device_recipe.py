"""Reviewed frozen SDK command recipes; no upstream runner or resource policy."""
from pathlib import Path
import datetime,json,os,platform,subprocess
from tools.evidence import utc,sha as sha256
KERNEL_SOURCES=['vx_start.S', 'vx_syscalls.c', 'vx_print.S', 'tinyprintf.c', 'vx_print.c', 'vx_spawn.c', 'vx_serial.S', 'vx_perf.c']
def build_recipe(sdk, tools, address):
    if address not in (0x80000000, 0x10000000):
        raise ValueError('requires a separately linked approved GPU address domain')
    gcc = tools/'riscv32-gnu-toolchain'
    flags = ['-march=rv32imaf', '-mabi=ilp32f', '-O3', '-mcmodel=medany',
             '-fno-exceptions', '-fdata-sections', '-ffunction-sections', '-DXLEN_32',
             '-DNDEBUG', '-DNUM_CLUSTERS=1', '-DNUM_CORES=4', '-DSOCKET_SIZE=4',
             '-DNUM_WARPS=4', '-DNUM_THREADS=4', '-DNUM_BARRIERS=2',
             '-DICACHE_SIZE=16384', '-DDCACHE_SIZE=16384', '-DDCACHE_WRITEBACK=0',
             '-DPLATFORM_MEMORY_NUM_BANKS=1', '-DPLATFORM_MEMORY_DATA_SIZE=64',
             '-DMEM_BLOCK_SIZE=64', '-DMEM_ADDR_WIDTH=32', '-DLMEM_BASE_ADDR=1879048192',
             '-DFPU_DSP', '-DEXT_TCU_ENABLE', '-DTCU_DSP', '-DZ11_TCU_XIL_IP',
             '-DEXT_TEX_ENABLE', '-DGBAR_ENABLE', '-Xclang', '-target-feature', '-Xclang', '+vortex',
             '--sysroot='+str(gcc/'riscv32-unknown-elf'), '--gcc-toolchain='+str(gcc),
             '-I'+str(sdk/'kernel/include'), '-I'+str(sdk/'hw')]
    return dict(kernel_sources=KERNEL_SOURCES, flags=flags,
                link_flags=['-nostartfiles', '-nostdlib', '--ld-path='+str(gcc/'bin/riscv32-unknown-elf-ld').replace('\\', '/'),
                            '-Wl,-Bstatic,--gc-sections,-T,'+str(sdk/'kernel/scripts/link32.ld'),
                            f'-Wl,--defsym=STARTUP_ADDR={address:#x}'], startup_address=address)


def runtime_recipe(sdk,tools):
    """Match frozen SDK kernel/Makefile: GCC runtime, Clang device program."""
    recipe=build_recipe(sdk,tools,0x80000000)
    flags=recipe['flags'][:]
    index=flags.index('-Xclang');del flags[index:index+4]
    flags=[flag for flag in flags if not flag.startswith('--gcc-toolchain=')]
    base=tools/'riscv32-gnu-toolchain/bin'
    return dict(compiler=base/'riscv32-unknown-elf-gcc',archiver=base/'riscv32-unknown-elf-gcc-ar',
                flags=flags,kernel_sources=KERNEL_SOURCES)


def linux_command(command, cwd, run, name):
    command = [str(x) for x in command]
    log = run/(name+'.stdout.bin'); err = run/(name+'.stderr.bin')
    with log.open('xb') as out, err.open('xb') as errors:
        process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.DEVNULL,
                                   stdout=out, stderr=errors)
        # /proc start_ticks + boot epoch binds the actual Linux creation time.
        stat = Path(f'/proc/{process.pid}/stat').read_text()
        ticks = int(stat[stat.rfind(')')+2:].split()[19])
        boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
        created = datetime.datetime.fromtimestamp(boot + ticks/os.sysconf('SC_CLK_TCK'), datetime.timezone.utc).isoformat()
        receipt = dict(command=command, cwd=str(cwd), host=platform.node(), uid=os.getuid(),
                       pid=process.pid, created_at_utc=created, started_utc=utc())
        (run/(name+'.started.json')).write_text(json.dumps(receipt, indent=2)+'\n')
        receipt.update(exit_code=process.wait(), exited_utc=utc(),
                       exit_scope='exact Popen command; no timeout or forced termination')
    receipt.update(stdout_sha256=sha256(log), stderr_sha256=sha256(err))
    (run/(name+'.exit.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    if receipt['exit_code']:
        raise RuntimeError(name+' natural nonzero exit; originals retained in '+str(run))
    return receipt


