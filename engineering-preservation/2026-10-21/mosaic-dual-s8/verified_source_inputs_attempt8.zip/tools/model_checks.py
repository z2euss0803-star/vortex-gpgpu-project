"""Expected-negative model checks have their own scope, never GPU PASS."""
from tools.admit_stage import semantic_errors,check_natural_exit
def check_model_case(stage,case,text,native):
    if native['status']!='PASS':return dict(status=native['status'],reason='actual native tool/worker evidence missing or failed')
    if stage=='aux_ddr':
        positives={0:'AXI_DDR_MODEL_PASS',5:'AXI_DDR_MODEL_BOUNDARY_PASS',7:'AXI_DDR_MODEL_STACK_X_PASS'}
        negatives={1:'MODEL_REGION_OVERLAP',2:'MODEL_READ_UNALLOCATED',3:'MODEL_AW_SHAPE',4:'MODEL_W_SHAPE',6:'MODEL_WRITE_READONLY',8:'MODEL_W_DATA_X',9:'MODEL_WRITE_READONLY'}
        marker=positives.get(case);negative=negatives.get(case)
    elif stage=='aux_reset':
        positives={0:'RESET_GUARD_NORMAL_PASS'};negatives={1:'counter underflow',2:'counter overflow',3:'RESET_GUARD_CONVERGENCE_FAILED'}
        marker=positives.get(case);negative=negatives.get(case)
        if f'RESET_GUARD_CASE={case}' not in text:return dict(status='FAIL',reason='missing exact reset control case')
        if text.count('RESET_GUARD_CONVERGENCE_PASS')!=(0 if case==3 else 1):return dict(status='FAIL',reason='reset convergence count')
    else:raise ValueError('not a model control stage')
    errors=semantic_errors(text)
    if marker:ok=marker in text and not errors
    else:ok=negative is not None and len(errors)==1 and negative in errors[0] and not any(p in text for p in positives.values())
    return dict(status='PASS' if ok else 'FAIL',case=case,expected_rejection=bool(negative),diagnostics=errors,scope='external model/checker only')

def phase_model_check(run,stage,index,text,raw):
    if index<2:return dict(status='FAIL' if raw['exit_code']!=0 or semantic_errors(text) else 'PASS')
    return check_model_case(stage,index-2,text,check_natural_exit(raw,['xsim.exe','xsimk.exe']))
