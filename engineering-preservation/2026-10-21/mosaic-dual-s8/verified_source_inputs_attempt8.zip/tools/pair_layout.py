"""Exact layout of two 64-value signed48 banks and zero-padded 16x8 tiles."""
def valid_shape(m,n,k):return all(isinstance(v,int) and not isinstance(v,bool) for v in (m,n,k)) and 1<=m<=16 and 1<=n<=8 and 1<=k<=4096

def pack48(values):
    if len(values)!=128 or any(not -(1<<47)<=v<(1<<47) for v in values):raise ValueError('128 signed48 values required')
    result=[]
    for bank in range(2):
        bits=sum((v&((1<<48)-1))<<(48*i) for i,v in enumerate(values[bank*64:(bank+1)*64]))
        result.append([(bits>>(32*i))&0xffffffff for i in range(96)])
    return result

def unpack48(words):
    if len(words)!=2 or any(len(bank)!=96 for bank in words):raise ValueError('two banks of96words required')
    result=[]
    for bank in words:
        if any(not isinstance(v,int) or not 0<=v<=0xffffffff for v in bank):raise ValueError('32bit words required')
        bits=sum(v<<(32*i) for i,v in enumerate(bank))
        for i in range(64):
            value=(bits>>(48*i))&((1<<48)-1)
            result.append(value-(1<<48) if value&(1<<47) else value)
    return result

def padded_operands(a,b,m,n,k):
    if not valid_shape(m,n,k) or len(a)!=m or any(len(row)!=k for row in a) or len(b)!=k or any(len(row)!=n for row in b):raise ValueError('matrix shape outside16x8/K1..4096')
    if any(not -32768<=v<=32767 for matrix in (a,b) for row in matrix for v in row):raise ValueError('signed16 input required')
    return [list(row) for row in a]+[[0]*k for _ in range(16-m)],[list(row)+[0]*(8-n) for row in b]
