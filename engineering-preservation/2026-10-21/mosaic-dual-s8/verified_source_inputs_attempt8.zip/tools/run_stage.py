"""Launch exactly one explicitly requested phase group; never auto-retry."""
import argparse
import datetime
import json
import os
import traceback
from pathlib import Path
from tools.evidence import ROOT, load, save, sha, utc, input_identity,archive_inputs
from tools.baseline_identity import check_identity
from tools.resource_gate import resource_gate,launch_decision
from tools.process_runner import run_preserving
from tools.admit_stage import check_natural_exit, semantic_errors

def can_start(state):
    return not state.get('active_run') and state.get('mode') not in ['active','awaiting_independent_acceptance']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',required=True);ap.add_argument('--variant',choices=['baseline','candidate'],required=True);ap.add_argument('--memory-override',type=Path);ap.add_argument('--case-request',type=Path);a=ap.parse_args()
    stages=load(ROOT/'config/stages.json')
    if a.stage not in stages:raise ValueError('unknown stage')
    state_path=ROOT/'evidence/system_state.json';state=load(state_path)
    if not can_start(state):raise ValueError('bound active or pending acceptance stage')
    if not load(ROOT/'evidence/execution_authorization.json').get('implementation'):raise ValueError('implementation authorization missing')
    identity=check_identity(ROOT)
    if identity['status']!='PASS':raise ValueError(str(identity))
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    run=ROOT/'runs'/(stamp+'_'+a.variant+'_'+a.stage);run.mkdir(parents=True)
    auth=None
    if a.memory_override:
        p=a.memory_override.resolve()
        if not p.is_relative_to(ROOT/'evidence'):raise ValueError('exception outside own evidence')
        auth=load(p);save(run/'memory_override.json',auth)
    family=stages[a.stage].get('resource_family','gpu_simulation')
    gate=resource_gate(a.stage,ROOT);gate['launch_decision']=launch_decision(gate,family,auth);save(run/'preflight.json',gate)
    if not gate['launch_decision']['launch_permitted']:
        state.update(utc=utc(),mode='resource_refused',active_run=None,monitor='PAUSED',blocked_run=str(run),resource=gate)
        save(state_path,state);print(json.dumps({'run':str(run),'status':gate['status'],'resource':gate},ensure_ascii=False));return 2
    # The backend is imported only after a successful real resource gate.
    from tools.xsim_backend import prepare
    launch=dict(schema_version=1,utc=utc(),stage=a.stage,variant=a.variant,run=str(run),contract_sha256=sha(ROOT/'docs/planning_contract.json'),host=gate['host'],account=gate['account'])
    phases=[];error=None
    try:
        if a.case_request:
            p=a.case_request.resolve()
            if not p.is_relative_to(ROOT/'evidence'):raise ValueError('case request outside own root')
            save(run/'gpu_request.json',load(p))
        commands,env,tool_inputs=prepare(ROOT,run,a.variant,a.stage)
        save(run/'tool_manifest.json',tool_inputs);save(run/'commands.json',commands)
        save(run/'run_inputs_before.json',{p.relative_to(run).as_posix():sha(p) for p in run.rglob('*') if p.is_file()})
        before=input_identity();save(run/'inputs_before.json',before)
        archive_inputs(ROOT,before,run/'verified_source_inputs.zip')
        save(run/'launch.json',launch)
        state.update(launch,mode='active',active_run=str(run),monitor='ACTIVE',events=str(run/'phase_0.events.jsonl'),scope=stages[a.stage]['scope'])
        save(state_path,state)
        for i,command in enumerate(commands):
            fresh=resource_gate(a.stage+'_'+str(i),ROOT);fresh['launch_decision']=launch_decision(fresh,family,auth);save(run/(f'phase_{i}_preflight.json'),fresh)
            if not fresh['launch_decision']['launch_permitted']:
                error='phase resource '+fresh['status'];break
            phase_env=env.copy();phase_env['RDI_PROG']=command[0];phase_env['RDI_PROGNAME']=Path(command[0]).name
            state.update(command=command,cwd=str(run),events=str(run/(f'phase_{i}.events.jsonl')));save(state_path,state)
            r=run_preserving(command,cwd=run,log_path=run/(f'phase_{i}.log'),events_path=run/(f'phase_{i}.events.jsonl'),env=phase_env,poll_seconds=.05)
            save(run/(f'phase_{i}_exit.json'),r);phases.append(r)
            text=(run/(f'phase_{i}.log')).read_text(encoding='utf8',errors='replace')
            if a.stage in ['aux_ddr','aux_reset']:
                from tools.model_checks import phase_model_check
                if phase_model_check(run,a.stage,i,text,r)['status']!='PASS':error='model control semantic/native failure';break
            elif r['exit_code']!=0 or semantic_errors(text):error='phase tool or semantic failure';break
        text='\n'.join((run/(f'phase_{i}.log')).read_text(encoding='utf8',errors='replace') for i in range(len(phases)))
        (run/'console.log').write_text(text,encoding='utf-8')
        native=dict(exit_code=next((r['exit_code'] for r in phases if r['exit_code']!=0),0),children=[r for r in phases]+[c for r in phases for c in r.get('children',[])],descendant_identity_unknown=[e for r in phases for e in r.get('descendant_identity_unknown',[])],command=[],phases=len(phases))
        save(run/'natural_exit.json',native)
        after=input_identity();save(run/'inputs_after.json',after)
        if after!=before:error='source/input drift'
        if not all((run/p).is_file() and sha(run/p)==h for p,h in load(run/'run_inputs_before.json').items()):error='run input/vector drift'
        if not all(Path(p).is_file() and sha(Path(p))==h for p,h in tool_inputs.items()):error='tool/model drift'
        verdict=check_natural_exit(native,stages[a.stage]['required_native'])
        complete=not error and verdict['status']=='PASS' and stages[a.stage]['pass_marker'] in text
        save(run/'stage_receipt.json',dict(utc=utc(),status='TOOL_COMPLETE' if complete else 'FAIL_OR_UNKNOWN',error=error,native=verdict,scope=stages[a.stage]['scope']))
    except Exception as exc:
        error=str(exc);save(run/'controller_exception.json',dict(utc=utc(),error=error,traceback=traceback.format_exc()));complete=False
    products={p.relative_to(run).as_posix():sha(p) for p in run.rglob('*') if p.is_file()}
    save(run/'product_manifest.json',products)
    state.update(utc=utc(),mode='awaiting_independent_acceptance' if complete else 'failed_or_unknown',active_run=None,monitor='PAUSED',last_run=str(run),last_error=error)
    save(state_path,state)
    if not complete:
        with (ROOT/'docs/error_ledger.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(utc=utc(),run=str(run),stage=a.stage,error=error,status='FAIL_OR_UNKNOWN'),ensure_ascii=False)+'\n')
    print(json.dumps(dict(run=str(run),status=state['mode'],error=error),ensure_ascii=False));return 0 if complete else 1

if __name__=='__main__':raise SystemExit(main())
