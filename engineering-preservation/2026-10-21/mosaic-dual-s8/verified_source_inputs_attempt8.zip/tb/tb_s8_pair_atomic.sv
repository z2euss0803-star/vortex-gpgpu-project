`timescale 1ns/1ps
// This isolated ready/valid fixture deliberately substitutes a combinational
// compute handshake model. Numeric acceptance comes from the real-DSP stage.
module s8_compute(input wire clk,reset,cmd_valid,output wire cmd_ready,
 input wire [12:0]k_count,input wire step_valid,output wire step_ready,
 input wire [127:0]a_flat,b_flat,output wire result_valid,input wire result_ready,
 output wire [3071:0]c_flat,output wire cmd_error);
 assign cmd_ready=!reset&&a_flat[0];assign step_ready=!reset&&a_flat[1];
 assign result_valid=!reset&&a_flat[2];assign cmd_error=0;assign c_flat=0;
 wire cmd_fire=cmd_ready&&cmd_valid,step_fire=step_ready&&step_valid;
endmodule
module tb_s8_pair_atomic;
reg clk=0;always #5 clk=~clk;
reg reset=1,pair_mode=0,cmd_valid=1,step_valid=1,result_ready=1;
reg[12:0] k_count=1;reg[127:0] a0_flat=0,a1_flat=0,b_flat=0;
wire cmd_ready,step_ready,result_valid,cmd_error;wire[3071:0] c0_flat,c1_flat;
VX_tcu_s8_pair dut(.*);
integer m,x,y,checks=0;
reg want_cmd,want_step,want_result;
initial begin
 #12;reset=0;
 for(m=0;m<2;m=m+1)for(x=0;x<8;x=x+1)for(y=0;y<8;y=y+1)begin
  @(negedge clk);pair_mode=m;a0_flat=x;a1_flat=y;#1;
  want_cmd=x[0]&&(!m||y[0]);want_step=x[1]&&(!m||y[1]);want_result=x[2]&&(!m||y[2]);
  if({cmd_ready,step_ready,result_valid}!=={want_cmd,want_step,want_result})$fatal(1,"ATOMIC_READY_VALID");
  if(dut.compute0.cmd_fire!==want_cmd||dut.compute0.step_fire!==want_step)$fatal(1,"UNILATERAL_BANK0_FIRE");
  if(dut.compute1.cmd_fire!==(m&&want_cmd)||dut.compute1.step_fire!==(m&&want_step))$fatal(1,"UNILATERAL_BANK1_FIRE");
  if(dut.compute0.result_ready!==want_result||dut.compute1.result_ready!==(m&&want_result))$fatal(1,"NONATOMIC_RESULT_RELEASE");
  checks=checks+1;
 end
 $display("PAIR_ATOMIC_PASS combinations=%0d scope=handshake_stub_only",checks);$finish;
end
initial begin #10000;$fatal(1,"ATOMIC_TIMEOUT");end
endmodule
