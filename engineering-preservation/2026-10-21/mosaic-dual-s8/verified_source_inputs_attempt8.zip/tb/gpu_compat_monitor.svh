`ifdef PAIR_COMPAT
integer compat_fd;
initial begin
  compat_fd=$fopen("gpu_compat_events.txt","w");
  if(!compat_fd)$fatal(1,"GPU_COMPAT_EVENTS_OPEN");
end
task automatic compat_request(input integer core,src,fmt,overlap,input VX_gpu_pkg::dispatch_t d);
  if($isunknown({d.uuid,d.PC,d.wis,d.sid,d.rd,d.tmask,d.wb,d.sop,d.eop}))$fatal(1,"GPU_COMPAT_REQUEST_META_UNKNOWN");
  if(d.sid!=0)$fatal(1,"GPU_COMPAT_UNEXPECTED_SID");
  $fdisplay(compat_fd,"0 %0d %0d %0d %h %h %0d %0d %h %0d %0d %0d %0d %0d",src,core,crt_cycles,d.uuid,d.PC,d.wis,d.rd,d.tmask,d.wb,d.sop,d.eop,fmt,overlap);
endtask
task automatic compat_response(input integer core,src,input VX_gpu_pkg::commit_t d);
  if($isunknown({d.uuid,d.PC,d.wid,d.sid,d.rd,d.tmask,d.wb,d.sop,d.eop,d.data}))$fatal(1,"GPU_COMPAT_RESULT_META_DATA_UNKNOWN");
  if(d.sid!=0)$fatal(1,"GPU_COMPAT_RESULT_SID");
  $fdisplay(compat_fd,"1 %0d %0d %0d %h %h %0d %0d %h %0d %0d %0d -1 0",src,core,crt_cycles,d.uuid,d.PC,d.wid,d.rd,d.tmask,d.wb,d.sop,d.eop);
endtask
`define CP_EXEC dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket.g_cores[cc].core.execute
for(genvar cc=0;cc<4;cc=cc+1)begin:g_compat_observer
  always @(posedge clk)if(resetn && !dut.gpu_reset)begin
    if(`CP_EXEC.tcu_unit.dispatch_if[0].valid && `CP_EXEC.tcu_unit.dispatch_if[0].ready)
      compat_request(cc,0,integer'(`CP_EXEC.tcu_unit.dispatch_if[0].data.op_args.tcu.fmt_s),integer'(`CP_EXEC.tcu_unit.g_blocks[0].tcu_int.g_native.native_core.active),`CP_EXEC.tcu_unit.dispatch_if[0].data);
    if(`CP_EXEC.tcu_unit.commit_if[0].valid && `CP_EXEC.tcu_unit.commit_if[0].ready)
      compat_response(cc,0,`CP_EXEC.tcu_unit.commit_if[0].data);
    if(`CP_EXEC.fpu_unit.dispatch_if[0].valid && `CP_EXEC.fpu_unit.dispatch_if[0].ready)
      compat_request(cc,1,integer'(`CP_EXEC.fpu_unit.dispatch_if[0].data.op_type),0,`CP_EXEC.fpu_unit.dispatch_if[0].data);
    if(`CP_EXEC.fpu_unit.commit_if[0].valid && `CP_EXEC.fpu_unit.commit_if[0].ready)
      compat_response(cc,1,`CP_EXEC.fpu_unit.commit_if[0].data);
    if(`CP_EXEC.tex_unit.dispatch_if.valid && `CP_EXEC.tex_unit.dispatch_if.ready)
      compat_request(cc,2,0,0,`CP_EXEC.tex_unit.dispatch_if.data);
    if(`CP_EXEC.tex_unit.commit_if.valid && `CP_EXEC.tex_unit.commit_if.ready)
      compat_response(cc,2,`CP_EXEC.tex_unit.commit_if.data);
  end
end
`undef CP_EXEC
`endif
