// Observe real decoded native requests and real final commit; no state injection.
`ifdef PAIR_BP
`include "gpu_bp_native_policy.svh"
`endif
integer gpu_steps_accepted[0:3],gpu_steps_retired[0:3],gpu_step_wb[0:3];
integer gpu_begins[0:3],gpu_releases[0:3],gpu_pages[0:3],gpu_bank0[0:3],gpu_bank1[0:3];
`ifdef PAIR_PROTOCOL
integer protocol_fd;
initial begin
  protocol_fd=$fopen("gpu_protocol_requests.txt","w");
  if(!protocol_fd)$fatal(1,"GPU_PROTOCOL_TRACE_OPEN");
end
`endif
`define GPU_CORE dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket.g_cores[gc].core
`define GPU_NATIVE `GPU_CORE.execute.tcu_unit.g_blocks[0].tcu_int.g_native.native_core
for(genvar gc=0;gc<4;gc=gc+1)begin:g_pair_observer
  bit step_pcs[bit[31:0]];
  always @(posedge clk)begin
    if(!resetn)begin
      gpu_steps_accepted[gc]=0;gpu_steps_retired[gc]=0;gpu_step_wb[gc]=0;
      gpu_begins[gc]=0;gpu_releases[gc]=0;gpu_pages[gc]=0;gpu_bank0[gc]=0;gpu_bank1[gc]=0;step_pcs.delete();
    end else if(!dut.gpu_reset)begin
      if(`GPU_NATIVE.execute_if.valid && `GPU_NATIVE.execute_if.ready)begin
        if($isunknown({`GPU_NATIVE.execute_if.data.PC,`GPU_NATIVE.execute_if.data.wid,`GPU_NATIVE.execute_if.data.tmask}))$fatal(1,"GPU_NATIVE_ID_UNKNOWN");
        `ifdef PAIR_PROTOCOL
        if(`GPU_NATIVE.execute_if.data.wid>3 || `GPU_NATIVE.execute_if.data.tmask!=4'hf)$fatal(1,"GPU_PROTOCOL_WARP_OR_MASK");
        if($isunknown({`GPU_NATIVE.error,`GPU_NATIVE.cmd_valid,`GPU_NATIVE.step_valid,`GPU_NATIVE.release_fire}))$fatal(1,"GPU_PROTOCOL_EFFECT_UNKNOWN");
        $fdisplay(protocol_fd,"%0d %0d %0d %0d %0d %0d %0d %0d %0d",crt_cycles,gc,`GPU_NATIVE.execute_if.data.wid,`GPU_NATIVE.execute_if.data.op_args.tcu.fmt_s,`GPU_NATIVE.execute_if.data.op_args.tcu.fmt_d,`GPU_NATIVE.error,`GPU_NATIVE.cmd_valid,`GPU_NATIVE.step_valid,`GPU_NATIVE.release_fire);
        `elsif PAIR_BP
        if(!gpu_bp_native_allowed(`GPU_NATIVE.execute_if.data.wid,
           `GPU_NATIVE.execute_if.data.tmask,`GPU_NATIVE.execute_if.data.op_args.tcu.fmt_s,
           `GPU_NATIVE.execute_if.data.op_args.tcu.fmt_d,`GPU_NATIVE.execute_if.data.rs3_data))
          $fatal(1,"GPU_BP_OWNER_OR_QUERY");
        if(`GPU_NATIVE.execute_if.data.wid!=0 &&
           ({`GPU_NATIVE.error,`GPU_NATIVE.cmd_valid,`GPU_NATIVE.step_valid,`GPU_NATIVE.release_fire} !== 7'b0))
          $fatal(1,"GPU_BP_QUERY_SIDE_EFFECT");
        `else
        if(`GPU_NATIVE.execute_if.data.wid!=0 || `GPU_NATIVE.execute_if.data.tmask!=4'hf)$fatal(1,"GPU_OWNER_OR_MASK");
        `endif
        case(`GPU_NATIVE.execute_if.data.op_args.tcu.fmt_s)
          13:gpu_begins[gc]=gpu_begins[gc]+1;
          14:begin gpu_steps_accepted[gc]=gpu_steps_accepted[gc]+1;step_pcs[32'(`GPU_NATIVE.execute_if.data.PC)]=1;end
          15:if(`GPU_NATIVE.execute_if.data.rs3_data[0][8])gpu_releases[gc]=gpu_releases[gc]+1;
        endcase
      end
      if(`GPU_NATIVE.result_if.valid && `GPU_NATIVE.result_if.ready && `GPU_NATIVE.response_page)begin
        gpu_pages[gc]=gpu_pages[gc]+1;
        `ifdef PAIR_CANDIDATE
        if(`GPU_NATIVE.response_bank)gpu_bank1[gc]=gpu_bank1[gc]+1;
        else gpu_bank0[gc]=gpu_bank0[gc]+1;
        `else
        gpu_bank0[gc]=gpu_bank0[gc]+1;
        `endif
      end
      if(`GPU_CORE.commit.commit_arb_if[0].valid && `GPU_CORE.commit.commit_arb_if[0].ready)begin
        if(step_pcs.exists(32'(`GPU_CORE.commit.commit_arb_if[0].data.PC)))begin
          gpu_steps_retired[gc]=gpu_steps_retired[gc]+1;
          if(`GPU_CORE.commit.commit_arb_if[0].data.wb)gpu_step_wb[gc]=gpu_step_wb[gc]+1;
        end
      end
    end
  end
end
`undef GPU_NATIVE
`undef GPU_CORE
