`timescale 1ns/1ps
module tb_reset_guard;
  reg clk=0; always #5 clk=~clk;
  reg resetn=0;
  reg gpu_reset;
  wire cluster_reset, socket_reset, local_reset;
  reg incr=0;
  reg [1:0] decr=0;
  wire empty, alm_empty, full, alm_full;
  wire [2:0] size;
  integer case_id=0, edges=0;
  reg converged=0;
  always @(posedge clk) gpu_reset <= ~resetn;
  VX_reset_relay #(.N(1), .MAX_FANOUT(0)) cluster_relay(clk,gpu_reset,cluster_reset);
  VX_reset_relay #(.N(1), .MAX_FANOUT(0)) socket_relay(clk,cluster_reset,socket_reset);
  VX_reset_relay #(.N(1), .MAX_FANOUT(0)) cache_relay(clk,socket_reset,local_reset);
  VX_pending_size #(.SIZE(7), .INCRW(1), .DECRW(2)) counter(.*,.reset(local_reset));
  // Fixture mirrors the registered cold-reset chain. No force or deposit.
  always @(posedge clk) begin
    edges=edges+1;
    #1;
    if (edges==8) begin
      if (resetn !== 1'b0 || local_reset !== 1'b1 || size !== 3'd0 ||
          empty !== 1'b1 || full !== 1'b0)
        $fatal(1,"RESET_GUARD_CONVERGENCE_FAILED");
      converged=1;
      $display("RESET_GUARD_CONVERGENCE_PASS");
    end
    if (converged && $isunknown({local_reset,size,empty,full}))
      $fatal(1,"RESET_GUARD_STATE_UNKNOWN");
  end
  initial begin
    if (!$value$plusargs("CASE=%d",case_id)) case_id=0;
    $display("RESET_GUARD_CASE=%0d",case_id);
    if (case_id==3) resetn=1'bx;
    repeat(10) @(negedge clk);
    resetn=1;
    repeat(6) @(negedge clk);
    if (local_reset !== 1'b0 || size !== 0) $fatal(1,"RESET_GUARD_RELEASE_FAILED");
    case (case_id)
      0: begin
        incr=1; @(negedge clk); incr=0;
        if (size !== 1 || empty !== 0) $fatal(1,"RESET_GUARD_LEGAL_INCREMENT_FAILED");
        decr=1; @(negedge clk); decr=0;
        if (size !== 0 || empty !== 1) $fatal(1,"RESET_GUARD_LEGAL_DECREMENT_FAILED");
        $display("RESET_GUARD_NORMAL_PASS");
      end
      1: begin decr=1; @(negedge clk); decr=0; end
      2: begin incr=1; repeat(8) @(negedge clk); incr=0; end
      default: $fatal(1,"RESET_GUARD_INVALID_CASE");
    endcase
    #10; $finish;
  end
  initial begin #2000; $fatal(1,"RESET_GUARD_TIMEOUT"); end
endmodule
