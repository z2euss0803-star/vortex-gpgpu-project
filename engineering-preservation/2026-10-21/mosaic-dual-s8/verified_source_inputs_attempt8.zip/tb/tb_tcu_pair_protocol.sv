`timescale 1ns/1ps
`include "VX_define.vh"
module tb_tcu_pair_protocol;
import VX_gpu_pkg::*;import VX_tcu_pkg::*;
reg clk=0,reset=1,legacy_compare=0;always #5 clk=~clk;
VX_execute_if #(.data_t(tcu_exe_t)) ex(),rex();
VX_result_if #(.data_t(tcu_res_t)) res(),rres();
VX_tcu_native_s8 dut(.clk(clk),.reset(reset),.execute_if(ex),.result_if(res));
VX_tcu_native_s8_ref old(.clk(clk),.reset(reset),.execute_if(rex),.result_if(rres));
assign rex.valid=ex.valid&&legacy_compare;assign rex.data=ex.data;assign rres.ready=res.ready;
reg [127:0] packet; tcu_res_t reply,held;
reg held_previous=0;
integer seq=0,sent=0,received=0,cases,idx,n,k,mode,dest,owner_w,bank,p,t,spec,rc,checks=0;
reg [383:0] vectors[0:4095];reg [47:0] golden[0:127];reg [6143:0] raw;
string vector_name,golden_name;
always @(negedge clk)begin
 #1;
 if(!reset&&legacy_compare)begin
  if(ex.ready!==rex.ready||res.valid!==rres.valid)$fatal(1,"OLD_NATIVE_CONTROL_CHANGED");
  if(res.valid&&res.data!==rres.data)$fatal(1,"OLD_NATIVE_RESPONSE_CHANGED");
 end
end
always @(posedge clk)begin
 if(reset)held_previous<=0;
 else begin
  if(held_previous&&(!res.valid||res.data!==held))$fatal(1,"HELD_PAGE_OR_METADATA_CHANGED");
  held_previous<=res.valid&&!res.ready;held<=res.data;
 end
end
task automatic do_reset;
 begin
  @(negedge clk);reset=1;ex.valid=0;res.ready=0;
  repeat(4)@(negedge clk);reset=0;repeat(2)@(negedge clk);
  if(res.valid)$fatal(1,"RESET_RESPONSE_VALID");
 end
endtask
task automatic request(input integer op,d,w,input reg[127:0] a,b,c,input reg[3:0] mask,input integer hold_cycles);
 integer h;
 begin
  @(negedge clk);ex.data='0;ex.data.op_args.tcu.fmt_s=4'(op);ex.data.op_args.tcu.fmt_d=4'(d);
  ex.data.wid=NW_WIDTH'(w);ex.data.tmask=mask;ex.data.uuid=UUID_WIDTH'(seq);ex.data.PC=PC_BITS'(seq+80);
  ex.data.rd=make_reg_num(REG_TYPE_F,10);ex.data.wb=(op!=14);ex.data.sop=1;ex.data.eop=1;
  ex.data.rs1_data=a;ex.data.rs2_data=b;ex.data.rs3_data=c;ex.valid=1;res.ready=0;
  do @(posedge clk);while(!ex.ready);sent=sent+1;
  @(negedge clk);ex.valid=0;
  // Change the bus after acceptance; response data/bank/page must be a snapshot.
  for(h=0;h<hold_cycles;h=h+1)begin ex.data.rs3_data=c^128'h20;@(negedge clk);end
  res.ready=1;do @(posedge clk);while(!res.valid);
  reply=res.data;received=received+1;packet=reply.data;
  if(reply.uuid!==UUID_WIDTH'(seq)||reply.wid!==NW_WIDTH'(w)||reply.PC!==PC_BITS'(seq+80)||reply.tmask!==mask||reply.rd!==make_reg_num(REG_TYPE_F,10)||reply.wb!==(op!=14)||!reply.sop||!reply.eop)$fatal(1,"PROTOCOL_METADATA");
  @(negedge clk);res.ready=0;seq=seq+1;
 end
endtask
task automatic status(input integer d,w,code);
 begin
  request(15,d,w,0,0,128'd31,15,2);
  if(packet[31:0]!==32'(code))$fatal(1,"STATUS_CODE expected=%0d got=%0d",code,packet[31:0]);
 end
endtask
initial begin
 ex.valid=0;ex.data='0;res.ready=0;repeat(16)@(negedge clk);reset=0;
 request(13,3,0,0,0,128'd1,15,0);
 if(packet[31:0]!==0)$fatal(1,"PAIR_BEGIN_NOT_SUPPORTED");do_reset();
 spec=$fopen("cases.txt","r");if(!spec)$fatal(1,"NO_NATIVE_CASES");rc=$fscanf(spec,"%d\n",cases);
 for(idx=0;idx<cases;idx=idx+1)begin
  rc=$fscanf(spec,"%d %d %s %s\n",mode,k,vector_name,golden_name);if(rc!=4)$fatal(1,"BAD_NATIVE_CASE");
  do_reset();legacy_compare=!mode;dest=mode?3:8;owner_w=idx%4;
  $readmemh(vector_name,vectors,0,k-1);$readmemh(golden_name,golden,0,127);
  request(13,dest,owner_w,0,0,128'(k),15,3);
  if(packet[31:0]!==0||packet[63:32]!==0||packet[95:64]!==32'(k)||packet[127:96]!==32'(mode?9:1))$fatal(1,"BEGIN_STATE");
  for(t=0;t<4;t=t+1)if(t!=owner_w)begin
   request(13,dest,t,0,0,128'(k),15,0);if(packet[31:0]!==1||packet[127:32]!==0)$fatal(1,"BUSY_OR_OWNER_LEAK");
   request(14,dest,t,0,0,0,15,0);status(dest,t,3);if(packet[127:32]!==0)$fatal(1,"COUNTER_LEAK");
  end
  status(dest,owner_w,4);
  for(n=0;n<k;n=n+1)request(14,dest,owner_w,vectors[n][127:0],vectors[n][255:128],vectors[n][383:256],15,n%3);
  repeat(5)@(negedge clk);status(dest,owner_w,0);
  if(packet[63:32]!==32'(k)||packet[95:64]!==32'(k)||packet[97:96]!==3)$fatal(1,"PAIR_K_OR_DRAIN");
  raw=0;
  for(bank=mode;bank>=0;bank=bank-1)begin
   for(t=0;t<24;t=t+1)begin
    p=(t*7)%24;
    request(15,dest,owner_w,0,0,128'((bank<<5)|p),15,t%5);
    raw[bank*3072+p*128+:128]=packet;
   end
   if(mode)begin
    status(dest,owner_w,0);
    if(!bank&&(packet[101:98]!==4'b1111))$fatal(1,"BOTH_BANK_CAPTURE_FLAGS");
    if(bank&&(packet[101:98]!==4'b1010))$fatal(1,"BANK_SELECTION_CAPTURE_FLAGS");
   end
  end
  for(n=0;n<(mode?128:64);n=n+1)begin
   if(raw[n*48+:48]!==golden[n])$fatal(1,"NATIVE_BANK_VALUE case=%0d index=%0d",idx,n);
   checks=checks+1;
  end
  request(15,dest,owner_w,0,0,128'h11f,15,4);if(packet[31:0]!==0)$fatal(1,"RELEASE_REJECTED");
  status(dest,owner_w,0);if(packet[127:32]!==0)$fatal(1,"RELEASE_NOT_IDLE");
  $display("PAIR_NATIVE_CASE_PASS case=%0d pair=%0d K=%0d",idx,mode,k);
 end
 $fclose(spec);legacy_compare=0;
 for(t=0;t<2;t=t+1)begin
  do_reset();dest=t?3:8;
  request(13,dest,0,0,0,0,15,0);if(packet[31:0]!==2)$fatal(1,"BAD_K_ZERO");
  request(13,dest,0,0,0,128'd4097,15,0);if(packet[31:0]!==2)$fatal(1,"BAD_K_HIGH");
  request(13,dest,0,0,0,128'd8193,15,0);if(packet[31:0]!==8)$fatal(1,"BAD_RESERVED_BEGIN");
  request(13,dest,0,0,0,128'd1,7,0);if(packet[31:0]!==9)$fatal(1,"BAD_MASK");
 end
 do_reset();request(13,3,0,0,0,128'd1,15,0);
 request(14,8,0,0,0,0,15,0);status(3,0,8);if(packet[63:32]!==0)$fatal(1,"WRONG_MODE_ADVANCED_K");
 request(15,8,0,0,0,128'd31,15,0);if(packet[31:0]!==8||packet[127:32]!==0)$fatal(1,"WRONG_MODE_STATUS_LEAK");
 request(15,3,0,0,0,128'h3f,15,0);if(packet[31:0]!==8)$fatal(1,"STATUS_BANK1_ALLOWED");
 for(p=24;p<31;p=p+1)begin request(15,3,0,0,0,128'(p),15,0);if(packet!==0)$fatal(1,"BAD_PAGE_DATA");status(3,0,5);end
 request(15,3,0,0,0,128'h100,15,0);if(packet!==0)$fatal(1,"RELEASE_ON_DATA");status(3,0,8);
 request(15,3,0,0,0,128'h13f,15,0);if(packet[31:0]!==8)$fatal(1,"RELEASE_BANK1_ALLOWED");
 request(15,3,0,0,0,128'h11f,15,0);if(packet[31:0]!==7)$fatal(1,"PREMATURE_RELEASE");
 do_reset();request(13,3,0,0,0,128'd1,15,0);request(14,3,0,0,0,0,15,0);repeat(5)@(negedge clk);
 for(p=0;p<24;p=p+1)request(15,3,0,0,0,128'(p),15,2);
 for(p=0;p<23;p=p+1)request(15,3,0,0,0,128'(32+p),15,2);
 request(15,3,0,0,0,128'h11f,15,0);if(packet[31:0]!==7)$fatal(1,"MISSING_BANK1_PAGE_RELEASED");
 request(15,3,0,0,0,128'h37,15,3);
 request(15,3,0,0,0,128'h11f,15,0);if(packet[31:0]!==0)$fatal(1,"COMPLETE_RELEASE_REJECTED");
 do_reset();if(sent!=received)$fatal(1,"NATIVE_RESPONSE_ACCOUNTING");
 $display("PAIR_NATIVE_PROTOCOL_PASS cases=%0d values=%0d requests=%0d responses=%0d scope=native_adapter_not_full_TCU_or_GPU",cases,checks,sent,received);$finish;
end
initial begin #30000000;$fatal(1,"NATIVE_GLOBAL_TIMEOUT");end
endmodule
