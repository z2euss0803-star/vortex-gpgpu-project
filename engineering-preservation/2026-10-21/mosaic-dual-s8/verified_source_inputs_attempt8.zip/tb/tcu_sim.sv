`include "VX_define.vh"
// Test-only wire adapter: retains exact dispatch_t / commit_t bits and handshake.
// It is not a production interface change and adds no registers.
module tcu_sim import VX_gpu_pkg::*; (
 input wire clk,reset,
 input wire [`ISSUE_WIDTH-1:0] in_valid,
 input wire [`ISSUE_WIDTH-1:0][$bits(dispatch_t)-1:0] in_data,
 output wire [`ISSUE_WIDTH-1:0] in_ready,
 output wire [`ISSUE_WIDTH-1:0] out_valid,
 output wire [`ISSUE_WIDTH-1:0][$bits(commit_t)-1:0] out_data,
 input wire [`ISSUE_WIDTH-1:0] out_ready
);
 VX_dispatch_if di[`ISSUE_WIDTH]();
 VX_commit_if co[`ISSUE_WIDTH]();
 for(genvar i=0;i<`ISSUE_WIDTH;i++)begin
  assign di[i].valid=in_valid[i]; assign di[i].data=in_data[i]; assign in_ready[i]=di[i].ready;
  assign out_valid[i]=co[i].valid; assign out_data[i]=co[i].data; assign co[i].ready=out_ready[i];
 end
 VX_tcu_unit #(.INSTANCE_ID("ooc")) unit(.clk(clk),.reset(reset),.dispatch_if(di),.commit_if(co));
endmodule
