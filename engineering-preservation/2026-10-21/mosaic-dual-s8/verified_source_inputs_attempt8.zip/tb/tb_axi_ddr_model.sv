`timescale 1ns/1ps
module tb_axi_ddr_model;
  reg clk=0;always #5 clk=~clk;
  reg resetn=0,job_active=0;
  reg [48:0] HP_awaddr=49'h500000000,HP_araddr=49'h500000000;
  reg [7:0] HP_awlen=0,HP_arlen=0;
  reg [2:0] HP_awsize=6,HP_arsize=6;
  reg [5:0] HP_awid=17,HP_arid=29;
  reg HP_awvalid=0,HP_wvalid=0,HP_wlast=1,HP_arvalid=0,HP_bready=0,HP_rready=0;
  reg [511:0] HP_wdata=0;
  reg [63:0] HP_wstrb=0;
  wire HP_awready,HP_wready,HP_arready,HP_bvalid,HP_rvalid,HP_rlast;
  wire [5:0] HP_bid,HP_rid;
  wire [1:0] HP_bresp,HP_rresp;
  wire [511:0] HP_rdata;
  axi_ddr_model memory_bus(.*);
  reg [511:0] snapshot;
  integer case_id=0;
  task automatic aw;
    @(negedge clk);HP_awvalid=1;
    do @(posedge clk);while(!HP_awready);
    @(negedge clk);HP_awvalid=0;
  endtask
  task automatic w;
    @(negedge clk);HP_wvalid=1;
    do @(posedge clk);while(!HP_wready);
    @(negedge clk);HP_wvalid=0;
  endtask
  task automatic check_b;
    while(!HP_bvalid)@(negedge clk);
    if(HP_bid!==17 || HP_bresp!==0)$fatal(1,"MODEL_TEST_B_ID");
    repeat(6)begin @(negedge clk);if(!HP_bvalid || HP_bid!==17 || HP_bresp!==0)$fatal(1,"MODEL_TEST_B_STABILITY");end
    HP_bready=1;@(negedge clk);HP_bready=0;
  endtask
  task automatic read_line;
    @(negedge clk);HP_arvalid=1;
    do @(posedge clk);while(!HP_arready);
    @(negedge clk);HP_arvalid=0;
    while(!HP_rvalid)@(negedge clk);
    snapshot=HP_rdata;
    if(HP_rid!==29 || HP_rresp!==0 || HP_rlast!==1)$fatal(1,"MODEL_TEST_R_ID");
    repeat(6)begin @(negedge clk);if(!HP_rvalid || HP_rdata!==snapshot || HP_rid!==29)$fatal(1,"MODEL_TEST_R_STABILITY");end
    HP_rready=1;@(negedge clk);HP_rready=0;
  endtask
  initial begin
    if($value$plusargs("NEGATIVE=%d",case_id))begin end
    if(case_id==5 || case_id==6)begin
      memory_bus.register_region("boundary_rw",64'h500000000,8,"rw",8'h5a);
      memory_bus.register_region("boundary_padding",64'h500000008,56,"r",8'h5a);
      memory_bus.register_region("second",64'h500000040,64,"rw",8'h5a);
    end else if(case_id==7)
      memory_bus.register_region("stack_0",64'h500000000,128,"rw",8'h5a,1);
    else if(case_id==9)
      memory_bus.register_region("stack_0",64'h500000000,128,"r",8'h5a,1);
    else memory_bus.register_region("unit",64'h500000000,128,"rw",8'h5a);
    if($value$plusargs("NEGATIVE=%d",case_id))begin
      if(case_id==1)memory_bus.register_region("overlap",64'h500000020,64,"rw",0);
      if(case_id==2)begin snapshot[7:0]=memory_bus.peek_byte(64'h500000080);end
    end
    repeat(5)@(negedge clk);resetn=1;
    if(case_id==3)begin HP_awid=6'bxxxxxx;aw();end
    if(case_id==4)begin HP_wstrb=64'bx;w();end
    if(case_id>=7 && case_id<=9)begin
      // W first: policy must wait for the independently accepted AW address.
      HP_wdata='0;HP_wdata[7:0]=8'b10x101z0;HP_wstrb=1;
      w();repeat(3)@(negedge clk);aw();check_b();read_line();
      if(snapshot[7:0]!==8'b10x101z0 || memory_bus.peek_byte(64'h500000000)!==8'b10x101z0 ||
         snapshot[511:8]!=={63{8'h5a}})$fatal(1,"MODEL_TEST_X_COERCION");
      $display("AXI_DDR_MODEL_STACK_X_PASS four_state_preserved=1 selected_bytes=1 unstrobed_known=63");
      $finish;
    end
    for(integer j=0;j<64;j=j+1)HP_wdata[j*8+:8]=j;
    HP_wstrb=case_id==6 ? 64'h00000000000001ff : 64'h00000000000000ff;
    w();repeat(3)@(negedge clk);aw();check_b();read_line();
    for(integer j=0;j<64;j=j+1)
      if(snapshot[j*8+:8] !== (j<8 ? 8'(j) : 8'h5a))$fatal(1,"MODEL_TEST_PARTIAL_WRITE %0d",j);
    HP_awaddr=49'h500000040;HP_araddr=49'h500000040;HP_wstrb=64'hffffffffffffffff;
    aw();repeat(3)@(negedge clk);w();check_b();read_line();
    if(snapshot!==HP_wdata || memory_bus.reads!=2 || memory_bus.writes!=2)$fatal(1,"MODEL_TEST_COUNTS");
    if(case_id==5)$display("AXI_DDR_MODEL_BOUNDARY_PASS writes=2 reads=2 readonly_unstrobed=56");
    else $display("AXI_DDR_MODEL_PASS writes=2 reads=2 AW_W_independent=2 backpressure=12");$finish;
  end
  initial begin #20000;$fatal(1,"MODEL_TEST_TIMEOUT");end
endmodule
