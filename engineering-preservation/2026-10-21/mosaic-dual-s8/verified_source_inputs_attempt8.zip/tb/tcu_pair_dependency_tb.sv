`timescale 1ns/1ps
`include "VX_define.vh"
module tcu_pair_dependency_tb(output reg finished);
 import VX_gpu_pkg::*;
 import VX_tcu_pkg::*;
 reg clk=0,reset=1;
 always #5 clk=~clk;
 VX_ibuffer_if ib[PER_ISSUE_WARPS]();
 VX_scoreboard_if sc();
 VX_commit_if ci[NUM_EX_UNITS*`ISSUE_WIDTH]();
 VX_writeback_if wb[`ISSUE_WIDTH]();
 VX_commit_csr_if csr();
 VX_commit_sched_if sched();
 VX_scoreboard sb(.clk(clk),.reset(reset),.writeback_if(wb[0]),.ibuffer_if(ib),.scoreboard_if(sc));
 VX_commit cm(.clk(clk),.reset(reset),.commit_if(ci),.writeback_if(wb),.commit_csr_if(csr),.commit_sched_if(sched));
 ibuffer_t uin,uout, driven;
 VX_tcu_uops uu(.clk(clk),.reset(reset),.ibuf_in(uin),.ibuf_out(uout),.start(1'b0),.next(1'b0),.done());
 reg iv=0,cv=0;
 commit_t cd;
 integer sb_count=0,retired=0,writebacks=0;
 assign ib[0].valid=iv;assign ib[0].data=driven;
 for(genvar g=1;g<PER_ISSUE_WARPS;g=g+1)begin
  assign ib[g].valid=0;assign ib[g].data='0;
 end
 for(genvar g=0;g<NUM_EX_UNITS*`ISSUE_WIDTH;g=g+1)begin
  assign ci[g].valid=(g==EX_TCU*`ISSUE_WIDTH)&&cv;
  assign ci[g].data=cd;
 end
 always @(posedge clk)if(!reset)begin
  if(sc.valid&&sc.ready)sb_count=sb_count+1;
  if(sched.committed_warps[0])retired=retired+1;
  if(wb[0].valid)writebacks=writebacks+1;
 end
 task push(input ibuffer_t d);
 begin
  @(negedge clk);driven=d;iv=1;
  do @(posedge clk);while(!ib[0].ready);
  @(negedge clk);iv=0;
 end endtask
 task wait_sc(input integer count);
 begin
  for(integer n=0;n<30&&sb_count<count;n=n+1)@(negedge clk);
  if(sb_count!=count)$fatal(1,"SCOREBOARD_EXPECTED %0d GOT %0d",count,sb_count);
 end endtask
 task commit_one(input reg writes);
 begin
  @(negedge clk);cd='0;cd.wid=0;cd.wb=writes;cd.tmask=4'hf;cd.rd=make_reg_num(REG_TYPE_F,10);cd.sop=1;cd.eop=1;cv=1;
  do @(posedge clk);while(!ci[EX_TCU*`ISSUE_WIDTH].ready);
  @(negedge clk);cv=0;
  repeat(4)@(negedge clk);
 end endtask
 initial begin
  finished=0;sc.ready=1;uin='0;driven='0;cd='0;
  if(`ISSUE_WIDTH!=1)$fatal(1,"DEPENDENCY_FIXTURE_ISSUE_WIDTH");
  repeat(5)@(negedge clk);reset=0;
  // Reserve f10 using a real staged write; intentionally withhold its commit.
  uin.ex_type=EX_TCU;uin.op_type=INST_TCU_WMMA;uin.tmask=4'hf;uin.rd=make_reg_num(REG_TYPE_F,10);uin.wb=1;uin.used_rs=0;
  push(uin);wait_sc(1);
  // Real TCU uops produce STEP dependencies while f10 stays reserved.
  uin.op_args.tcu.fmt_s=14;uin.op_args.tcu.fmt_d=8;uin.used_rs=3'b111;
  #1;push(uout);wait_sc(2);commit_one(0);
  #1;push(uout);wait_sc(3);commit_one(0);
  if(retired!=2||writebacks!=0)$fatal(1,"STEP_RETIRE_WITHOUT_WRITEBACK retired=%0d wb=%0d",retired,writebacks);
  uin.op_args.tcu.fmt_s=15;#1;push(uout);
  repeat(8)@(negedge clk);
  if(sb_count!=3)$fatal(1,"READ_DID_NOT_WAIT_FOR_F10");
  commit_one(1);wait_sc(4);
  if(retired!=3||writebacks!=1)$fatal(1,"ORIGINAL_WRITEBACK_RELEASE");
  // READ now owns f10. Pair STEP must wait for that actual writeback.
  uin.op_args.tcu.fmt_s=14;uin.op_args.tcu.fmt_d=3;#1;push(uout);
  repeat(8)@(negedge clk);
  if(sb_count!=4)$fatal(1,"PAIR_STEP_DID_NOT_WAIT_F10");
  commit_one(1);wait_sc(5);commit_one(0);
  #1;push(uout);wait_sc(6);commit_one(0);
  if(retired!=6||writebacks!=2)$fatal(1,"PAIR_STEP_RETIRE_OR_WRITEBACK");
  $display("PAIR_DEPENDENCY_COMMIT_PASS single_steps=2 pair_steps=2 step_writeback=0");finished=1;
 end
 initial begin #10000;if(!finished)$fatal(1,"DEPENDENCY_TIMEOUT");end
endmodule
