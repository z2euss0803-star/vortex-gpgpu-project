`timescale 1ns/1ps
`include "VX_define.vh"
module tcu_legacy_tb(output reg done);
 import VX_gpu_pkg::*;
 reg clk=0,reset=1,iv=0,oready=0;
 dispatch_t din;
 wire ri,ci,rv,cv;
 wire [$bits(commit_t)-1:0] rb,cb;
 commit_t rout,cout;
 assign rout=rb; assign cout=cb;
 tcu_sim_ref reference_unit(clk,reset,iv,din,ri,rv,rb,oready);
 tcu_sim candidate_unit(clk,reset,iv,din,ci,cv,cb,oready);
 always #5 clk=~clk;
 reg [127:0] expect_data[0:8191];
 reg pending[0:8191];
 reg [1:0] expect_wid[0:8191];
 reg [4:0] expect_rd[0:8191];
 integer cycle=0,sent=0,returned=0,stalls=0,resets=0,id=1,fmt,seed=20261012,k,i,j,bits,s,av,bv,a,b,index;
 integer accepted_cycle[0:8191];
 integer reset_discarded=0;
 integer burst_returns=0,burst_first=-1,burst_last=-1,burst_latency_min=9999,burst_latency_max=0;
 reg [31:0] accum;
 reg [127:0] computed;
 reg blocked=0;
 reg [$bits(commit_t)-1:0] held;
 reg [7:0] fmts[0:5];
 task build(input integer ident,input integer format);
 begin
  din='0;din.PC=ident;din.wis=ident%4;din.rd=ident%32;din.wb=1;din.tmask=15;din.sop=1;din.eop=1;
  din.op_args.tcu.fmt_s=format;din.op_args.tcu.fmt_d=(format>=8)?8:0;
  din.op_args.tcu.step_m=ident%4;din.op_args.tcu.step_n=ident%2;
  for(k=0;k<4;k=k+1)begin
   din.rs1_data[k]=$random(seed);din.rs2_data[k]=$random(seed);din.rs3_data[k]=$random(seed);
   if(format<8)begin din.rs1_data[k]=32'h3c003c00;din.rs2_data[k]=32'h3c003c00;din.rs3_data[k]=0;
    if(format==2)begin din.rs1_data[k]=32'h3f803f80;din.rs2_data[k]=32'h3f803f80;end
   end
  end
  for(i=0;i<2;i=i+1)for(j=0;j<2;j=j+1)begin
   accum=din.rs3_data[2*i+j];bits=(format==9||format==10)?8:4;
   for(k=0;k<2;k=k+1)begin
    a=din.rs1_data[2*i+k];b=din.rs2_data[2*j+k];
    for(s=0;s<32;s=s+bits)begin
     av=(a>>s)&((1<<bits)-1);bv=(b>>s)&((1<<bits)-1);
     if(format==9||format==11)begin if(av&(1<<(bits-1)))av=av-(1<<bits);if(bv&(1<<(bits-1)))bv=bv-(1<<bits);end
     accum=accum+av*bv;
    end
   end
   computed[32*(2*i+j)+:32]=(format<8)?32'h40800000:accum;
  end
 end endtask
 initial begin
  done=0;
  fmts[0]=9;fmts[1]=10;fmts[2]=11;fmts[3]=12;fmts[4]=1;fmts[5]=2;
  for(index=0;index<8192;index=index+1)pending[index]=0;
  repeat(6)@(negedge clk);reset=0;
  build(id,9);iv=0;
  for(cycle=0;cycle<13000;cycle=cycle+1)begin
   @(negedge clk);
   // Long backpressure, random bubbles, FP/integer interleaving, reset with inflight traffic.
   oready=(cycle<256)||(cycle%71>15);
   if(cycle==300||cycle==3500)begin reset=1;iv=0;resets=resets+1;for(index=0;index<8192;index=index+1)begin
     if(pending[index])reset_discarded=reset_discarded+1;pending[index]=0;
   end end
   else if(reset)begin reset=0;build(id,fmts[id%6]);iv=1;end
   @(posedge clk);
   if(!reset)begin
    if(ri!==ci||rv!==cv)$fatal(1,"handshake cycle=%0d",cycle);
    if(blocked && (!rv || rb!==held))$fatal(1,"output not stable during backpressure");
    blocked=rv&&!oready;held=rb;
    if(rv && rb!==cb)$fatal(1,"TCU differential cycle=%0d",cycle);
    if(rv && !oready)stalls=stalls+1;
    if(rv&&oready)begin
     index=rout.PC;
     if(!pending[index])$fatal(1,"unexpected/duplicate output PC=%0d",index);
     if(rout.data!==expect_data[index])$fatal(1,"TCU oracle PC=%0d expected=%h got=%h",index,expect_data[index],rout.data);
     if(rout.wid!==expect_wid[index]||rout.rd!==expect_rd[index]||rout.tmask!==4'hf||rout.wb!==1||rout.sop!==1||rout.eop!==1||rout.sid!==0)$fatal(1,"metadata PC=%0d",index);
     pending[index]=0;returned=returned+1;
     if(index<=128)begin
      if(burst_first<0)burst_first=cycle;burst_last=cycle;burst_returns=burst_returns+1;
      if(cycle-accepted_cycle[index]<burst_latency_min)burst_latency_min=cycle-accepted_cycle[index];
      if(cycle-accepted_cycle[index]>burst_latency_max)burst_latency_max=cycle-accepted_cycle[index];
     end
    end
    if(iv&&ri)begin
     pending[id]=1;expect_data[id]=computed;expect_wid[id]=din.wis;expect_rd[id]=din.rd;accepted_cycle[id]=cycle;sent=sent+1;id=id+1;
     #1;iv=0;
    end
   end else blocked=0;
   #2;
   if(!reset&&!iv&&id<6000&&cycle<11000&&(cycle<256||cycle%9!=0))begin build(id,(id<=128)?((id%2)?9:10):fmts[id%6]);iv=1;end
  end
  for(index=0;index<8192;index=index+1)if(pending[index])$fatal(1,"not drained PC=%0d",index);
  if(returned<1000||stalls==0||resets!=2)$fatal(1,"insufficient coverage");
  if(burst_returns!=128||burst_last-burst_first!=127||burst_latency_min!=burst_latency_max)$fatal(1,"integer sustained throughput/latency");
  $display("TCU_PERF integer_burst=%0d output_span_cycles=%0d latency_min=%0d latency_max=%0d II=1",burst_returns,burst_last-burst_first,burst_latency_min,burst_latency_max);
  if(sent!=returned+reset_discarded)$fatal(1,"LEGACY_UNACCOUNTED_LOSS");
  $display("LEGACY_CYCLE_EQ_PASS sent=%0d returned=%0d reset_discarded=%0d stalls=%0d resets=%0d",sent,returned,reset_discarded,stalls,resets);done=1;
 end
 initial begin #200000;if(!done)$fatal(1,"legacy timeout");end
endmodule
