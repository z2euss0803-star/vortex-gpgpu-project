// One actual ELF/job per fresh XSim invocation. No legacy shadow memory or force.
reg [31:0] crt_value;
reg [3:0] crt_cores_seen=0;
integer crt_cycles=0;
always @(posedge clk) if(resetn) begin
  crt_cycles<=crt_cycles+1;
  crt_cores_seen<=crt_cores_seen | dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket.per_core_busy;
end
`ifdef PAIR_REOPEN
else crt_cores_seen<=0;
`endif

task automatic crt_aw(input integer offset);
  @(negedge clk);HPM_awaddr=40'ha0000000+offset;HPM_awid=16'h1234;
  HPM_awsize=2;HPM_awburst=1;HPM_awvalid=1;
  do @(posedge clk);while(!HPM_awready);
  @(negedge clk);HPM_awvalid=0;
endtask
task automatic crt_w(input [31:0] data);
  repeat(3)@(negedge clk);HPM_wdata=data;HPM_wstrb=15;HPM_wlast=1;HPM_wvalid=1;
  do @(posedge clk);while(!HPM_wready);
  @(negedge clk);HPM_wvalid=0;
endtask
task automatic ctrl_write(input integer offset,input [31:0] data,input [3:0] strb);
  if(strb!==4'hf)$fatal(1,"CRT_HPM_WRITE_STRB");
  fork crt_aw(offset);crt_w(data);join
  while(!HPM_bvalid)@(negedge clk);
  repeat(2)@(negedge clk);
  if(HPM_bresp!==0 || HPM_bid!==16'h1234)$fatal(1,"CRT_HPM_WRITE_RESPONSE");
  HPM_bready=1;@(negedge clk);HPM_bready=0;
endtask
task automatic ctrl_read(input integer offset,output reg [31:0] data);
  @(negedge clk);HPM_araddr=40'ha0000000+offset;HPM_arid=16'h6789;
  HPM_arsize=2;HPM_arburst=1;HPM_arvalid=1;
  do @(posedge clk);while(!HPM_arready);
  @(negedge clk);HPM_arvalid=0;
  while(!HPM_rvalid)@(negedge clk);
  repeat(2)@(negedge clk);
  if(HPM_rresp!==0 || HPM_rid!==16'h6789 || HPM_rlast!==1'b1)$fatal(1,"CRT_HPM_READ_RESPONSE");
  data=HPM_rdata;HPM_rready=1;@(negedge clk);HPM_rready=0;
endtask
task automatic launch_job(input [31:0] pc,args,watchdog);
  ctrl_write(16,pc,15);ctrl_write(20,args,15);ctrl_write(24,watchdog,15);ctrl_write(8,1,15);
endtask
task automatic wait_job(input integer expected_terminal,max_cycles);
  integer start_cycle;
  start_cycle=crt_cycles;crt_value=0;
  while(!crt_value[1] && !crt_value[2])begin
    repeat(20)@(negedge clk);ctrl_read(12,crt_value);
    if(crt_cycles-start_cycle>max_cycles)$fatal(1,"CRT_HOST_JOB_TIMEOUT");
  end
  if(expected_terminal!=1 || crt_value[1]!==1'b1 || crt_value[2]!==1'b0)
    $fatal(1,"CRT_EXPECTED_REAL_DONE_WITHOUT_FAULT");
endtask
function automatic longint unsigned crt_hp(input reg [31:0] gpu);
  crt_hp=gpu[31] ? 64'h500000000+{1'b0,gpu[30:0]} : gpu;
endfunction

integer pair_fd,pair_rc,pair_count,pair_writable,pair_fill,pair_dump,pair_hart;
integer pair_epoch=0;
function automatic string pair_output_name(input string name);
  `ifdef PAIR_REOPEN
  pair_output_name=$sformatf("epoch_%0d_%s",pair_epoch,name);
  `else
  pair_output_name=name;
  `endif
endfunction
integer pair_stack_regions=0;
longint unsigned pair_address,pair_bytes;
string pair_name,pair_permission;
reg[31:0] pair_entry,pair_args;
bit pair_stack_x;
integer pair_watchdog_cycles,pair_host_limit_cycles;
longint unsigned pair_global_timeout_ns;
bit pair_budget_ready=0;
initial begin:read_runtime_budget
  integer fd,rc;
  fd=$fopen("gpu_runtime_budget.txt","r");
  if(!fd)$fatal(1,"PAIR_RUNTIME_BUDGET_MISSING");
  rc=$fscanf(fd,"%d %d %d\n",pair_watchdog_cycles,pair_host_limit_cycles,pair_global_timeout_ns);
  $fclose(fd);
  if(rc!=3 || pair_watchdog_cycles<1000000 || pair_host_limit_cycles<=pair_watchdog_cycles ||
     pair_global_timeout_ns<=64'(pair_host_limit_cycles)*10 || pair_global_timeout_ns>64'd4000000000)
    $fatal(1,"PAIR_RUNTIME_BUDGET_INVALID");
  pair_budget_ready=1;
end
initial begin
  repeat(2)@(negedge clk);
  if(!pair_budget_ready)$fatal(1,"PAIR_RUNTIME_BUDGET_NOT_READY");
  if(resetn!==0 || job_active!==0)$fatal(1,"PAIR_PRELOAD_RESET_IDLE");
  pair_fd=$fopen("gpu_regions.txt","r");if(!pair_fd)$fatal(1,"PAIR_REGIONS_MISSING");pair_count=0;
  while(!$feof(pair_fd))begin
    pair_rc=$fscanf(pair_fd,"%h %d %d %h %s\n",pair_address,pair_bytes,pair_writable,pair_fill,pair_name);
    if(pair_rc!=5 || pair_writable<0 || pair_writable>1 || pair_fill<0 || pair_fill>255)$fatal(1,"PAIR_REGION_SHAPE");
    pair_stack_x=0;
    for(integer h=0;h<64;h=h+1)if(pair_name==$sformatf("stack_%0d",h))begin
      if(pair_address!=crt_hp(32'hffff0000-h*8192-8192)||pair_bytes!=8192||pair_writable!=1)$fatal(1,"PAIR_STACK_REGION");
      pair_stack_x=1;pair_stack_regions=pair_stack_regions+1;
    end
    pair_permission=pair_writable?"rw":"r";
    memory_bus.register_region(pair_name,pair_address,pair_bytes,pair_permission,pair_fill,pair_stack_x);pair_count=pair_count+1;
  end
  $fclose(pair_fd);if(pair_count<133 || pair_stack_regions!=64)$fatal(1,"PAIR_REGIONS_INCOMPLETE");
  pair_fd=$fopen("gpu_load_bytes.txt","r");if(!pair_fd)$fatal(1,"PAIR_LOAD_MISSING");
  while(!$feof(pair_fd))begin
    pair_rc=$fscanf(pair_fd,"%h %h\n",pair_address,pair_fill);if(pair_rc!=2||pair_fill<0||pair_fill>255)$fatal(1,"PAIR_LOAD_SHAPE");
    memory_bus.load_byte(pair_address,pair_fill);
  end
  $fclose(pair_fd);
  pair_fd=$fopen("gpu_launch.txt","r");if(!pair_fd)$fatal(1,"PAIR_LAUNCH_MISSING");
  pair_rc=$fscanf(pair_fd,"%h %h\n",pair_entry,pair_args);$fclose(pair_fd);
  if(pair_rc!=2||pair_entry!=32'h80000000||pair_args!=32'h20000000)$fatal(1,"PAIR_LAUNCH_DOMAIN");
  `ifdef PAIR_REOPEN
  for(pair_epoch=0;pair_epoch<2;pair_epoch=pair_epoch+1)begin
    if(pair_epoch==1)begin
      @(negedge clk);resetn=0;
      repeat(10)@(negedge clk);
      pair_fd=$fopen("gpu_load_bytes_epoch_1.txt","r");if(!pair_fd)$fatal(1,"PAIR_REOPEN_LOAD_MISSING");
      while(!$feof(pair_fd))begin
        pair_rc=$fscanf(pair_fd,"%h %h\n",pair_address,pair_fill);
        if(pair_rc!=2||pair_fill<0||pair_fill>255)$fatal(1,"PAIR_REOPEN_LOAD_SHAPE");
        memory_bus.load_byte(pair_address,pair_fill);
      end
      $fclose(pair_fd);
    end
  `endif
  repeat(60)@(negedge clk);resetn=1;repeat(50)@(negedge clk);
  $display("INITIAL_RESET_COMPLETE: normal external reset before real HPM traffic");
  ctrl_read(0,crt_value);if(crt_value!==32'h56580204)$fatal(1,"PAIR_HPM_ID");
  ctrl_read(4,crt_value);if(crt_value!==32'h00040404)$fatal(1,"PAIR_GEOMETRY");
  `ifdef PAIR_COMPAT
  // Actual public HPM descriptor writes while IDLE, propagated by controller DCRs.
  ctrl_write('h40,32'h29000000,15);ctrl_write('h44,4,15);ctrl_write('h48,4,15);
  ctrl_write('h4c,16,15);ctrl_write('h50,8,15);ctrl_write('h54,64,15);
  `endif
  $display("PAIR_GPU_REAL_ELF_START entry=%08h args=%08h",pair_entry,pair_args);
  `ifdef PAIR_REOPEN
  reopen_record("start");
  `endif
  launch_job(pair_entry,pair_args,pair_watchdog_cycles);wait_job(1,pair_host_limit_cycles);
  if(job_active!==0||dut.gpu_busy!==0||crt_cores_seen!==4'hf)$fatal(1,"PAIR_DONE_NOT_ALL_CORES_RETIRED");
  ctrl_read(28,crt_value);if(crt_value!==0)$fatal(1,"PAIR_CTRL_ERROR");
  ctrl_read(32,crt_value);if(crt_value!==0)$fatal(1,"PAIR_WRITES_NOT_DRAINED");
  ctrl_read(36,crt_value);if(crt_value!==0)$fatal(1,"PAIR_READS_NOT_DRAINED");
  ctrl_read(44,crt_value);if(crt_value!==1)$fatal(1,"PAIR_JOB_COUNT");
  if(memory_bus.aw_full||memory_bus.w_full||memory_bus.r_full||HP_bvalid||HP_rvalid)$fatal(1,"PAIR_EXTERNAL_AXI_NOT_DRAINED");
  `ifdef PAIR_REOPEN
  reopen_record("done");
  `endif
  pair_dump=$fopen(pair_output_name("gpu_readback.txt"),"w");
  `ifdef PAIR_PROTOCOL
  for(integer w=0;w<16384;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h24000000+w*4,crt_word(32'h24000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h28000000+w*4,crt_word(32'h28000000+w*4));
  $fclose(protocol_fd);
  `else
  for(integer w=0;w<4096;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h24000000+w*4,crt_word(32'h24000000+w*4));
  `endif
  for(integer w=0;w<68;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h25000000+w*4,crt_word(32'h25000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h26000000+w*4,crt_word(32'h26000000+w*4));
  for(integer w=0;w<256;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h27000000+w*4,crt_word(32'h27000000+w*4));
  $fclose(pair_dump);
  `ifdef PAIR_COMPAT
  pair_dump=$fopen("gpu_compat_readback.txt","w");
  for(integer w=0;w<4096;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h28000000+w*4,crt_word(32'h28000000+w*4));
  $fclose(pair_dump);$fclose(compat_fd);
  $display("GPU_COMPAT_READBACK_CAPTURED words=4096 profile=legacy_fpu_tex_v1");
  `endif
  `ifdef PAIR_BP
  pair_dump=$fopen("gpu_bp_readback.txt","w");
  for(integer w=0;w<64;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h2a000000+w*4,crt_word(32'h2a000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h2b000000+w*4,crt_word(32'h2b000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h2c000000+w*4,crt_word(32'h2c000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h2d000000+w*4,crt_word(32'h2d000000+w*4));
  for(integer w=0;w<1024;w=w+1)$fdisplay(pair_dump,"%08h %08h",32'h2e000000+w*4,crt_word(32'h2e000000+w*4));
  $fclose(pair_dump);$fclose(bp_bank_fd);$fclose(bp_tcu_fd);$fclose(bp_arb_fd);$fclose(bp_query_fd);$fclose(bp_alu_fd);$fclose(bp_commit_fd);
  $display("GPU_BP_READBACK_CAPTURED words=4160 profile=dualbank_backpressure_v1");
  `endif
  pair_dump=$fopen(pair_output_name("gpu_monitor.txt"),"w");
  for(integer c=0;c<4;c=c+1)$fdisplay(pair_dump,"%0d %0d %0d %0d %0d %0d %0d %0d %0d",c,gpu_steps_accepted[c],gpu_steps_retired[c],gpu_step_wb[c],gpu_begins[c],gpu_releases[c],gpu_pages[c],gpu_bank0[c],gpu_bank1[c]);
  $fclose(pair_dump);
  $display("PAIR_GPU_REAL_DONE_DRAIN_PASS cores=4 jobs=1 pending_reads=0 pending_writes=0");
  `ifdef PAIR_PROTOCOL
  $display("PAIR_GPU_READBACK_CAPTURED words=18756 profile=owner_modes_v1 raw_cycles=%0d",crt_cycles);
  `else
  $display("PAIR_GPU_READBACK_CAPTURED words=5444 raw_cycles=%0d",crt_cycles);
  `endif
  ctrl_write(8,2,15);
  `ifdef PAIR_REOPEN
  end
  $fclose(reopen_fd);
  $display("PAIR_GPU_RESET_REOPEN_DRAIN_PASS epochs=2");
  `endif
  $finish;
end
initial begin wait(pair_budget_ready);#(pair_global_timeout_ns);$fatal(1,"PAIR_GPU_BOUNDED_TIMEOUT");end
function automatic reg [31:0] crt_word(input reg [31:0] gpu);
  reg [31:0] word_value;
  for(integer b=0;b<4;b=b+1)word_value[b*8+:8]=memory_bus.peek_byte(crt_hp(gpu)+b);
  crt_word=word_value;
endfunction

