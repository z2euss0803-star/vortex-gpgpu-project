`timescale 1ns/1ps
module tb_s8_pair_compute;
reg clk=0;always #5 clk=~clk;
reg reset=1,pair_mode=0,cmd_valid=0,step_valid=0,result_ready=0;
reg [12:0] k_count=0;
reg [127:0] a0_flat=0,a1_flat=0,b_flat=0;
wire cmd_ready,step_ready,result_valid,cmd_error;
wire [3071:0] c0_flat,c1_flat;
VX_tcu_s8_pair dut(.*);
wire ref_cmd_ready,ref_step_ready,ref_result_valid,ref_error;
wire [3071:0] ref_c;
s8_compute single_reference(.clk(clk),.reset(reset||pair_mode),
 .cmd_valid(cmd_valid&&!pair_mode),.cmd_ready(ref_cmd_ready),.k_count(k_count),
 .step_valid(step_valid&&!pair_mode),.step_ready(ref_step_ready),
 .a_flat(a0_flat),.b_flat(b_flat),.result_valid(ref_result_valid),
 .result_ready(result_ready&&!pair_mode),.c_flat(ref_c),.cmd_error(ref_error));
integer cases,idx,k,n,kind,mode,timeout_count,checks=0;
reg [383:0] vectors[0:4095];reg [47:0] golden[0:127];
reg [3071:0] saved0,saved1;
reg [383:0] reset_payload;
reg signed [47:0] reset_expected;
string vector_name,golden_name;
integer spec;
reg check_single=0;
always @(posedge clk)begin
 if(reset||pair_mode)check_single<=0;
 else if(cmd_valid&&cmd_ready&&k_count>=1&&k_count<=4096)check_single<=1;
 if(!reset&&pair_mode)begin
  if(dut.compute0.step_fire!==dut.compute1.step_fire)$fatal(1,"NONATOMIC_PAIR_STEP");
  if(dut.compute0.cmd_fire!==dut.compute1.cmd_fire)$fatal(1,"NONATOMIC_PAIR_COMMAND");
  if(dut.compute0.accepted!==dut.compute1.accepted)$fatal(1,"PAIR_COUNT_DIVERGED");
 end
end
always @(negedge clk)begin
 #1; // Observe after negedge stimulus and continuous assignments settle.
 if(!reset&&!pair_mode)begin
  if({cmd_ready,step_ready,result_valid,cmd_error} !== {ref_cmd_ready,ref_step_ready,ref_result_valid,ref_error})$fatal(1,"SINGLE_CONTROL_CHANGED");
  if(check_single&&c0_flat!==ref_c)$fatal(1,"SINGLE_DATA_CHANGED");
 end
end
task automatic do_reset;
 begin
  @(negedge clk);reset=1;cmd_valid=0;step_valid=0;result_ready=0;
  repeat(4)@(negedge clk);reset=0;repeat(2)@(negedge clk);
  if(result_valid!==0||cmd_ready!==1||step_ready!==0)$fatal(1,"RESET_NOT_IDLE");
  if(c0_flat!==3072'd0||c1_flat!==3072'd0)$fatal(1,"RESET_ACCUMULATOR_NOT_ZERO");
 end
endtask
task automatic start_job(input integer m,input integer count);
 begin
  @(negedge clk);pair_mode=m; k_count=count;cmd_valid=1;
  @(posedge clk);if(!cmd_ready)$fatal(1,"COMMAND_NOT_READY");
  @(negedge clk);cmd_valid=0;
 end
endtask
task automatic send_step(input reg[383:0] payload);
 begin
  @(negedge clk);{a1_flat,b_flat,a0_flat}=payload;step_valid=1;
  @(posedge clk);if(!step_ready)$fatal(1,"STEP_NOT_READY");
 end
endtask
initial begin
 repeat(16)@(negedge clk);reset=0;repeat(2)@(negedge clk);
 spec=$fopen("cases.txt","r");if(!spec)$fatal(1,"NO_CASE_MANIFEST");
 n=$fscanf(spec,"%d\n",cases);
 for(idx=0;idx<cases;idx=idx+1)begin
  n=$fscanf(spec,"%d %d %s %s\n",mode,k,vector_name,golden_name);
  if(n!=4)$fatal(1,"BAD_CASE_MANIFEST");
  $readmemh(vector_name,vectors,0,k-1);$readmemh(golden_name,golden,0,127);
  start_job(mode,k);
  for(n=0;n<k;n=n+1)begin
   if(n%7==3)begin @(negedge clk);step_valid=0;repeat(2)@(negedge clk);end
   send_step(vectors[n]);
  end
  @(negedge clk);step_valid=0;timeout_count=0;
  while(!result_valid&&timeout_count<12)begin @(negedge clk);timeout_count=timeout_count+1;end
  if(!result_valid)$fatal(1,"DRAIN_TIMEOUT");
  for(n=0;n<64;n=n+1)begin
   if(c0_flat[n*48+:48]!==golden[n])$fatal(1,"BANK0_MISMATCH case=%0d pe=%0d",idx,n);
   if(mode&&c1_flat[n*48+:48]!==golden[64+n])$fatal(1,"BANK1_MISMATCH case=%0d pe=%0d",idx,n);
   checks=checks+1+mode;
  end
  saved0=c0_flat;saved1=c1_flat;
  repeat(7)begin @(negedge clk);if(!result_valid||c0_flat!==saved0||(mode&&c1_flat!==saved1))$fatal(1,"RESULT_NOT_HELD");end
  result_ready=1;@(negedge clk);result_ready=0;
  $display("PAIR_CASE_PASS index=%0d pair=%0d K=%0d",idx,mode,k);
 end
 $fclose(spec);
 // Reset with accepted work in flight at each drain offset, then reuse.
 for(kind=0;kind<4;kind=kind+1)begin
  start_job(1,4);send_step(384'h123);@(negedge clk);step_valid=0;
  repeat(kind)@(negedge clk);do_reset();
 end
 // Reset while both complete banks are held for readback.
 start_job(1,1);send_step(384'h1);@(negedge clk);step_valid=0;repeat(5)@(negedge clk);
 if(!result_valid)$fatal(1,"EXPECTED_HELD_RESULT");do_reset();
 // No command/step may be accepted while reset is high.
 @(negedge clk);reset=1;cmd_valid=1;step_valid=1;k_count=1;
 repeat(3)begin @(negedge clk);#1;if(cmd_ready||step_ready||result_valid)$fatal(1,"RESET_ACCEPTED_TRAFFIC");end
 cmd_valid=0;step_valid=0;do_reset();
 // Prove the reset banks can compute a new nonzero, distinct result.
 reset_payload=0;
 for(n=0;n<8;n=n+1)begin
  reset_payload[n*16+:16]=16'(n-3);
  reset_payload[128+n*16+:16]=16'(2*n-4);
  reset_payload[256+n*16+:16]=16'(n+5);
 end
 start_job(1,1);send_step(reset_payload);@(negedge clk);step_valid=0;repeat(5)@(negedge clk);
 if(!result_valid)$fatal(1,"POST_RESET_NO_RESULT");
 for(n=0;n<64;n=n+1)begin
  reset_expected=(n/8-3)*(2*(n%8)-4);
  if(c0_flat[n*48+:48]!==reset_expected)$fatal(1,"POST_RESET_BANK0_DATA");
  reset_expected=(n/8+5)*(2*(n%8)-4);
  if(c1_flat[n*48+:48]!==reset_expected)$fatal(1,"POST_RESET_BANK1_DATA");
 end
 do_reset();
 // Invalid K reaches the bare compute interface, but must never allocate.
 for(kind=0;kind<2;kind=kind+1)begin
  start_job(1,kind==0?0:4097);
  if(cmd_error!==1||cmd_ready!==1||result_valid!==0)$fatal(1,"ILLEGAL_K_ACCEPTED");
  @(negedge clk);
 end
 $display("PAIR_COMPUTE_PASS cases=%0d value_checks=%0d normal_reset=PASS single_cycle_equivalence=PASS",cases,checks);
 $finish;
end
initial begin #10000000;$fatal(1,"GLOBAL_TIMEOUT");end
endmodule
