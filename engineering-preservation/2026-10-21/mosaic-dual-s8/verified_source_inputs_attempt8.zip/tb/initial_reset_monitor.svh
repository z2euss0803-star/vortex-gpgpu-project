// Simulation observations only. No force, deposit, reset or state injection.
// Frozen geometry is one cluster/socket with shared I/D cache, four cores.
`define RESET_SOCKET dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket
`define RESET_ICOUNTER `RESET_SOCKET.icache.g_cache_wrap[0].cache_wrap.g_cache.cache.g_banks[0].bank.mshr_pending_size
`define RESET_DCOUNTER `RESET_SOCKET.dcache.g_cache_wrap[0].cache_wrap.g_cache.cache.g_banks[0].bank.mshr_pending_size
  integer initial_reset_edges = 0;
  reg initial_reset_converged = 0;
  always @(posedge clk) begin
    initial_reset_edges = initial_reset_edges + 1;
    // Observe post-NBA relay/counter outputs. Eight edges exceeds the frozen
    // four-edge reset propagation plus the counter's own reset edge.
    #1;
    if (initial_reset_edges == 8) begin
      if (resetn !== 1'b0 || dut.gpu_reset !== 1'b1 ||
          `RESET_SOCKET.icache_reset !== 1'b1 || `RESET_SOCKET.dcache_reset !== 1'b1 ||
          `RESET_ICOUNTER.empty !== 1'b1 || `RESET_ICOUNTER.full !== 1'b0 ||
          `RESET_ICOUNTER.size !== '0 || `RESET_DCOUNTER.size !== '0 ||
          `RESET_DCOUNTER.empty !== 1'b1 || `RESET_DCOUNTER.full !== 1'b0)
        $fatal(1, "INITIAL_RESET_CONVERGENCE_FAILED");
      initial_reset_converged = 1;
      $display("INITIAL_RESET_CONVERGENCE_PASS: bound8edges local caches and counters known");
    end
    if (initial_reset_converged) begin
      if ($isunknown({resetn, dut.gpu_reset, `RESET_SOCKET.icache_reset,
                     `RESET_SOCKET.dcache_reset, `RESET_ICOUNTER.empty,
                     `RESET_ICOUNTER.full, `RESET_ICOUNTER.size, `RESET_DCOUNTER.size,
                     `RESET_DCOUNTER.empty, `RESET_DCOUNTER.full}))
        $fatal(1, "RESET_OR_COUNTER_UNKNOWN_AFTER_CONVERGENCE");
    end
    if (HPM_arvalid || HPM_awvalid || HPM_wvalid)
      if (!initial_reset_converged) $fatal(1, "HPM_BEFORE_RESET_CONVERGENCE");
  end
`undef RESET_DCOUNTER
`undef RESET_ICOUNTER
`undef RESET_SOCKET
