`timescale 1ns/1ps
`include "VX_define.vh"
module tb_tcu_legacy_diff;
 import VX_gpu_pkg::*;
 import VX_tcu_pkg::*;
 reg clk=0,reset=1,iv=0,enable_commit=1;
 integer cycle_count=0;
 // Test stimulus settles half a cycle before every accepting clock edge.
 always @(negedge clk)cycle_count=cycle_count+1;
 wire cycle_ready=(cycle_count%31>6)&&(cycle_count%17!=9);
 always #5 clk=~clk;
 dispatch_t din;
 wire ir,ov;
 wire [$bits(commit_t)-1:0] ob;
 commit_t cd;
 assign cd=ob;
 VX_commit_if ci[NUM_EX_UNITS*`ISSUE_WIDTH]();
 VX_writeback_if wb[`ISSUE_WIDTH]();
 VX_commit_csr_if csr();VX_commit_sched_if sched();
 tcu_sim dut(clk,reset,iv,din,ir,ov,ob,enable_commit&&cycle_ready&&ci[EX_TCU].ready);
 for(genvar g=0;g<NUM_EX_UNITS*`ISSUE_WIDTH;g=g+1)begin
   assign ci[g].valid=(g==EX_TCU)&&ov&&enable_commit&&cycle_ready;
   assign ci[g].data=cd;
 end
 VX_commit cm(.clk(clk),.reset(reset),.commit_if(ci),.writeback_if(wb),.commit_csr_if(csr),.commit_sched_if(sched));
 wire legacy_done;
 tcu_legacy_tb legacy_check(legacy_done);
 reg [127:0] expected[0:16383];
 reg pending[0:16383];
 reg [1:0] owner_expect[0:16383];
 reg wb_expect[0:16383];
 reg [NUM_REGS_BITS-1:0] rd_expect[0:16383];
 integer sequence_id=1,accepted=0,retired=0,step_retired=0,step_writeback=0;
 integer captured=0,case_checked=0,snapshot_case=0,native_dest=8,pair_cases=0;
 integer reset_discarded=0,output_stalls=0;
 integer n;
 reg [255:0] vectors[0:4095];
 reg [3071:0] oracle[0:0];
 reg [3071:0] readback;
 reg [127:0] observed[0:16383];
 reg held_valid=0;reg [$bits(commit_t)-1:0] held;
 always @(posedge clk)if(!reset)begin
   if(held_valid&&(!ov||ob!==held))$fatal(1,"COMPLETE_TCU_HELD_OUTPUT");
   held_valid=ov&&!(enable_commit&&cycle_ready&&ci[EX_TCU].ready);held=ob;
   if(held_valid)output_stalls=output_stalls+1;
   if(dut.unit.g_blocks[0].tcu_int.g_native.native_res.valid&&dut.unit.g_blocks[0].tcu_int.g_native.native_res.ready
      &&dut.unit.g_blocks[0].tcu_int.g_native.native_core.response_page)captured=captured+1;
   if(cm.commit_arb_if[0].valid&&cm.commit_arb_if[0].ready)begin
     n=int'(cm.commit_arb_if[0].data.PC);
     if(n<1||n>=16384||!pending[n])$fatal(1,"INTEGRATED_DUPLICATE_OR_UNKNOWN PC=%0d",n);
     if(cm.commit_arb_if[0].data.data!==expected[n])$fatal(1,"INTEGRATED_NUMERIC_MISMATCH PC=%0d got=%h expected=%h",n,cm.commit_arb_if[0].data.data,expected[n]);
     if(cm.commit_arb_if[0].data.wid!==owner_expect[n]||cm.commit_arb_if[0].data.wb!==wb_expect[n]
       ||cm.commit_arb_if[0].data.rd!==rd_expect[n]||cm.commit_arb_if[0].data.tmask!==4'hf
       ||!cm.commit_arb_if[0].data.sop||!cm.commit_arb_if[0].data.eop||cm.commit_arb_if[0].data.sid!==0)$fatal(1,"INTEGRATED_METADATA PC=%0d wid=%0d wb=%0d rd=%0d expected_rd=%0d",n,cm.commit_arb_if[0].data.wid,cm.commit_arb_if[0].data.wb,cm.commit_arb_if[0].data.rd,rd_expect[n]);
     observed[n]=cm.commit_arb_if[0].data.data;pending[n]=0;retired=retired+1;
     if(!wb_expect[n])step_retired=step_retired+1;
   end
   if(wb[0].valid&&!wb_expect[int'(wb[0].data.PC)])step_writeback=step_writeback+1;
 end else held_valid=0;
 task submit(input integer fmt,input integer owner_w,input reg [127:0] a,b,c,answer,output integer ident);
 begin
   ident=sequence_id;sequence_id=sequence_id+1;
   @(negedge clk);din='0;din.PC=PC_BITS'(ident);din.wis=NW_WIDTH'(owner_w);din.rd=make_reg_num(REG_TYPE_F,10);
   din.wb=fmt!=14;din.tmask=15;din.sop=1;din.eop=1;
   din.op_args.tcu.fmt_s=4'(fmt);din.op_args.tcu.fmt_d=fmt<8?0:(fmt>=13?native_dest:8);
   din.rs1_data=a;din.rs2_data=b;din.rs3_data=c;
   expected[ident]=answer;owner_expect[ident]=2'(owner_w);wb_expect[ident]=fmt!=14;rd_expect[ident]=make_reg_num(REG_TYPE_F,10);
   iv=1;do @(posedge clk);while(!ir);pending[ident]=1;accepted=accepted+1;
   @(negedge clk);iv=0;
 end
 endtask
 task native_inflight_reset;
 integer ident;
 reg [127:0] answer;
 begin
   answer='0;answer[95:64]=1;answer[96]=1;send(13,3,0,0,128'd1,answer);
   @(negedge clk);enable_commit=0;
   submit(14,3,{4{32'h80008000}},{4{32'h80008000}},0,0,ident);
   repeat(8)@(negedge clk);
   if(!pending[ident])$fatal(1,"RESET_REQUEST_ALREADY_RETIRED");
   reset=1;iv=0;
   for(integer j=1;j<sequence_id;j=j+1)if(pending[j])begin pending[j]=0;reset_discarded=reset_discarded+1;end
   repeat(5)@(negedge clk);reset=0;enable_commit=1;
   send(15,3,0,0,128'd31,0);
 end
 endtask
 task drain_one(input integer ident);
 integer ticks;
 begin
   ticks=0;while(pending[ident])begin @(negedge clk);ticks=ticks+1;if(ticks>5000)$fatal(1,"INTEGRATED_RETIRE_TIMEOUT PC=%0d",ident);end
 end endtask
 task send(input integer fmt,input integer owner_w,input reg [127:0] a,b,c,answer);
 integer ident;
 begin submit(fmt,owner_w,a,b,c,answer,ident);drain_one(ident);end
 endtask
 task matrix_case(input integer case_idx,input integer k,input integer owner_w,input integer snapshot);
 integer ident,page_id,release_id,begin_id,old_captured;
 reg [127:0] answer;
 begin
   $readmemh($sformatf("%s/inputs/native_%0d.mem",`S8_TEST_ROOT,case_idx),vectors,0,k-1);
   $readmemh($sformatf("%s/inputs/expected_%0d.mem",`S8_TEST_ROOT,case_idx),oracle);
   answer='0;answer[95:64]=32'(k);answer[96]=1;
   send(13,owner_w,0,0,128'(k),answer);
   // Interleave bounded legacy FP and four integer formats with legal native steps.
   for(integer t=0;t<k;t=t+1)begin
     submit(14,owner_w,vectors[t][127:0],vectors[t][255:128],0,0,ident);
     if(t%101==0)begin
       send(9,(owner_w+1)%4,{4{32'h01010101}},{4{32'h01010101}},0,{4{32'd8}});
       send(10,(owner_w+2)%4,{4{32'hff00ff00}},{4{32'h01010101}},0,{4{32'd1020}});
       send(11,(owner_w+3)%4,{4{32'h11111111}},{4{32'h11111111}},0,{4{32'd16}});
       send(12,owner_w,{4{32'hffffffff}},{4{32'h11111111}},0,{4{32'd240}});
       send(1,owner_w,{4{32'h3c003c00}},{4{32'h3c003c00}},0,{4{32'h40800000}});
       send(2,owner_w,{4{32'h3f803f80}},{4{32'h3f803f80}},0,{4{32'h40800000}});
     end
   end
   drain_one(ident);repeat(5)@(negedge clk);
   answer='0;answer[63:32]=32'(k);answer[95:64]=32'(k);answer[97:96]=3;
   send(15,owner_w,0,0,128'd31,answer);
   readback=0;old_captured=captured;
   for(integer p=0;p<23;p=p+1)begin
     submit(15,owner_w,0,0,128'(p),oracle[0][p*128+:128],ident);drain_one(ident);
     readback[p*128+:128]=observed[ident];
   end
   if(snapshot)begin
     @(negedge clk);enable_commit=0;
     submit(15,owner_w,0,0,128'd23,oracle[0][23*128+:128],page_id);
     while(captured-old_captured<24)@(negedge clk);
     if(!pending[page_id])$fatal(1,"PAGE_RETIRED_BEFORE_SNAPSHOT_TEST");
     answer='0;answer[63:32]=32'(k);answer[95:64]=32'(k);answer[98:96]=7;
     submit(15,owner_w,0,0,128'd287,answer,release_id);
     while(dut.unit.g_blocks[0].tcu_int.g_native.native_core.active)@(negedge clk);
     answer='0;answer[95:64]=2;answer[96]=1;
     submit(13,(owner_w+1)%4,0,0,128'd2,answer,begin_id);
     while(!dut.unit.g_blocks[0].tcu_int.g_native.native_core.active)@(negedge clk);
     if(!pending[page_id]||!pending[release_id])$fatal(1,"SNAPSHOT_ALREADY_RETIRED");
     @(negedge clk);enable_commit=1;drain_one(page_id);drain_one(release_id);drain_one(begin_id);
     readback[23*128+:128]=observed[page_id];snapshot_case=snapshot_case+1;
     // Finish the new context, then release normally, proving old-page FIFO data survived accumulator reset.
     send(14,(owner_w+1)%4,0,0,0,0);send(14,(owner_w+1)%4,0,0,0,0);repeat(5)@(negedge clk);
     for(integer p=0;p<24;p=p+1)send(15,(owner_w+1)%4,0,0,128'(p),0);
     answer='0;answer[63:32]=2;answer[95:64]=2;answer[98:96]=7;
     send(15,(owner_w+1)%4,0,0,128'd287,answer);
   end else begin
     submit(15,owner_w,0,0,128'd23,oracle[0][23*128+:128],ident);drain_one(ident);readback[23*128+:128]=observed[ident];
     answer='0;answer[63:32]=32'(k);answer[95:64]=32'(k);answer[98:96]=7;
     send(15,owner_w,0,0,128'd287,answer);
   end
   if(readback!==oracle[0])$fatal(1,"NATIVE_INTEGER_ORACLE_MISMATCH K=%0d",k);
   case_checked=case_checked+1;
 end
 endtask

 task matrix_pair_case;
 integer ident,last_id,release_id,begin_id,start_capture;
 reg[383:0] ab[0:2];reg[6143:0] c[0:0];reg[127:0] answer;
 begin
  native_dest=3;
  $readmemh($sformatf("%s/inputs/pair_k3_ab.mem",`S8_TEST_ROOT),ab);
  $readmemh($sformatf("%s/inputs/pair_k3_c.mem",`S8_TEST_ROOT),c);
  answer=0;answer[95:64]=3;answer[127:96]=9;send(13,1,0,0,128'd3,answer);
  for(integer k=0;k<3;k=k+1)begin
   send(9,2,{4{32'h01010101}},{4{32'h01010101}},0,{4{32'd8}});
   send(1,2,{4{32'h3c003c00}},{4{32'h3c003c00}},0,{4{32'h40800000}});
   send(14,1,ab[k][127:0],ab[k][255:128],ab[k][383:256],0);
  end
  repeat(5)@(negedge clk);start_capture=captured;
  for(integer bank=0;bank<2;bank=bank+1)begin
   for(integer page=0;page<(bank?23:24);page=page+1)begin
    answer=c[0][bank*3072+page*128+:128];
    `ifdef PAIR_NEGATIVE_GOLD
    if(bank==1&&page==0)answer[0]=~answer[0];
    `endif
    send(15,1,0,0,128'((bank<<5)|page),answer);
   end
  end
  answer=0;answer[31:0]=7;answer[63:32]=3;answer[95:64]=3;answer[127:96]=27;
  send(15,1,0,0,128'h11f,answer);
  // Capture bank1's final page, then reset both P banks for the next owner
  // while its response and release are still pending at actual commit.
  @(negedge clk);enable_commit=0;
  submit(15,1,0,0,128'h37,c[0][47*128+:128],last_id);
  while(captured-start_capture<48)@(negedge clk);
  answer=0;answer[63:32]=3;answer[95:64]=3;answer[127:96]=63;
  submit(15,1,0,0,128'h11f,answer,release_id);
  while(dut.unit.g_blocks[0].tcu_int.g_native.native_core.active)@(negedge clk);
  answer=0;answer[95:64]=1;answer[127:96]=9;
  submit(13,2,0,0,128'd1,answer,begin_id);
  while(!dut.unit.g_blocks[0].tcu_int.g_native.native_core.active)@(negedge clk);
  if(!pending[last_id]||!pending[release_id])$fatal(1,"PAIR_SNAPSHOT_RETIRED_EARLY");
  @(negedge clk);enable_commit=1;drain_one(last_id);drain_one(release_id);drain_one(begin_id);
  send(14,2,0,0,0,0);repeat(5)@(negedge clk);
  for(integer bank=0;bank<2;bank=bank+1)for(integer page=0;page<24;page=page+1)send(15,2,0,0,128'((bank<<5)|page),0);
  answer=0;answer[63:32]=1;answer[95:64]=1;answer[127:96]=63;send(15,2,0,0,128'h11f,answer);
  native_dest=8;pair_cases=pair_cases+1;
 end
 endtask

 initial begin
   for(integer i=0;i<16384;i=i+1)begin pending[i]=0;observed[i]=0;end
   din='0;
   repeat(15)@(negedge clk);reset=0;
   `ifdef PAIR_NEGATIVE_GOLD
   $display("PAIR_NEGATIVE_CONTROL bank1_page0_expected_bit0_corrupted=1");
   matrix_pair_case;
   $fatal(1,"NEGATIVE_CONTROL_DID_NOT_REJECT");
   `else
   matrix_case(0,1,0,1);matrix_case(1,2,1,0);matrix_case(2,3,2,0);matrix_case(3,2592,3,0);matrix_case(4,4096,0,0);
   matrix_pair_case;
   native_inflight_reset;
   repeat(10)@(negedge clk);
   for(integer i=1;i<sequence_id;i=i+1)if(pending[i])$fatal(1,"INTEGRATED_UNACCOUNTED_LOSS PC=%0d",i);
   if(accepted!=retired+reset_discarded||reset_discarded!=1||output_stalls<10||step_writeback!=0||step_retired!=6700||pair_cases!=1||case_checked!=5||snapshot_case!=1)$fatal(1,"INTEGRATED_ACCOUNTING accepted=%0d retired=%0d steps=%0d step_wb=%0d reset_discarded=%0d stalls=%0d",accepted,retired,step_retired,step_writeback,reset_discarded,output_stalls);
   wait(legacy_done);
   $display("PAIR_TCU_COMPAT_PASS pair_cases=%0d snapshot_bank1=PASS",pair_cases);
   $display("NATIVE_INTEGER_ORACLE_PASS cases=5 values=320 captured_pages=%0d snapshot_before_retirement=%0d",captured,snapshot_case);
   $display("INTEGRATED_COMMIT_PASS accepted=%0d retired=%0d step_retired=%0d step_writeback=%0d reset_discarded=%0d output_stalls=%0d",accepted,retired,step_retired,step_writeback,reset_discarded,output_stalls);$finish;
   `endif
 end
 initial begin #10000000;$fatal(1,"INTEGRATED_GLOBAL_TIMEOUT");end
endmodule
