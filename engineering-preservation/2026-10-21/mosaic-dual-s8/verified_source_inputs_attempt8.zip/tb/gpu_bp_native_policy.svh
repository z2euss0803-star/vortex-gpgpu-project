// Private observer policy; exercised directly by the SV regression.
function automatic bit gpu_bp_native_allowed(
  input integer warp,
  input logic [3:0] mask,fmt_s,fmt_d,
  input logic [127:0] control
);
  gpu_bp_native_allowed=(warp===0 && mask===4'hf)
    || ((warp===1 || warp===2 || warp===3) && mask===4'hf
        && fmt_s===4'd15 && fmt_d===4'd3 && control===128'd31);
endfunction
