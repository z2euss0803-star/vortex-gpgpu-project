// Passive real result-channel observations. Never drives ready or DUT state.
`ifdef PAIR_BP
integer bp_bank_fd,bp_tcu_fd,bp_arb_fd,bp_query_fd;
integer bp_alu_fd,bp_commit_fd,bp_pc_fd,bp_pc_rc;
reg [31:0] bp_alu_pc_begin,bp_alu_pc_end;
initial begin
  bp_bank_fd=$fopen("gpu_bp_bank_events.txt","w");
  bp_tcu_fd=$fopen("gpu_bp_tcu_events.txt","w");
  bp_arb_fd=$fopen("gpu_bp_arb_events.txt","w");
  bp_query_fd=$fopen("gpu_bp_query_events.txt","w");
  bp_alu_fd=$fopen("gpu_bp_alu_events.txt","w");bp_commit_fd=$fopen("gpu_bp_commit_events.txt","w");
  bp_pc_fd=$fopen("gpu_bp_alu_pc.txt","r");
  if(!bp_bank_fd || !bp_tcu_fd || !bp_arb_fd || !bp_query_fd || !bp_alu_fd || !bp_commit_fd || !bp_pc_fd)$fatal(1,"GPU_BP_TRACE_OPEN");
  bp_pc_rc=$fscanf(bp_pc_fd,"%h %h",bp_alu_pc_begin,bp_alu_pc_end);$fclose(bp_pc_fd);
  if(bp_pc_rc!=2 || $isunknown({bp_alu_pc_begin,bp_alu_pc_end}) || bp_alu_pc_end-bp_alu_pc_begin!=256)$fatal(1,"GPU_BP_ALU_PC_RANGE");
end
task automatic bp_request(input integer core,input VX_gpu_pkg::dispatch_t d);
  if($isunknown({d.uuid,d.PC,d.wis,d.sid,d.rd,d.tmask,d.wb,d.sop,d.eop,d.op_args.tcu.fmt_s}))
    $fatal(1,"GPU_BP_REQUEST_UNKNOWN");
  if(d.sid!=0)$fatal(1,"GPU_BP_REQUEST_SID");
  $fdisplay(bp_tcu_fd,"0 %0d %0d %h %h %0d %0d %h %0d %0d %0d %0d",
      core,crt_cycles,d.uuid,d.PC,d.wis,d.rd,d.tmask,d.wb,d.sop,d.eop,d.op_args.tcu.fmt_s);
endtask
task automatic bp_response(input integer core,input VX_gpu_pkg::commit_t d);
  if($isunknown({d.uuid,d.PC,d.wid,d.sid,d.rd,d.tmask,d.wb,d.sop,d.eop,d.data}))
    $fatal(1,"GPU_BP_RESULT_UNKNOWN");
  if(d.sid!=0)$fatal(1,"GPU_BP_RESULT_SID");
  $fdisplay(bp_tcu_fd,"1 %0d %0d %h %h %0d %0d %h %0d %0d %0d -1",
      core,crt_cycles,d.uuid,d.PC,d.wid,d.rd,d.tmask,d.wb,d.sop,d.eop);
endtask
`define BP_TCU dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket.g_cores[bc].core.execute.tcu_unit
`define BP_BLOCK `BP_TCU.g_blocks[0]
`define BP_INT `BP_BLOCK.tcu_int.g_native
`define BP_NATIVE `BP_INT.native_core
`define BP_CORE dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket.g_cores[bc].core
`define BP_ALU `BP_CORE.execute.alu_unit
`define BP_COMMIT `BP_CORE.commit
for(genvar bc=0;bc<4;bc=bc+1)begin:g_bp_observer
  reg held=0;
  reg [$bits(`BP_NATIVE.result_if.data)-1:0] snapshot;
  reg held_bank;
  reg [4:0] held_page;
  always @(posedge clk)begin
    if(!resetn || dut.gpu_reset)held=0;
    else begin
      if(`BP_ALU.dispatch_if[0].valid && `BP_ALU.dispatch_if[0].ready &&
         `BP_ALU.dispatch_if[0].data.PC>=bp_alu_pc_begin && `BP_ALU.dispatch_if[0].data.PC<bp_alu_pc_end)begin
        if($isunknown({`BP_ALU.dispatch_if[0].data.uuid,`BP_ALU.dispatch_if[0].data.PC,
          `BP_ALU.dispatch_if[0].data.wis,`BP_ALU.dispatch_if[0].data.sid,`BP_ALU.dispatch_if[0].data.rd,
          `BP_ALU.dispatch_if[0].data.tmask,`BP_ALU.dispatch_if[0].data.wb,
          `BP_ALU.dispatch_if[0].data.sop,`BP_ALU.dispatch_if[0].data.eop}) || `BP_ALU.dispatch_if[0].data.sid!=0)$fatal(1,"GPU_BP_ALU_REQUEST_UNKNOWN");
        $fdisplay(bp_alu_fd,"0 %0d %0d %h %h %0d %0d %h %0d %0d %0d 0",bc,crt_cycles,
          `BP_ALU.dispatch_if[0].data.uuid,`BP_ALU.dispatch_if[0].data.PC,`BP_ALU.dispatch_if[0].data.wis,
          `BP_ALU.dispatch_if[0].data.rd,`BP_ALU.dispatch_if[0].data.tmask,`BP_ALU.dispatch_if[0].data.wb,
          `BP_ALU.dispatch_if[0].data.sop,`BP_ALU.dispatch_if[0].data.eop);
      end
      if(`BP_COMMIT.commit_arb_if[0].valid && `BP_COMMIT.commit_arb_if[0].ready &&
         `BP_COMMIT.commit_arb_if[0].data.PC>=bp_alu_pc_begin && `BP_COMMIT.commit_arb_if[0].data.PC<bp_alu_pc_end)begin
        if($isunknown(`BP_COMMIT.commit_arb_if[0].data) || `BP_COMMIT.commit_arb_if[0].data.sid!=0)$fatal(1,"GPU_BP_ALU_COMMIT_UNKNOWN");
        $fdisplay(bp_alu_fd,"1 %0d %0d %h %h %0d %0d %h %0d %0d %0d %h",bc,crt_cycles,
          `BP_COMMIT.commit_arb_if[0].data.uuid,`BP_COMMIT.commit_arb_if[0].data.PC,`BP_COMMIT.commit_arb_if[0].data.wid,
          `BP_COMMIT.commit_arb_if[0].data.rd,`BP_COMMIT.commit_arb_if[0].data.tmask,`BP_COMMIT.commit_arb_if[0].data.wb,
          `BP_COMMIT.commit_arb_if[0].data.sop,`BP_COMMIT.commit_arb_if[0].data.eop,`BP_COMMIT.commit_arb_if[0].data.data);
      end
      if(`BP_NATIVE.result_if.valid && `BP_NATIVE.result_if.ready && `BP_NATIVE.result_if.data.wid!=0)begin
        if($isunknown(`BP_NATIVE.result_if.data) || `BP_NATIVE.result_if.data.pid!=0)
          $fatal(1,"GPU_BP_QUERY_PACKET_UNKNOWN");
        $fdisplay(bp_query_fd,"%0d %0d %0d %h %h %0d %h %0d %0d %0d %h",bc,crt_cycles,
          `BP_NATIVE.result_if.data.wid,`BP_NATIVE.result_if.data.uuid,`BP_NATIVE.result_if.data.PC,
          `BP_NATIVE.result_if.data.rd,`BP_NATIVE.result_if.data.tmask,`BP_NATIVE.result_if.data.wb,
          `BP_NATIVE.result_if.data.sop,`BP_NATIVE.result_if.data.eop,`BP_NATIVE.result_if.data.data);
      end
      if(held && (`BP_NATIVE.result_if.valid!==1'b1 || `BP_NATIVE.response_page!==1'b1 ||
         `BP_NATIVE.result_if.data!==snapshot || `BP_NATIVE.response_bank!==held_bank ||
         `BP_NATIVE.response_page_index!==held_page))$fatal(1,"GPU_BP_HELD_RESPONSE_CHANGED");
      if(`BP_NATIVE.result_if.valid && `BP_NATIVE.response_page)begin
        if($isunknown({`BP_COMMIT.commit_if[VX_gpu_pkg::EX_TCU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_TCU].ready,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_ALU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_LSU].valid,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_SFU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_FPU].valid,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_TEX].valid}))$fatal(1,"GPU_BP_COMMIT_CONTROL_UNKNOWN");
        $fdisplay(bp_commit_fd,"%0d %0d %0d %0d %0d %0d %0d %0d %0d",bc,crt_cycles,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_TCU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_TCU].ready,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_ALU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_LSU].valid,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_SFU].valid,`BP_COMMIT.commit_if[VX_gpu_pkg::EX_FPU].valid,
          `BP_COMMIT.commit_if[VX_gpu_pkg::EX_TEX].valid);
        if($isunknown({`BP_NATIVE.result_if.ready,`BP_NATIVE.result_if.data,
            `BP_NATIVE.response_bank,`BP_NATIVE.response_page_index}))$fatal(1,"GPU_BP_BANK_UNKNOWN");
        $fdisplay(bp_bank_fd,"%0d %0d %0d %0d %0d %h %h",bc,crt_cycles,
            `BP_NATIVE.result_if.ready,`BP_NATIVE.response_bank,`BP_NATIVE.response_page_index,
            `BP_NATIVE.result_if.data,`BP_NATIVE.result_if.data.data);
        if($isunknown({`BP_INT.choose_native,`BP_INT.legacy_res.valid,
            `BP_BLOCK.tcu_int.result_if.ready,`BP_BLOCK.pe_result_if[0].valid,
            `BP_BLOCK.pe_result_if[0].ready}))$fatal(1,"GPU_BP_ARBITRATION_UNKNOWN");
        $fdisplay(bp_arb_fd,"%0d %0d %0d %0d %0d %0d %0d %0d",bc,crt_cycles,
            `BP_NATIVE.result_if.ready,`BP_INT.choose_native,`BP_INT.legacy_res.valid,
            `BP_BLOCK.tcu_int.result_if.ready,`BP_BLOCK.pe_result_if[0].valid,`BP_BLOCK.pe_result_if[0].ready);
        held=!`BP_NATIVE.result_if.ready;
        if(held)begin snapshot=`BP_NATIVE.result_if.data;held_bank=`BP_NATIVE.response_bank;held_page=`BP_NATIVE.response_page_index;end
      end else held=0;
      if(`BP_TCU.dispatch_if[0].valid && `BP_TCU.dispatch_if[0].ready)bp_request(bc,`BP_TCU.dispatch_if[0].data);
      if(`BP_TCU.commit_if[0].valid && `BP_TCU.commit_if[0].ready)bp_response(bc,`BP_TCU.commit_if[0].data);
    end
  end
end
`undef BP_NATIVE
`undef BP_CORE
`undef BP_ALU
`undef BP_COMMIT
`undef BP_INT
`undef BP_BLOCK
`undef BP_TCU
`endif
