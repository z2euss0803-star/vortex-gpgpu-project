`timescale 1ns/1ps
`include "VX_define.vh"
module tb_pair_frontend;
 import VX_gpu_pkg::*;
 import VX_tcu_pkg::*;
 reg clk=0, reset=1;
 wire dependency_finished;
 tcu_pair_dependency_tb dependency(.finished(dependency_finished));
 always #5 clk=~clk;
 VX_fetch_if fetch();
 VX_decode_if dec();
 VX_decode_sched_if ds();
 VX_ibuffer_if ib(), out(), rib(), rout();
 VX_decode decode(.clk(clk),.reset(reset),.fetch_if(fetch),.decode_if(dec),.decode_sched_if(ds));
 wire native_in=(dec.data.op_args.tcu.fmt_s>=13);
 assign ib.valid=dec.valid;
 assign dec.ready=ib.ready;
 assign ib.data={dec.data.uuid,dec.data.tmask,dec.data.PC,dec.data.ex_type,dec.data.op_type,
                 dec.data.op_args,dec.data.wb,dec.data.used_rs,dec.data.rd,dec.data.rs1,dec.data.rs2,dec.data.rs3};
 assign rib.valid=ib.valid&&!native_in;
 assign rib.data=ib.data;
 assign rout.ready=out.ready;
 VX_uop_sequencer dut(.clk(clk),.reset(reset),.input_if(ib),.output_if(out));
 VX_uop_sequencer_ref refseq(.clk(clk),.reset(reset),.input_if(rib),.output_if(rout));
 integer fmt, count, cycles, commands=0, native_commands=0, old_commands=0;
 ibuffer_t held;
 reg was_held=0;
 always @(posedge clk) if(!reset)begin
   if(was_held && out.data!==held)$fatal(1,"FRONTEND_HOLD_CHANGED");
   was_held=out.valid&&!out.ready; held=out.data;
 end else was_held=0;

 task command(input integer format,input integer dest);
 begin
   @(negedge clk);
   fetch.data='0; fetch.data.tmask=4'hf;fetch.data.PC=PC_BITS'(commands+32);
   fetch.data.uuid=UUID_WIDTH'(commands);
   fetch.data.instr=(32'h2<<25)|(32'(format)<<15)|(32'(dest)<<7)|32'h0b;
   fetch.valid=1;
   count=0; cycles=0;
   begin : accept_loop
   while(1) begin
     out.ready=(cycles%5!=2);
     @(posedge clk);
     if(format<13)begin
       if(out.valid!==rout.valid || ib.ready!==rib.ready)$fatal(1,"LEGACY_CONTROL_CHANGED fmt=%0d",format);
       if(out.valid && out.data!==rout.data)$fatal(1,"LEGACY_UOP_CHANGED fmt=%0d step=%0d",format,count);
     end
     if(out.valid && out.ready)begin
       if(out.data.op_args.tcu.fmt_s!==4'(format)||out.data.op_args.tcu.fmt_d!==4'(dest))$fatal(1,"DECODE_FORMAT");
       if(format>=13)begin
         if(out.data.rs1!==make_reg_num(REG_TYPE_F,5'd0)||out.data.rs2!==make_reg_num(REG_TYPE_F,5'd28)||out.data.rs3!==make_reg_num(REG_TYPE_F,5'd10)||out.data.rd!==make_reg_num(REG_TYPE_F,5'd10))$fatal(1,"NATIVE_REGISTER_BASE");
         if(out.data.used_rs!==(format==14?(dest==3?3'b111:3'b011):3'b100)||out.data.wb!==(format!=14))$fatal(1,"NATIVE_DEPENDENCY fmt=%0d used=%b wb=%b",format,out.data.used_rs,out.data.wb);
         if(out.data.op_args.tcu.step_m!==0||out.data.op_args.tcu.step_n!==0)$fatal(1,"NATIVE_COUNTER");
       end
       count=count+1;
     end
     if(fetch.valid&&fetch.ready)begin
       if(count!=(format>=13?1:16))$fatal(1,"NATIVE_SINGLE_UOP fmt=%0d count=%0d",format,count);
       disable accept_loop;
     end
     cycles=cycles+1;
     if(cycles>120)$fatal(1,"FRONTEND_TIMEOUT");
     @(negedge clk);
   end
   end
   @(negedge clk);fetch.valid=0;
   out.ready=1;
   @(posedge clk); if(out.valid)$fatal(1,"NATIVE_SINGLE_UOP fmt=%0d",format);
   @(negedge clk);
   commands=commands+1;
   if(format>=13)native_commands=native_commands+1;else old_commands=old_commands+1;
 end
 endtask
 initial begin
   fetch.valid=0;fetch.data='0;out.ready=1;
   repeat(5)@(negedge clk);reset=0;
   command(13,8);command(14,8);command(15,8);
   for(integer j=0;j<20;j=j+1)begin
     command(9,8);command(13,8);command(10,8);command(14,8);command(11,8);command(15,8);command(12,8);command(1,8);command(2,8);
   end
   command(13,3);command(14,3);command(15,3);
   wait(dependency_finished);
   $display("PAIR_FRONTEND_PASS commands=%0d native=%0d legacy=%0d",commands,native_commands,old_commands);
   $finish;
 end
 initial begin #1000000;$fatal(1,"GLOBAL_TIMEOUT");end
endmodule
