`timescale 1ns/1ps
// External AXI memory model only. Never substitutes GPU/TCU computation.
module axi_ddr_model #(
  parameter integer R_DELAY=4, B_DELAY=24
)(
  input wire clk,resetn,job_active,
  input wire [48:0] HP_awaddr,HP_araddr,
  input wire [7:0] HP_awlen,HP_arlen,
  input wire [2:0] HP_awsize,HP_arsize,
  input wire [5:0] HP_awid,HP_arid,
  input wire HP_awvalid,HP_wvalid,HP_wlast,HP_arvalid,HP_bready,HP_rready,
  input wire [511:0] HP_wdata,
  input wire [63:0] HP_wstrb,
  output wire HP_awready,HP_wready,HP_arready,
  output reg [5:0] HP_bid=0,HP_rid=0,
  output reg [1:0] HP_bresp=0,HP_rresp=0,
  output reg HP_bvalid=0,HP_rvalid=0,HP_rlast=1,
  output reg [511:0] HP_rdata=0
);
  localparam integer MAX_REGIONS=1024;
  longint unsigned bases[0:MAX_REGIONS-1],ends[0:MAX_REGIONS-1];
  bit writable[0:MAX_REGIONS-1];
  bit stack_unknown[0:MAX_REGIONS-1];
  byte unsigned fill[0:MAX_REGIONS-1];
  string region_names[0:MAX_REGIONS-1];
  integer region_count=0;
  // Four-state bytes are essential: a CRT callee-save spill can contain X.
  // Preserve those bits through memory, never coerce them to zero.
  logic [7:0] storage[longint unsigned];
  integer cycle=0,read_delay=0,write_delay=0;
  integer reads=0,writes=0;
  reg aw_full=0,w_full=0,r_full=0,write_committed=0;
  reg [48:0] write_addr,read_addr;
  reg [5:0] write_id,read_id;
  reg [511:0] write_data;
  reg [63:0] write_strb;
  assign HP_awready=resetn && !aw_full && !HP_bvalid && cycle%3!=0;
  assign HP_wready=resetn && !w_full && !HP_bvalid && cycle%5!=0;
  assign HP_arready=resetn && !r_full && !HP_rvalid && cycle%4!=0;

  function automatic integer find_region(input longint unsigned addr);
    find_region=-1;
    for(integer i=0;i<region_count;i=i+1)
      if(addr>=bases[i] && addr<ends[i])find_region=i;
  endfunction

  task automatic register_region(input string name,input longint unsigned hp_base,
      input longint unsigned byte_count,input string permissions,input byte unsigned fill_byte,
      input bit preserve_stack_unknown=0);
    if(job_active===1'b1)$fatal(1,"MODEL_REGISTER_DURING_JOB");
    if(region_count>=MAX_REGIONS || byte_count==0 || hp_base+byte_count<hp_base ||
       hp_base+byte_count>64'h2000000000000)$fatal(1,"MODEL_REGION_BOUNDS");
    if(permissions!="r" && permissions!="rw")$fatal(1,"MODEL_REGION_PERMISSION");
    for(integer i=0;i<region_count;i=i+1)
      if(hp_base<ends[i] && hp_base+byte_count>bases[i])$fatal(1,"MODEL_REGION_OVERLAP");
    bases[region_count]=hp_base;ends[region_count]=hp_base+byte_count;
    writable[region_count]=(permissions=="rw");fill[region_count]=fill_byte;
    stack_unknown[region_count]=preserve_stack_unknown;
    region_names[region_count]=name;region_count=region_count+1;
  endtask

  task automatic load_byte(input longint unsigned addr,input byte unsigned value);
    if(job_active!==1'b0)$fatal(1,"MODEL_LOAD_DURING_JOB_OR_UNKNOWN");
    if(find_region(addr)<0)$fatal(1,"MODEL_LOAD_UNALLOCATED %h",addr);
    storage[addr]=value;
  endtask

  function automatic logic [7:0] peek_byte(input longint unsigned addr);
    integer i;
    i=find_region(addr);
    if(i<0)$fatal(1,"MODEL_READ_UNALLOCATED %h",addr);
    if(storage.exists(addr))peek_byte=storage[addr];else peek_byte=fill[i];
  endfunction

  task automatic legal_line(input [48:0] addr,input bit write_access);
    integer i;
    if($isunknown(addr) || addr[5:0]!=0)$fatal(1,"MODEL_LINE_ALIGNMENT_OR_X %h",addr);
    for(integer j=0;j<64;j=j+1)begin
      i=find_region(longint'(addr)+j);
      if(i<0)$fatal(1,"MODEL_LINE_UNALLOCATED %h",addr);
      if(write_access && !writable[i])$fatal(1,"MODEL_WRITE_READONLY %h",addr);
    end
  endtask

  always @(posedge clk) begin
    if(!resetn)begin
      cycle<=0;aw_full<=0;w_full<=0;r_full<=0;write_committed<=0;
      HP_bvalid<=0;HP_rvalid<=0;HP_bresp<=0;HP_rresp<=0;HP_rlast<=1;
      HP_bid<=0;HP_rid<=0;HP_rdata<=0;write_delay<=0;read_delay<=0;
    end else begin
      cycle<=cycle+1;
      if(HP_awvalid && HP_awready)begin
        legal_line(HP_awaddr,0);
        if($isunknown({HP_awlen,HP_awsize,HP_awid}) || HP_awlen!=0 || HP_awsize!=6)$fatal(1,"MODEL_AW_SHAPE");
        write_addr<=HP_awaddr;write_id<=HP_awid;aw_full<=1;
      end
      if(HP_wvalid && HP_wready)begin
        if(HP_wlast!==1'b1 || $isunknown(HP_wstrb))$fatal(1,"MODEL_W_SHAPE");
        write_data<=HP_wdata;write_strb<=HP_wstrb;w_full<=1;
      end
      if(aw_full && w_full && !HP_bvalid)begin
        if(!write_committed)begin
          // AW and W are independent. Validate every selected byte before any
          // update, after both address and data have actually been accepted.
          for(integer j=0;j<64;j=j+1)begin
            if(write_strb[j])begin
              if(!writable[find_region(longint'(write_addr)+j)])$fatal(1,"MODEL_WRITE_READONLY %h",write_addr);
              if($isunknown(write_data[j*8+:8]) && !stack_unknown[find_region(longint'(write_addr)+j)])
                $fatal(1,"MODEL_W_DATA_X %h",longint'(write_addr)+j);
            end
          end
          for(integer j=0;j<64;j=j+1)
            if(write_strb[j])storage[longint'(write_addr)+j]=write_data[j*8+:8];
          write_committed<=1;
        end
        if(write_delay==B_DELAY)begin
          HP_bvalid<=1;HP_bid<=write_id;HP_bresp<=0;
          write_delay<=0;aw_full<=0;w_full<=0;write_committed<=0;writes<=writes+1;
        end else write_delay<=write_delay+1;
      end
      if(HP_bvalid && HP_bready)HP_bvalid<=0;
      if(HP_arvalid && HP_arready)begin
        legal_line(HP_araddr,0);
        if($isunknown({HP_arlen,HP_arsize,HP_arid}) || HP_arlen!=0 || HP_arsize!=6)$fatal(1,"MODEL_AR_SHAPE");
        read_addr<=HP_araddr;read_id<=HP_arid;r_full<=1;read_delay<=0;
      end
      if(r_full && !HP_rvalid)begin
        if(read_delay==R_DELAY)begin
          for(integer j=0;j<64;j=j+1)HP_rdata[j*8+:8]<=peek_byte(longint'(read_addr)+j);
          HP_rid<=read_id;HP_rvalid<=1;HP_rresp<=0;HP_rlast<=1;r_full<=0;reads<=reads+1;
        end else read_delay<=read_delay+1;
      end
      if(HP_rvalid && HP_rready)HP_rvalid<=0;
    end
  end
endmodule
