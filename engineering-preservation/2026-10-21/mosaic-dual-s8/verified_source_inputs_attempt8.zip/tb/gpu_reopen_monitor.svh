// Passive repeated-reset convergence and public job boundary evidence.
`ifdef PAIR_REOPEN
integer reopen_fd,reopen_ticks=0,reopen_reset_edges=0;
initial begin
  reopen_fd=$fopen("gpu_reset_epochs.txt","w");
  if(!reopen_fd)$fatal(1,"GPU_REOPEN_TRACE_OPEN");
end
task automatic reopen_record(input string event_name);
  if($isunknown({resetn,dut.gpu_reset,job_active,dut.gpu_busy,
      memory_bus.aw_full,memory_bus.w_full,memory_bus.r_full,HP_bvalid,HP_rvalid}))
    $fatal(1,"GPU_REOPEN_BOUNDARY_UNKNOWN");
  $fdisplay(reopen_fd,"%0d %s %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
      pair_epoch,event_name,reopen_ticks,resetn,dut.gpu_reset,job_active,dut.gpu_busy,
      memory_bus.aw_full,memory_bus.w_full,memory_bus.r_full,HP_bvalid,HP_rvalid);
endtask
`define REOPEN_SOCKET dut.gpu.vortex.g_clusters[0].cluster.g_sockets[0].socket
`define REOPEN_IC `REOPEN_SOCKET.icache.g_cache_wrap[0].cache_wrap.g_cache.cache.g_banks[0].bank.mshr_pending_size
`define REOPEN_DC `REOPEN_SOCKET.dcache.g_cache_wrap[0].cache_wrap.g_cache.cache.g_banks[0].bank.mshr_pending_size
always @(posedge clk)begin
  reopen_ticks=reopen_ticks+1;
  if(!resetn)reopen_reset_edges=reopen_reset_edges+1;else reopen_reset_edges=0;
  if(reopen_reset_edges==8)begin
    #1;
    if(resetn!==0 || dut.gpu_reset!==1 || job_active!==0 || dut.gpu_busy!==0 ||
       `REOPEN_SOCKET.icache_reset!==1 || `REOPEN_SOCKET.dcache_reset!==1 ||
       `REOPEN_IC.size!=='0 || `REOPEN_DC.size!=='0 ||
       `REOPEN_IC.empty!==1 || `REOPEN_DC.empty!==1 ||
       `REOPEN_IC.full!==0 || `REOPEN_DC.full!==0)
      $fatal(1,"GPU_REOPEN_RESET_CONVERGENCE_FAILED");
    reopen_record("reset");
  end
end
`undef REOPEN_DC
`undef REOPEN_IC
`undef REOPEN_SOCKET
`endif
