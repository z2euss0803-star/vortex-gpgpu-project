log_wave /tb_gpu_pair_system/resetn
log_wave /tb_gpu_pair_system/dut/gpu_busy
log_wave /tb_gpu_pair_system/crt_cycles
run all
quit
